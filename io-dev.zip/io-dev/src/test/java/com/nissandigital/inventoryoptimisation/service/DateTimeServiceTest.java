//package com.nissandigital.inventoryoptimisation.service;
//
//import org.junit.Before;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import com.nissandigital.inventoryoptimization.dto.DateTimeDTO;
//import com.nissandigital.inventoryoptimization.service.DateTimeService;
//import com.nissandigital.inventoryoptimization.service.impl.DateTimeServiceImpl;
//
//@RunWith(MockitoJUnitRunner.class)
//public class DateTimeServiceTest {
//	
//	@Mock
//	private DateTimeService mockDateTimeService;
//	
//	@InjectMocks
//	private DateTimeServiceImpl dateTimeServiceImpl;
//	
//	@Before
//	public void setup() throws Exception
//	{
//		DateTimeDTO currentDateResponse = new DateTimeDTO();
//		
//	}
//
//}
