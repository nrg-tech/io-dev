//package com.nissandigital.inventoryoptimisation.service;
//
//import static org.assertj.core.api.Assertions.tuple;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.assertj.core.api.Assertions;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.modelmapper.ModelMapper;
//import org.springframework.test.util.ReflectionTestUtils;
//
//import com.nissandigital.inventoryoptimization.dto.DemandVariabilityContributionDTO;
//import com.nissandigital.inventoryoptimization.dto.SupplyVariabilityContributionDTO;
//import com.nissandigital.inventoryoptimization.dto.TopPartsStatisticsOverviewDTO;
//import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
//import com.nissandigital.inventoryoptimization.entity.StatisticalMVTopPartsEntity;
//import com.nissandigital.inventoryoptimization.repository.StatisticalMVTopPartsRepository;
//import com.nissandigital.inventoryoptimization.service.UserService;
//import com.nissandigital.inventoryoptimization.service.impl.TopPartsStatisticsServiceImpl;
//
//@RunWith(MockitoJUnitRunner.class)
//public class TopPartsStatisticsServiceTest {
//
//	@Mock
//	StatisticalMVTopPartsRepository mockTopPartsRepository;
//
//	@Mock
//	UserService mockUserService;
//
//	@InjectMocks
//	TopPartsStatisticsServiceImpl mockTopPartsService;
//
//	List<StatisticalMVTopPartsEntity> entityList;
//
//	@Before
//	public void setup() throws Exception {
//		StatisticalMVTopPartsEntity entity1 = new StatisticalMVTopPartsEntity();
//		entity1.setAverageDailyDemand(Double.parseDouble("2000"));
//		entity1.setAverageSupplyCycleTime(32.4);
//		entity1.setCoefVariableDailyDemand(2.3);
//		entity1.setCoefVariableSupplyCycleTime(Double.parseDouble("1426"));
//		entity1.setCurrentFloat(1.6);
//		entity1.setFloatSurplus(3.4);
//		entity1.setId(1);
//		entity1.setItemNumber("INUX1551");
//		entity1.setPlantId(1);
//		entity1.setRecommendedFloat(4.8);
//
//		StatisticalMVTopPartsEntity entity2 = new StatisticalMVTopPartsEntity();
//		entity2.setAverageDailyDemand(Double.parseDouble("2000"));
//		entity2.setAverageSupplyCycleTime(32.4);
//		entity2.setCoefVariableDailyDemand(2.3);
//		entity2.setCoefVariableSupplyCycleTime(Double.parseDouble("2426"));
//		entity2.setCurrentFloat(2.6);
//		entity2.setFloatSurplus(3.4);
//		entity2.setId(2);
//		entity2.setItemNumber("INUX2552");
//		entity2.setPlantId(1);
//		entity2.setRecommendedFloat(4.8);
//
//		StatisticalMVTopPartsEntity entity3 = new StatisticalMVTopPartsEntity();
//		entity3.setAverageDailyDemand(Double.parseDouble("3000"));
//		entity3.setAverageSupplyCycleTime(33.4);
//		entity3.setCoefVariableDailyDemand(3.3);
//		entity3.setCoefVariableSupplyCycleTime(Double.parseDouble("3436"));
//		entity3.setCurrentFloat(3.6);
//		entity3.setFloatSurplus(3.4);
//		entity3.setId(3);
//		entity3.setItemNumber("INUX3553");
//		entity3.setPlantId(1);
//		entity3.setRecommendedFloat(4.8);
//
//		StatisticalMVTopPartsEntity entity4 = new StatisticalMVTopPartsEntity();
//		entity4.setAverageDailyDemand(Double.parseDouble("4000"));
//		entity4.setAverageSupplyCycleTime(44.4);
//		entity4.setCoefVariableDailyDemand(4.4);
//		entity4.setCoefVariableSupplyCycleTime(Double.parseDouble("4446"));
//		entity4.setCurrentFloat(4.6);
//		entity4.setFloatSurplus(4.4);
//		entity4.setId(4);
//		entity4.setItemNumber("INUX4554");
//		entity4.setPlantId(1);
//		entity4.setRecommendedFloat(4.8);
//
//		StatisticalMVTopPartsEntity entity5 = new StatisticalMVTopPartsEntity();
//		entity5.setAverageDailyDemand(Double.parseDouble("5000"));
//		entity5.setAverageSupplyCycleTime(55.5);
//		entity5.setCoefVariableDailyDemand(5.5);
//		entity5.setCoefVariableSupplyCycleTime(Double.parseDouble("5556"));
//		entity5.setCurrentFloat(5.6);
//		entity5.setFloatSurplus(5.5);
//		entity5.setId(5);
//		entity5.setItemNumber("INUX5555");
//		entity5.setPlantId(1);
//		entity5.setRecommendedFloat(5.8);
//
//		entityList = new ArrayList<StatisticalMVTopPartsEntity>();
//		entityList.add(entity1);
//		entityList.add(entity2);
//		entityList.add(entity3);
//		entityList.add(entity4);
//		entityList.add(entity5);
//
//		ModelMapper modelMapper = new ModelMapper();
//		modelMapper.getConfiguration().setSkipNullEnabled(true);
//		ReflectionTestUtils.setField(mockTopPartsService, "modelMapper", modelMapper);
//
//		UserDetailsDTO user = new UserDetailsDTO();
//		user.setPlantId(1);
//		user.setUserId(1001);
//
//		when(mockUserService.getCurrentUser()).thenReturn(user);
//		when(mockTopPartsRepository.findAllByPlantId(1)).thenReturn(entityList);
////		when(mockTopPartsRepository.findAllByPlantId((Integer)2)).thenReturn(null);
//	}
//
//	@Test
//	public void testGetDemandVariabilityContribution() {
//		List<DemandVariabilityContributionDTO> response = mockTopPartsService.getDemandVariabilityContribution();
//		Assertions.assertThat(response)
//				.extracting(DemandVariabilityContributionDTO::getAverageDailyDemand,
//						DemandVariabilityContributionDTO::getCoefVariableDailyDemand,
//						DemandVariabilityContributionDTO::getItemNumber)
//				.containsExactly(
//						tuple(entityList.get(0).getAverageDailyDemand(), entityList.get(0).getCoefVariableDailyDemand(),
//								entityList.get(0).getItemNumber()),
//						tuple(entityList.get(1).getAverageDailyDemand(), entityList.get(1).getCoefVariableDailyDemand(),
//								entityList.get(1).getItemNumber()),
//						tuple(entityList.get(2).getAverageDailyDemand(), entityList.get(2).getCoefVariableDailyDemand(),
//								entityList.get(2).getItemNumber()),
//						tuple(entityList.get(3).getAverageDailyDemand(), entityList.get(3).getCoefVariableDailyDemand(),
//								entityList.get(3).getItemNumber()),
//						tuple(entityList.get(4).getAverageDailyDemand(), entityList.get(4).getCoefVariableDailyDemand(),
//								entityList.get(4).getItemNumber()));
//	}
//
//	@Test
//	public void testGetSupplyVariabilityContribution() {
//		List<SupplyVariabilityContributionDTO> response = mockTopPartsService.getSupplyVariabilityContribution();
//		Assertions.assertThat(response)
//				.extracting(SupplyVariabilityContributionDTO::getAverageSupplyCycleTime,
//						SupplyVariabilityContributionDTO::getCoefVariableSupplyCycleTime,
//						SupplyVariabilityContributionDTO::getItemNumber)
//				.containsExactly(
//						tuple(entityList.get(0).getAverageSupplyCycleTime(),
//								entityList.get(0).getCoefVariableSupplyCycleTime(), entityList.get(0).getItemNumber()),
//						tuple(entityList.get(1).getAverageSupplyCycleTime(),
//								entityList.get(1).getCoefVariableSupplyCycleTime(), entityList.get(1).getItemNumber()),
//						tuple(entityList.get(2).getAverageSupplyCycleTime(),
//								entityList.get(2).getCoefVariableSupplyCycleTime(), entityList.get(2).getItemNumber()),
//						tuple(entityList.get(3).getAverageSupplyCycleTime(),
//								entityList.get(3).getCoefVariableSupplyCycleTime(), entityList.get(3).getItemNumber()),
//						tuple(entityList.get(4).getAverageSupplyCycleTime(),
//								entityList.get(4).getCoefVariableSupplyCycleTime(), entityList.get(4).getItemNumber()));
//	}
//
//	@Test
//	public void testGetTopPartsOverview() {
//		List<TopPartsStatisticsOverviewDTO> response = mockTopPartsService.getTopPartsOverviewDto();
//		Assertions.assertThat(response).extracting(TopPartsStatisticsOverviewDTO::getCurrentFloat,
//				TopPartsStatisticsOverviewDTO::getFloatSurplus, TopPartsStatisticsOverviewDTO::getRecommendedFloat,
//				TopPartsStatisticsOverviewDTO::getItemNumber)
//				.containsExactly(
//						tuple(entityList.get(0).getCurrentFloat(), entityList.get(0).getFloatSurplus(),
//								entityList.get(0).getRecommendedFloat(), entityList.get(0).getItemNumber()),
//						tuple(entityList.get(1).getCurrentFloat(), entityList.get(1).getFloatSurplus(),
//								entityList.get(1).getRecommendedFloat(), entityList.get(1).getItemNumber()),
//						tuple(entityList.get(2).getCurrentFloat(), entityList.get(2).getFloatSurplus(),
//								entityList.get(2).getRecommendedFloat(), entityList.get(2).getItemNumber()),
//						tuple(entityList.get(3).getCurrentFloat(), entityList.get(3).getFloatSurplus(),
//								entityList.get(3).getRecommendedFloat(), entityList.get(3).getItemNumber()),
//						tuple(entityList.get(4).getCurrentFloat(), entityList.get(4).getFloatSurplus(),
//								entityList.get(4).getRecommendedFloat(), entityList.get(4).getItemNumber()));
//	}
//}
