package com.nissandigital.inventoryoptimisation.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.test.util.ReflectionTestUtils;

import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
import com.nissandigital.inventoryoptimization.entity.UserEntity;
import com.nissandigital.inventoryoptimization.entity.UserRoleEntity;
import com.nissandigital.inventoryoptimization.repository.UserRepository;
import com.nissandigital.inventoryoptimization.service.impl.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
	@Mock
	UserRepository mockUserRepository;
	
	@InjectMocks
	UserServiceImpl mockUserService;

	UserEntity user;
	
	@Before
	public void setup()
	{
		user = new UserEntity();
		user.setFirstName("Alex");
		user.setLastName("philip");
		user.setPlantId(1);
		user.setUserId(1001);
		user.setUserName("NDH00001");
		
		UserRoleEntity userRole = new UserRoleEntity();
		userRole.setUserRoleId(1);
		userRole.setUserRoleDesc("Admin");
		user.setUserRoleId(userRole);
		
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setSkipNullEnabled(true);
		ReflectionTestUtils.setField(mockUserService, "modelMapper", modelMapper);
		
		when(mockUserRepository.findById(1009l)).thenReturn(Optional.of(user));
	}
	
	@Test
	public void testGetCurrentUser() {
		UserDetailsDTO currUser = mockUserService.getCurrentUser();
		assertEquals(currUser.getFirstName(),user.getFirstName());
		assertEquals(currUser.getLastName(),user.getLastName());
		assertEquals(currUser.getUserId(),user.getUserId());
		assertEquals(currUser.getUserName(),user.getUserName());
	}
}
