package com.nissandigital.inventoryoptimisation.service;

import static org.assertj.core.api.Assertions.tuple;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import org.assertj.core.api.Assertions;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import com.nissandigital.inventoryoptimization.dto.PartCategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartDetailsDTO;
import com.nissandigital.inventoryoptimization.dto.PartsCategoryMappingDTO;
import com.nissandigital.inventoryoptimization.entity.PartCategoryEntity;
import com.nissandigital.inventoryoptimization.entity.PartEntity;
import com.nissandigital.inventoryoptimization.entity.SupplierAddressBookEntity;
import com.nissandigital.inventoryoptimization.repository.PartCategoryRepository;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.repository.PartsCategoryMappingRepository;
import com.nissandigital.inventoryoptimization.repository.SupplierPartsRepository;
import com.nissandigital.inventoryoptimization.repository.SupplierRepository;
import com.nissandigital.inventoryoptimization.repository.UserPartsRepository;
import com.nissandigital.inventoryoptimization.service.impl.PartCategoryServiceImpl;

/**
 * Test class for PartServiceTest
 * 
 * @author Nissan Digital
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PartCategoryService {
	@Mock
	private PartCategoryRepository mockPartCategoryRepository;

	@Mock
	private PartsCategoryMappingRepository mockPartCategoryMappingRepository;

	@Mock
	private PartRepository mockPartRepository;

	@Mock
	private SupplierPartsRepository mockSupplierPartsRepository;

	@Mock
	private SupplierRepository mockSupplierRepository;

	@Mock
	private UserPartsRepository mockUserPartsRepository;

	@InjectMocks
	private PartCategoryServiceImpl partCategoryService;

	PartCategoryDTO partCategoryDTO;

	PartsCategoryMappingDTO partsCategoryMappingDTO;

	@Before
	public void setup() {
		PartCategoryEntity partCategoryEntity1 = new PartCategoryEntity();
		partCategoryEntity1.setPartCategoryDescription("category_1");
		partCategoryEntity1.setPartCategoryId(2012);
		partCategoryEntity1.setPlantId(1);

		PartCategoryEntity partCategoryEntity2 = new PartCategoryEntity();
		partCategoryEntity2.setPartCategoryDescription("category_2");
		partCategoryEntity2.setPartCategoryId(2013);
		partCategoryEntity2.setPlantId(1);

		List<Long> partIds = new ArrayList<>();
		partIds.add(10672l);
		partIds.add(10726l);

		PartEntity partEntity = new PartEntity();
		partEntity.setItemNumber("009231081A");
		partEntity.setItemDescription("PIN SNAP");
		partEntity.setPartTypeCode("Direct");

		PartEntity partEntity2 = new PartEntity();
		partEntity2.setItemNumber("009231081B");
		partEntity2.setItemDescription("BOLT-HEX");
		partEntity2.setPartTypeCode("Direct");

		SupplierAddressBookEntity supplierAddressBookEntity = new SupplierAddressBookEntity();
		supplierAddressBookEntity.setSupplierType("Domestic");
		supplierAddressBookEntity.setSupplierName("NISSAN MEXICANA L.E");

		SupplierAddressBookEntity supplierAddressBookEntity2 = new SupplierAddressBookEntity();
		supplierAddressBookEntity2.setSupplierType("Domestic");
		supplierAddressBookEntity2.setSupplierName("NISSAN NORTH AMERICA L.E");

		List<Long> userIds = new ArrayList<>();
		userIds.add((long) 1122);
		userIds.add((long) 1123);

		List<Long> supplierIds = new ArrayList<>();
		supplierIds.add(80l);
		supplierIds.add(81l);

		List<PartEntity> partEntityList = new ArrayList<>();
		partEntityList.add(partEntity);
		partEntityList.add(partEntity2);

		List<PartCategoryEntity> partCategoryEntityList = new ArrayList<>();
		partCategoryEntityList.add(partCategoryEntity1);
		partCategoryEntityList.add(partCategoryEntity2);

		List<SupplierAddressBookEntity> supplierAddressBookEntityList = new ArrayList<>();
		supplierAddressBookEntityList.add(supplierAddressBookEntity);
		supplierAddressBookEntityList.add(supplierAddressBookEntity2);

		partCategoryDTO = new PartCategoryDTO();
		partCategoryDTO.setCategoryId(2012);
		partCategoryDTO.setPartCategoryDescription("category_1");
		partCategoryDTO.setPlantId(1);

		partsCategoryMappingDTO = new PartsCategoryMappingDTO();
		partsCategoryMappingDTO.setCategoryId(2012);
		partsCategoryMappingDTO.setPartIds(partIds);

		when(mockPartCategoryRepository.findAll()).thenReturn(partCategoryEntityList);
		when(mockPartCategoryMappingRepository.findPartsByPartCategoryId(2012l)).thenReturn(partIds);
		when(mockPartCategoryRepository.findUnmappedParts()).thenReturn(partIds);
		when(mockPartRepository.findByPartIdIn(partIds)).thenReturn(partEntityList);
		when(mockSupplierPartsRepository.findSupplierIdsForPartIds(partIds)).thenReturn(supplierIds);
		when(mockSupplierRepository.findBySkSupplierIdIn(supplierIds)).thenReturn(supplierAddressBookEntityList);
		when(mockUserPartsRepository.findPartsControllerInfoByPartIds(partIds)).thenReturn(userIds);

	}

	

	@Test
	public void testFindByCategoryId() {
		List<PartDetailsDTO> partDetailsDTOList = partCategoryService.findPartsByCategory(2012);
		Assertions.assertThat(partDetailsDTOList)
				.extracting(PartDetailsDTO::getPartNumber, PartDetailsDTO::getPartDescription,
						PartDetailsDTO::getPartController, PartDetailsDTO::getPartTypeCode, PartDetailsDTO::getLocation,
						PartDetailsDTO::getSupplierName)
				.containsExactly(tuple("009231081A", "PIN SNAP", "1122", "Direct", "Domestic", "NISSAN MEXICANA L.E"),
						tuple("009231081B", "BOLT-HEX", "1123", "Direct", "Domestic", "NISSAN NORTH AMERICA L.E"));
	}

	@Test
	public void testFindUnmappedParts() {
		List<PartDetailsDTO> partDetailsDTOList = partCategoryService.findUnmappedParts();
		Assertions.assertThat(partDetailsDTOList)
				.extracting(PartDetailsDTO::getPartNumber, PartDetailsDTO::getPartDescription,
						PartDetailsDTO::getPartController, PartDetailsDTO::getPartTypeCode, PartDetailsDTO::getLocation,
						PartDetailsDTO::getSupplierName)
				.containsExactly(tuple("009231081A", "PIN SNAP", "1122", "Direct", "Domestic", "NISSAN MEXICANA L.E"),
						tuple("009231081B", "BOLT-HEX", "1123", "Direct", "Domestic", "NISSAN NORTH AMERICA L.E"));

	}

	@Test
	public void testAddPartsCategory() {
		PartCategoryServiceImpl partCategoryServiceImpl = mock(PartCategoryServiceImpl.class);
		ArgumentCaptor<PartCategoryDTO> partsCategoryDTOCaptor = ArgumentCaptor.forClass(PartCategoryDTO.class);
		doNothing().when(partCategoryServiceImpl).addPartsCategory(partsCategoryDTOCaptor.capture());
		partCategoryServiceImpl.addPartsCategory(partCategoryDTO);
		assertEquals(1, partsCategoryDTOCaptor.getValue().getPlantId());
		assertEquals("category_1", partsCategoryDTOCaptor.getValue().getPartCategoryDescription());;
		assertEquals(2012, partsCategoryDTOCaptor.getValue().getCategoryId());
	}

	@Test
	public void testAddPartsToPartsCategory() {
		PartCategoryServiceImpl partCategoryServiceImpl = mock(PartCategoryServiceImpl.class);
		ArgumentCaptor<PartsCategoryMappingDTO> partsCategoryMappingDTOCaptor = ArgumentCaptor
				.forClass(PartsCategoryMappingDTO.class);
		doNothing().when(partCategoryServiceImpl).addPartsToPartsCategory(partsCategoryMappingDTOCaptor.capture());
		partCategoryServiceImpl.addPartsToPartsCategory(partsCategoryMappingDTO);
		assertEquals(2012, partsCategoryMappingDTOCaptor.getValue().getCategoryId());
		assertEquals(Arrays.asList(10672L,10726L), partsCategoryMappingDTOCaptor.getValue().getPartIds());
	}

}
