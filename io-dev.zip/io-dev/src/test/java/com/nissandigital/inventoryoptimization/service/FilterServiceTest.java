package com.nissandigital.inventoryoptimization.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.nissandigital.inventoryoptimization.dto.FilterDTO;
import com.nissandigital.inventoryoptimization.entity.PlantEntity;
import com.nissandigital.inventoryoptimization.entity.UniqueColumnViewEntity;
import com.nissandigital.inventoryoptimization.repository.FilterRepository;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.service.impl.FilterServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class FilterServiceTest {

	@Mock
	private FilterRepository mockFilterRepository;

	@Mock
	private PlantRepository mockPlantRepository;

	@InjectMocks
	private FilterServiceImpl mockFilterServiceImpl;

	@Before
	public void setup() {
		UniqueColumnViewEntity uniqueColumn = new UniqueColumnViewEntity();
		uniqueColumn.setColumnName("partNumber");
		uniqueColumn.setColumnValue("50842EZ00C");
		uniqueColumn.setPlantCode("SP");

		UniqueColumnViewEntity uniqueColumn1 = new UniqueColumnViewEntity();
		uniqueColumn1.setColumnName("partNumber");
		uniqueColumn1.setColumnValue("962106CA0A");
		uniqueColumn1.setPlantCode("SP");

		UniqueColumnViewEntity uniqueColumn2 = new UniqueColumnViewEntity();
		uniqueColumn2.setColumnName("partNumber");
		uniqueColumn2.setColumnValue("410004BT0B");
		uniqueColumn2.setPlantCode("SP");

		List<UniqueColumnViewEntity> listOfUnique = new ArrayList<>();
		String plantCode = "SP";
		listOfUnique.add(uniqueColumn);
		listOfUnique.add(uniqueColumn1);
		listOfUnique.add(uniqueColumn2);

		List<PlantEntity> list = new ArrayList<PlantEntity>();
		PlantEntity plantEntity = new PlantEntity();
		plantEntity.setPlantCode(plantCode);
		list.add(plantEntity);

		when(mockPlantRepository.findByPlantId(1)).thenReturn(list);

		when(mockFilterRepository.findByPlantCode(ArgumentMatchers.anyString())).thenReturn(listOfUnique);

	}

	@Test
	public void testGetAllFilters() {
		FilterDTO filterDTO = mockFilterServiceImpl.getAllFilters(1);

		Assertions.assertThat(filterDTO.getFilter().get("partNumber").get(0).getName()).isEqualTo("50842EZ00C");

	}

}
