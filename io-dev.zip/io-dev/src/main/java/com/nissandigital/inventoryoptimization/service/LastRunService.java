package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.PageDTO;
import com.nissandigital.inventoryoptimization.request.LastRunRequest;

/**
 * @author Nissan Digital
 *
 */

public interface LastRunService {

	/**
	 * Fetch last run details filtered by given service level
	 * 
	 * @return
	 */

	public PageDTO getPaginatedData(LastRunRequest lastRunRequest);

}
