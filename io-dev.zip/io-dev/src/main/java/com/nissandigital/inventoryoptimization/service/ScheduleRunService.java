package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;

public interface ScheduleRunService {
	ScheduleRunDTO findAllScheduleRun(ScheduleRunRequest request);
}
