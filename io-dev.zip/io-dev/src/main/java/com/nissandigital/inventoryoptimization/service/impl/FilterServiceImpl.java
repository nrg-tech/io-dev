package com.nissandigital.inventoryoptimization.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.FilterDTO;
import com.nissandigital.inventoryoptimization.dto.FilterValueDTO;
import com.nissandigital.inventoryoptimization.entity.UniqueColumnViewEntity;
import com.nissandigital.inventoryoptimization.repository.FilterRepository;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.service.FilterService;

@Service
public class FilterServiceImpl implements FilterService {

	@Autowired
	private PlantRepository plantRepository;

	@Autowired
	private FilterRepository filterRepository;

	@Override
	public FilterDTO getAllFilters(long plantId) {
		String plantCode = plantRepository.findByPlantId(plantId).get(0).getPlantCode();
		List<UniqueColumnViewEntity> columnViewEntities = filterRepository.findByPlantCode(plantCode);
		FilterDTO filterDTO = new FilterDTO();
		Map<String, List<FilterValueDTO>> filter = new HashMap<>();

		columnViewEntities.stream().forEach(w -> {
			setFilterDropdown(w, filter);
		});

		filterDTO.setFilter(filter);

		return filterDTO;

	}

	public void setFilterDropdown(UniqueColumnViewEntity columnViewEntity,
			Map<String, List<FilterValueDTO>> filter) {
		if (columnViewEntity == null) {
			return;
		}

		FilterValueDTO filterValueDTO = new FilterValueDTO();
		filterValueDTO.setId(columnViewEntity.getColumnValue());
		filterValueDTO.setName(columnViewEntity.getColumnValue());

		if (filter.containsKey(columnViewEntity.getColumnName())) {
			filter.get(columnViewEntity.getColumnName()).add(filterValueDTO);
		} else {
			List<FilterValueDTO> columnValuesList = new ArrayList<>();
			columnValuesList.add(filterValueDTO);
			filter.put(columnViewEntity.getColumnName(), columnValuesList);
		}
	}
}
