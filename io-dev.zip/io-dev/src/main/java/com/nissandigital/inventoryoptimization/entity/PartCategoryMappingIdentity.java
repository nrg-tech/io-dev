package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PartCategoryMappingIdentity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="PART_CATEGORY_ID")
	private long partCategoryId;

	@Column(name="SK_PART_ID")
	private long skPartId;
    
	public long getPartCategoryId() {
		return partCategoryId;
	}

	public void setPartCategoryId(long partCategoryId) {
		this.partCategoryId = partCategoryId;
	}

	public long getSkPartId() {
		return skPartId;
	}

	public void setSkPartId(long skPartId) {
		this.skPartId = skPartId;
	}

	
	public PartCategoryMappingIdentity(long partCategoryId, long skPartId) {
		super();
		this.partCategoryId = partCategoryId;
		this.skPartId = skPartId;
	}

	public PartCategoryMappingIdentity() {
	}

}
