package com.nissandigital.inventoryoptimization.common;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.AbstractMap;
import java.util.Map;

import com.nissandigital.inventoryoptimization.dto.Status;

/**
 * Contains utility methods used across parts details
 * 
 * @author Nissan Digital
 *
 */
public class InventoryOptimizationUtils {
	
	public static final Map<String, String> columnMap = Map.ofEntries(new AbstractMap.SimpleEntry<String, String>("analystCode", "analyst_cde"),
			new AbstractMap.SimpleEntry<String, String>("groupCode", "grp_cde"),
			new AbstractMap.SimpleEntry<String, String>("supplierCode", "suplr_code"),
			new AbstractMap.SimpleEntry<String, String>("partNumber", "item_num"),
			new AbstractMap.SimpleEntry<String, String>("dockId", "lccn_dck_id"),
			new AbstractMap.SimpleEntry<String, String>("shipFacility", "ship_facl_type_cd"),
			new AbstractMap.SimpleEntry<String, String>("orderOptionCode", "xdck_ord_opt_cde"),
			new AbstractMap.SimpleEntry<String, String>("crossDockSubsystem", "xdck_subsys_id"),
			new AbstractMap.SimpleEntry<String, String>("primaryLccnNumber", "primary_lccn_num"),
			new AbstractMap.SimpleEntry<String, String>("lastUsageMonth", "lst_req_dt"),
			new AbstractMap.SimpleEntry<String, String>("pkgDataL", "pkg_qty_lt"),
			new AbstractMap.SimpleEntry<String, String>("pkgDataH", "pkg_qty_ht"),
			new AbstractMap.SimpleEntry<String, String>("pkgDataW", "pkg_qty_wt"),
			new AbstractMap.SimpleEntry<String, String>("orderPointCalculationCode", "ordr_pnt_calc_cd"),
			new AbstractMap.SimpleEntry<String, String>("orderPointFactor1", "ordr_pnt_fctr_1_rt"),
			new AbstractMap.SimpleEntry<String, String>("rackCapacity", "rack_cpcty_qt"),
			new AbstractMap.SimpleEntry<String, String>("dzLocationType", "dz_loc_typ_cde"));

	/**
	 * Creates Response status with message
	 * 
	 * @param message
	 * @return Status
	 */
	public static Status setMessage(String message) {
		Status status = new Status();
		status.setMessage(message);
		return status;
	}

	/**
	 * Generate the current UTC Timestamp
	 * 
	 * @return Timestamp
	 */
	public static Timestamp getCurrentUTCTimestamp() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS ");
		ZonedDateTime utcZoned = ZonedDateTime.now(ZoneOffset.UTC);
		return Timestamp.valueOf(formatter.format(utcZoned));
	}
}
