package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class PartParamAllIdentity implements Serializable {

    @NotNull
    @Column(name = "sk_part_id")
    private Long skPartId;
    @NotNull
    @Column(name = "part_param_id")
    private Long partParamId;
    @NotNull
    @Column(name="param_start_dt")
    private Date startDate;
    @NotNull
    @Column(name = "param_end_dt")
    private Date endDate;

    public Long getPartId() {
        return skPartId;
    }

    public void setPartId(Long partId) {
        this.skPartId = partId;
    }

    public Long getPartParamId() {
        return partParamId;
    }

    public void setPartParamId(Long partParamId) {
        this.partParamId = partParamId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public PartParamAllIdentity() {
    }

    public PartParamAllIdentity(Long partId, Long partParamId, Date startDate, Date endDate) {
        this.skPartId = partId;
        this.partParamId = partParamId;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
