package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the io_part_param_all database table.
 * 
 */
@Entity
@Table(name="io_part_param_all",schema = "io_stat_model")
public class PartParamAllMappingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private PartParamAllIdentity partParamAllIdentity;

	@Column(name="created_by")
	private Long createdBy;

	@Column(name="created_dt")
	private Timestamp createdDt;

	@Column(name="part_param_val")
	private BigDecimal partParamVal;

	@Column(name="upd_dt")
	private Timestamp updatedAt;

	@Column(name="upd_by")
	private Long updatedBy;

	//bi-directional many-to-one association to IoDimPartsMaster
	@ManyToOne
	@JoinColumn(name="sk_part_id",insertable=false,updatable=false)
	private PartEntity ioDimPartsMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name="sk_part_id",updatable = false,insertable = false),
			@JoinColumn(name="user_id",updatable = false,insertable = false)
	})
	private UserPartsEntity ioUserParts;

	//bi-directional many-to-one association to PartParamEntity
	@ManyToOne
	@JoinColumn(name="part_param_id",updatable = false,insertable = false)
	private PartParamEntity partParamEntity;

	public PartParamAllMappingEntity() {
	}

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public BigDecimal getPartParamVal() {
		return this.partParamVal;
	}

	public void setPartParamVal(BigDecimal partParamVal) {
		this.partParamVal = partParamVal;
	}

	public Timestamp getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public PartEntity getIoDimPartsMaster() {
		return this.ioDimPartsMaster;
	}

	public void setIoDimPartsMaster(PartEntity ioDimPartsMaster) {
		this.ioDimPartsMaster = ioDimPartsMaster;
	}

	public PartParamEntity getPartParamEntity() {
		return this.partParamEntity;
	}

	public void setPartParamEntity(PartParamEntity partParamEntity) {
		this.partParamEntity = partParamEntity;
	}

	public PartParamAllIdentity getPartAndPartParamIdentity() {
		return partParamAllIdentity;
	}

	public void setPartAndPartParamIdentity(PartParamAllIdentity partParamAllIdentity) {
		this.partParamAllIdentity = partParamAllIdentity;
	}

	public UserPartsEntity getIoUserParts() {
		return ioUserParts;
	}

	public void setIoUserParts(UserPartsEntity ioUserParts) {
		this.ioUserParts = ioUserParts;
	}

	
}