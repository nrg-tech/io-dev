package com.nissandigital.inventoryoptimization.dto;

public class RecommendedFloatCurrentDTO {
	
	private Double floatRecommendedHoursCurrent;
	private Double floatRecommendedDaysCurrent;
	public Double getFloatRecommendedHoursCurrent() {
		return floatRecommendedHoursCurrent;
	}
	public void setFloatRecommendedHoursCurrent(Double floatRecommendedHoursCurrent) {
		this.floatRecommendedHoursCurrent = floatRecommendedHoursCurrent;
	}
	public Double getFloatRecommendedDaysCurrent() {
		return floatRecommendedDaysCurrent;
	}
	public void setFloatRecommendedDaysCurrent(Double floatRecommendedDaysCurrent) {
		this.floatRecommendedDaysCurrent = floatRecommendedDaysCurrent;
	}


	

}
