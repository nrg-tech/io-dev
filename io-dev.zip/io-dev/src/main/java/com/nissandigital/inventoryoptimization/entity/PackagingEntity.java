package com.nissandigital.inventoryoptimization.entity;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "io_dwh_dim_part_pkg", schema = "io_stat_model")

public class PackagingEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sk_part_pkg_id")
	private Long skPartPackageId;

	@Column(name = "load_dt")
	private Timestamp loadDate;

	@Column(name = "max_pkg_ver_num")
	private Double maximumPackageumber;

	@Temporal(TemporalType.DATE)
	@Column(name = "pkg_eff_dt")
	private Date packageEffectiveDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "pkg_expr_dt")
	private Date packageExpiryDate;

	@Column(name = "pkg_qty_ht")
	private Double packageQuantityHeight;

	@Column(name = "pkg_qty_lt")
	private Double packageQuantityLength;

	@Column(name = "pkg_qty_wt")
	private Double packageQuantityWeight;

	@Column(name = "pkg_tare_wgt")
	private Double packageWeight;

	@Column(name = "pkg_ver_num")
	private Double packageVersionNumber;

	@Column(name = "plant_id")
	private long plantId;

	@Column(name = "sk_part_id")
	private Long skPartId;

	@Column(name = "sk_suplr_id")
	private Long skSupplierId;

	public Long getSkPartPackageId() {
		return skPartPackageId;
	}

	public void setSkPartPackageId(Long skPartPackageId) {
		this.skPartPackageId = skPartPackageId;
	}

	public Timestamp getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Timestamp loadDate) {
		this.loadDate = loadDate;
	}

	public Double getMaximumPackageumber() {
		return maximumPackageumber;
	}

	public void setMaximumPackageumber(Double maximumPackageumber) {
		this.maximumPackageumber = maximumPackageumber;
	}

	public Date getPackageEffectiveDate() {
		return packageEffectiveDate;
	}

	public void setPackageEffectiveDate(Date packageEffectiveDate) {
		this.packageEffectiveDate = packageEffectiveDate;
	}

	public Date getPackageExpiryDate() {
		return packageExpiryDate;
	}

	public void setPackageExpiryDate(Date packageExpiryDate) {
		this.packageExpiryDate = packageExpiryDate;
	}

	public Double getPackageQuantityHeight() {
		return packageQuantityHeight;
	}

	public void setPackageQuantityHeight(Double packageQuantityHeight) {
		this.packageQuantityHeight = packageQuantityHeight;
	}

	public Double getPackageQuantityLength() {
		return packageQuantityLength;
	}

	public void setPackageQuantityLength(Double packageQuantityLength) {
		this.packageQuantityLength = packageQuantityLength;
	}

	public Double getPackageQuantityWeight() {
		return packageQuantityWeight;
	}

	public void setPackageQuantityWeight(Double packageQuantityWeight) {
		this.packageQuantityWeight = packageQuantityWeight;
	}

	public Double getPackageWeight() {
		return packageWeight;
	}

	public void setPackageWeight(Double packageWeight) {
		this.packageWeight = packageWeight;
	}

	public Double getPackageVersionNumber() {
		return packageVersionNumber;
	}

	public void setPackageVersionNumber(Double packageVersionNumber) {
		this.packageVersionNumber = packageVersionNumber;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public Long getSkPartId() {
		return skPartId;
	}

	public void setSkPartId(Long skPartId) {
		this.skPartId = skPartId;
	}

	public Long getSkSupplierId() {
		return skSupplierId;
	}

	public void setSkSupplierId(Long skSupplierId) {
		this.skSupplierId = skSupplierId;
	}

	@Override
	public String toString() {
		return "PackagingEntity [skPartPackageId=" + skPartPackageId + ", loadDate=" + loadDate
				+ ", maximumPackageumber=" + maximumPackageumber + ", packageEffectiveDate=" + packageEffectiveDate
				+ ", packageExpiryDate=" + packageExpiryDate + ", packageQuantityHeight=" + packageQuantityHeight
				+ ", packageQuantityLength=" + packageQuantityLength + ", packageQuantityWeight="
				+ packageQuantityWeight + ", packageWeight=" + packageWeight + ", packageVersionNumber="
				+ packageVersionNumber + ", plantId=" + plantId + ", skPartId=" + skPartId + ", skSupplierId="
				+ skSupplierId + "]";
	}

}
