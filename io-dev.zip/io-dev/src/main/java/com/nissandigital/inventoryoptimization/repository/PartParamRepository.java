package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nissandigital.inventoryoptimization.entity.PartParamEntity;

public interface PartParamRepository extends JpaRepository<PartParamEntity, Long> {

	List<PartParamEntity> findAllByPlantId(Long plantId);

}
