package com.nissandigital.inventoryoptimization.entity;

public class ScheduledRunPartsDetailsEntity {

	private String itemNumber;

	private long plant_id;

	private String plantCode;

	private long partId;

	private Double serviceLevel;

	private String analystCode;

	private String supplierCode;

	private String dockId;

	private String pickToBroadcastIndicator;

	private String kitIndicator;

	private String subAssembledIndicator;

	private String ilcDirectIndicator;

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the plant_id
	 */
	public long getPlant_id() {
		return plant_id;
	}

	/**
	 * @param plant_id the plant_id to set
	 */
	public void setPlant_id(long plantId) {
		this.plant_id = plantId;
	}

	/**
	 * @return the plantCode
	 */
	public String getPlantCode() {
		return plantCode;
	}

	/**
	 * @param plantCode the plantCode to set
	 */
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	/**
	 * @return the partId
	 */
	public long getPartId() {
		return partId;
	}

	/**
	 * @param partId the partId to set
	 */
	public void setPartId(long partId) {
		this.partId = partId;
	}

	/**
	 * @return the serviceLevel
	 */
	public Double getServiceLevel() {
		return serviceLevel;
	}

	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Double serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	/**
	 * @return the analystCode
	 */
	public String getAnalystCode() {
		return analystCode;
	}

	/**
	 * @param analystCode the analystCode to set
	 */
	public void setAnalystCode(String analystCode) {
		this.analystCode = analystCode;
	}

	/**
	 * @return the supplierCode
	 */
	public String getSupplierCode() {
		return supplierCode;
	}

	/**
	 * @param supplierCode the supplierCode to set
	 */
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	/**
	 * @return the dockId
	 */
	public String getDockId() {
		return dockId;
	}

	/**
	 * @param dockId the dockId to set
	 */
	public void setDockId(String dockId) {
		this.dockId = dockId;
	}

	/**
	 * @return the pickToBroadcastIndicator
	 */
	public String getPickToBroadcastIndicator() {
		return (pickToBroadcastIndicator==null)?"No":"Yes";
	}

	/**
	 * @param pickToBroadcastIndicator the pickToBroadcastIndicator to set
	 */
	public void setPickToBroadcastIndicator(String pickToBroadcastIndicator) {
		this.pickToBroadcastIndicator = pickToBroadcastIndicator;
	}

	/**
	 * @return the kitIndicator
	 */
	public String getKitIndicator() {
		return (kitIndicator==null)?"No":"Yes";
	}

	/**
	 * @param kitIndicator the kitIndicator to set
	 */
	public void setKitIndicator(String kitIndicator) {
		this.kitIndicator = kitIndicator;
	}

	/**
	 * @return the subAssembledIndicator
	 */
	public String getSubAssembledIndicator() {
		return (subAssembledIndicator==null)?"No":"Yes";
	}

	/**
	 * @param subAssembledIndicator the subAssembledIndicator to set
	 */
	public void setSubAssembledIndicator(String subAssembledIndicator) {
		this.subAssembledIndicator = subAssembledIndicator;
	}

	/**
	 * @return the ilcDirectIndicator
	 */
	public String getIlcDirectIndicator() {
		return ilcDirectIndicator;
	}

	/**
	 * @param ilcDirectIndicator the ilcDirectIndicator to set
	 */
	public void setIlcDirectIndicator(String ilcDirectIndicator) {
		this.ilcDirectIndicator = ilcDirectIndicator;
	}

	public ScheduledRunPartsDetailsEntity(String itemNumber, long plantId, String plantCode, long partId,
			Double serviceLevel, String analystCode, String supplierCode, String dockId,
			String pickToBroadcastIndicator, String kitIndicator, String subAssembledIndicator,
			String ilcDirectIndicator) {
		this.itemNumber = itemNumber;
		this.plant_id = plantId;
		this.plantCode = plantCode;
		this.partId = partId;
		this.serviceLevel = serviceLevel;
		this.analystCode = analystCode;
		this.supplierCode = supplierCode;
		this.dockId = dockId;
		this.pickToBroadcastIndicator = pickToBroadcastIndicator;
		this.kitIndicator = kitIndicator;
		this.subAssembledIndicator = subAssembledIndicator;
		this.ilcDirectIndicator = ilcDirectIndicator;
	}	
}
