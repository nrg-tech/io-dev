package com.nissandigital.inventoryoptimization.dto;

import java.util.Date;

/**
 * DTO class containing Aggregate statistics
 * 
 * @author Nissan Digital
 *
 */
public class AggregateStatisticsDTO {

	private Integer plantId;

	private Double currentInventoryBaseline;

	private Double currentInventoryBaselineDifference;

	private Double currentSafetyStock;

	private Double currentSafetyStockDifference;

	private Integer stockKeepingUnit;

	private Double surplusSafetyStock;

	private Double surplusSafetyStockDifference;

	private Date modelExecutionDate;

	/**
	 * @return the modelExecutionDate
	 */
	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	/**
	 * @param modelExecutionDate the modelExecutionDate to set
	 */
	
	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	/**
	 * @return the plantId
	 */
	public Integer getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(Integer id) {
		this.plantId = id;
	}

	/**
	 * @return the currentInventoryBaseline
	 */
	public Double getCurrentInventoryBaseline() {
		return currentInventoryBaseline;
	}

	/**
	 * @param currentInventoryBaseline the currentInventoryBaseline to set
	 */
	public void setCurrentInventoryBaseline(Double currInvBsl) {
		this.currentInventoryBaseline = currInvBsl;
	}

	/**
	 * @return the currentInventoryBaselineDifference
	 */
	public Double getCurrentInventoryBaselineDifference() {
		return currentInventoryBaselineDifference;
	}

	/**
	 * @param currentInventoryBaselineDifference the
	 *                                           currentInventoryBaselineDifference
	 *                                           to set
	 */
	public void setCurrentInventoryBaselineDifference(Double currInvBslDiff) {
		this.currentInventoryBaselineDifference = currInvBslDiff;
	}

	/**
	 * @return the currentSafetyStock
	 */
	public Double getCurrentSafetyStock() {
		return currentSafetyStock;
	}

	/**
	 * @param currentSafetyStock the currentSafetyStock to set
	 */
	public void setCurrentSafetyStock(Double currSafetyStock) {
		this.currentSafetyStock = currSafetyStock;
	}

	/**
	 * @return the currentSafetyStockDifference
	 */
	public Double getCurrentSafetyStockDifference() {
		return currentSafetyStockDifference;
	}

	/**
	 * @param currentSafetyStockDifference the currentSafetyStockDifference to set
	 */
	public void setCurrentSafetyStockDifference(Double currSafetyStockDiff) {
		this.currentSafetyStockDifference = currSafetyStockDiff;
	}

	/**
	 * @return the stockKeepingUnit
	 */
	public Integer getStockKeepingUnit() {
		return stockKeepingUnit;
	}

	/**
	 * @param stockKeepingUnit the stockKeepingUnit to set
	 */
	public void setStockKeepingUnit(Integer stockKeepingUnit) {
		this.stockKeepingUnit = stockKeepingUnit;
	}

	/**
	 * @return the surplusSafetyStock
	 */
	public Double getSurplusSafetyStock() {
		return surplusSafetyStock;
	}

	/**
	 * @param surplusSafetyStock the surplusSafetyStock to set
	 */
	public void setSurplusSafetyStock(Double surplSafetyStock) {
		this.surplusSafetyStock = surplSafetyStock;
	}

	/**
	 * @return the surplusSafetyStockDifference
	 */
	public Double getSurplusSafetyStockDifference() {
		return surplusSafetyStockDifference;
	}

	/**
	 * @param surplusSafetyStockDifference the surplusSafetyStockDifference to set
	 */
	public void setSurplusSafetyStockDifference(Double surplSafetyStockDiff) {
		this.surplusSafetyStockDifference = surplSafetyStockDiff;
	}

}
