package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "io_v_uniq_col_values", schema = "io_stat_model")
@IdClass(UniqueColumnViewIdentity.class)
public class UniqueColumnViewEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "plant_code")
	private String plantCode;

	@Id
	@Column(name = "col_name")
	private String columnName;

	@Id
	@Column(name = "col_val")
	private String columnValue;

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnValue() {
		return columnValue;
	}

	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}

	@Override
	public String toString() {
		return "UniqueColumnViewEntity [plantCode=" + plantCode + ", columnName=" + columnName + ", columnValue="
				+ columnValue + "]";
	}

}
