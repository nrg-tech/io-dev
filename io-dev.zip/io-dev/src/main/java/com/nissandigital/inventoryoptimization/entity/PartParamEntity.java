package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the io_part_param_master database table.
 * 
 */
@Entity
@Table(name="io_part_param_master",schema="io_stat_model")
public class PartParamEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="part_param_id")
	private Long partParamId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_dt")
	private Timestamp createdDt;

	@Column(name="part_param_desc")
	private String partParamDesc;

	@Column(name="plant_id")
	private long plantId;

	@Column(name="upd_dt")
	private Timestamp updatedAt;

	@Column(name="upd_by")
	private String updatedBy;
	
	@Column(name="part_param_type")
	private String partParamType;

	//bi-directional many-to-one association to PartParamAllMappingEntity
	@OneToMany(mappedBy="partParamEntity")
	private List<PartParamAllMappingEntity> partParamAllMappingEntities;

	//bi-directional many-to-one association to PartParamCurrMappingEntity
	@OneToMany(mappedBy="partParamEntity")
	private List<PartParamCurrMappingEntity> partParamCurrMappingEntities;

	public PartParamEntity() {
	}
	
	

	public String getPartParamType() {
		return partParamType;
	}



	public void setPartParamType(String partParamType) {
		this.partParamType = partParamType;
	}



	public Long getPartParamId() {
		return this.partParamId;
	}

	public void setPartParamId(Long partParamId) {
		this.partParamId = partParamId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public String getPartParamDesc() {
		return this.partParamDesc;
	}

	public void setPartParamDesc(String partParamDesc) {
		this.partParamDesc = partParamDesc;
	}

	public long getPlantCd() {
		return this.plantId;
	}

	public void setPlantCd(long plantCd) {
		this.plantId = plantId;
	}

	public Timestamp getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<PartParamAllMappingEntity> getPartParamAllMappingEntities() {
		return this.partParamAllMappingEntities;
	}

	public void setPartParamAllMappingEntities(List<PartParamAllMappingEntity> partParamAllMappingEntities) {
		this.partParamAllMappingEntities = partParamAllMappingEntities;
	}

	public PartParamAllMappingEntity addIoPartParamAll(PartParamAllMappingEntity partParamAllMappingEntity) {
		getPartParamAllMappingEntities().add(partParamAllMappingEntity);
		partParamAllMappingEntity.setPartParamEntity(this);

		return partParamAllMappingEntity;
	}

	public PartParamAllMappingEntity removeIoPartParamAll(PartParamAllMappingEntity partParamAllMappingEntity) {
		getPartParamAllMappingEntities().remove(partParamAllMappingEntity);
		partParamAllMappingEntity.setPartParamEntity(null);

		return partParamAllMappingEntity;
	}

	public List<PartParamCurrMappingEntity> getPartParamCurrMappingEntities() {
		return this.partParamCurrMappingEntities;
	}

	public void setPartParamCurrMappingEntities(List<PartParamCurrMappingEntity> partParamCurrMappingEntities) {
		this.partParamCurrMappingEntities = partParamCurrMappingEntities;
	}

	public PartParamCurrMappingEntity addIoPartParamCurr(PartParamCurrMappingEntity partParamCurrMappingEntity) {
		getPartParamCurrMappingEntities().add(partParamCurrMappingEntity);
		partParamCurrMappingEntity.setPartParamEntity(this);

		return partParamCurrMappingEntity;
	}

	public PartParamCurrMappingEntity removeIoPartParamCurr(PartParamCurrMappingEntity partParamCurrMappingEntity) {
		getPartParamCurrMappingEntities().remove(partParamCurrMappingEntity);
		partParamCurrMappingEntity.setPartParamEntity(null);

		return partParamCurrMappingEntity;
	}

}