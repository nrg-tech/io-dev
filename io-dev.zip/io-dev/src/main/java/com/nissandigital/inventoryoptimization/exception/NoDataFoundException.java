package com.nissandigital.inventoryoptimization.exception;

public class NoDataFoundException extends RuntimeException {

	private static final long serialVersionUID = -3417045467255177922L;

	public NoDataFoundException() {
		super();
	}

	public NoDataFoundException(String msg) {
		super(msg);
	}
}