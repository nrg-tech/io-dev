package com.nissandigital.inventoryoptimization.dto;

/**
 * DTO class containing Demand variability contribution
 * 
 * @author Nissan Digital
 *
 */
public class DemandVariabilityContributionDTO {

	private String itemNumber;
	private double averageDailyDemand;
	private double coefVariableDailyDemand;

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the averageDailyDemand
	 */
	public double getAverageDailyDemand() {
		return averageDailyDemand;
	}

	/**
	 * @param averageDailyDemand the averageDailyDemand to set
	 */
	public void setAverageDailyDemand(double avgDlyDem) {
		this.averageDailyDemand = avgDlyDem;
	}

	/**
	 * @return the coefVariableDailyDemand
	 */
	public double getCoefVariableDailyDemand() {
		return coefVariableDailyDemand;
	}

	/**
	 * @param coefVariableDailyDemand the coefVariableDailyDemand to set
	 */
	public void setCoefVariableDailyDemand(double covVarDlyDem) {
		this.coefVariableDailyDemand = covVarDlyDem;
	}

}
