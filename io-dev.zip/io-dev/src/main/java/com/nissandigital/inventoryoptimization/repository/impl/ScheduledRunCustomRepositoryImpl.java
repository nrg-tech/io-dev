package com.nissandigital.inventoryoptimization.repository.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.PartResponseDTO;
import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.entity.PartParamCurrMappingEntity;
import com.nissandigital.inventoryoptimization.entity.ScheduledRunPartsDetailsEntity;
import com.nissandigital.inventoryoptimization.enums.FilterTypeEnum;
import com.nissandigital.inventoryoptimization.exception.ValidationException;
import com.nissandigital.inventoryoptimization.repository.LastRunRepository;
import com.nissandigital.inventoryoptimization.repository.PartParamCurrRepository;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.repository.ScheduledRunCustomRepository;
import com.nissandigital.inventoryoptimization.request.FilterRequest;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;

@Component
public class ScheduledRunCustomRepositoryImpl implements ScheduledRunCustomRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PartParamCurrRepository partParamCurrRepository;
	
	@Override
	public ScheduleRunDTO findByFilteredParts(ScheduleRunRequest request) {
		String query = "SELECT part.plant_id,part.plant_cd,part.sk_part_id,part.item_num,mview.service_level,mview.analyst_cde,"
				+ "mview.lccn_dck_id,mview.pick_brod_ind,mview.kit_ind,mview.sub_asmbld_ind,mview.part_type_cd,mview.suplr_code "
				+ "FROM (SELECT t1.plant_id,sk_part_id,plant_cd,item_num FROM io_stat_model.io_plant_master AS t1 Inner Join "
				+ "io_stat_model.io_dwh_dim_parts_master AS t2 on t1.plant_id=t2.plant_id) as part inner join io_stat_model.io_mv_sm_op_curr"
				+ " as mview on part.plant_cd=mview.plant_cd AND part.item_num=mview.item_num";
		
		ScheduleRunDTO response = new ScheduleRunDTO();
		String condition = generateQueryCondition(request.getFilters(),request.getPlantId());
		response.setTotalFilteredRows(findTotalCountOfFilteredData(condition));
		query += condition+" ORDER BY part.item_num OFFSET "+ ((request.getPageNumber() - 1) * request.getPageSize()) + " LIMIT " + request.getPageSize();
		List<Object[]> result = entityManager.createNativeQuery(query).getResultList();
		List<ScheduledRunPartsDetailsEntity> parts = result.stream().map(record->{
			return new ScheduledRunPartsDetailsEntity(
				(String)record[3], 
				((BigInteger)record[0]).longValue(),        
				(String)record[1],
				((BigInteger)record[2]).longValue(),
				((BigDecimal)record[4]).doubleValue(),
				(String)record[5],
				(String)record[11],
				(String)record[6],
				(String)record[7],
				(String)record[8],
				(String)record[9],
				(String)record[10]);
		}).collect(Collectors.toList());		
		List<Long> partIds = parts.stream().map(w -> w.getPartId()).collect(Collectors.toList());
		List<PartParamCurrMappingEntity> partList = partParamCurrRepository
				.findByPartParamIdentityEffectDtAndPartParamEntityPlantIdAndDimPartsMasterPartIdIn(request.getDate(),
						request.getPlantId(), partIds);
		List<PartResponseDTO> partsResponse = parts.stream().map(w -> {
			PartResponseDTO partResponse = modelMapper.map(w, PartResponseDTO.class);
			partResponse.setOffsets(partList.stream().filter(s -> s.getDimPartsMaster().getPartId() == w.getPartId())
					.collect(Collectors.toMap(PartParamCurrMappingEntity::getPartParamId,
							PartParamCurrMappingEntity::getPartParamVal)));
			return partResponse;
		}).collect(Collectors.toList());
		response.setParts(partsResponse);		
		return response;
	}
	@Override
	public Long findTotalCountOfFilteredData(String condition) {
		String query = "SELECT Count(*) FROM (SELECT t1.plant_id,sk_part_id,plant_cd,item_num FROM io_stat_model.io_plant_master AS t1 "
				+ "Inner Join io_stat_model.io_dwh_dim_parts_master AS t2 on t1.plant_id=t2.plant_id) as part inner join "
				+ "io_stat_model.io_mv_sm_op_curr as mview on part.plant_cd=mview.plant_cd AND part.item_num=mview.item_num" + condition;
		return Long.parseLong(entityManager.createNativeQuery(query).getResultList().get(0).toString());
	}
	@Override
	public List<Long> findPartIdWithFilters(Map<String, FilterRequest> filters, long plantId) {
		String query = "SELECT sk_part_id FROM (SELECT t1.plant_id,sk_part_id,plant_cd,item_num FROM io_stat_model.io_plant_master AS t1 "
				+ "Inner Join io_stat_model.io_dwh_dim_parts_master AS t2 on t1.plant_id=t2.plant_id) as part inner join "
				+ "io_stat_model.io_mv_sm_op_curr as mview on part.plant_cd=mview.plant_cd AND part.item_num=mview.item_num"
				+ generateQueryCondition(filters,plantId);
		List<Long> result = entityManager.createNativeQuery(query).getResultList();
		return result;
	}
	
	public String generateQueryCondition(Map<String, FilterRequest> filters, long plantId) {
		StringBuilder query = new StringBuilder(" where plant_id=" + plantId);
		if (filters != null) {
			String s = filters.entrySet().stream().map(w -> generateQuery(w)).collect(Collectors.joining());
			query.append(s);
		}
		return query.toString();
	}

	private StringBuilder generateQuery(Entry<String, FilterRequest> filters) {
		StringBuilder query = new StringBuilder();

		if (filters.getValue().getType() == FilterTypeEnum.LIST) {
			query.append(" AND " + entityTableNameMapping(filters.getKey()) + " IN "
					+ convertList(filters.getValue().getValues(), filters.getValue().getValuesType()));
		} else if (filters.getValue().getType() == FilterTypeEnum.RANGE) {
			query.append(" AND " + entityTableNameMapping(filters.getKey()) + " BETWEEN " + filters.getValue().getMin()
					+ " AND " + filters.getValue().getMax());
		} else {
			throw new ValidationException("Incorrect type information");
		}
		return query;

	}

	private String convertList(List<?> data, String type) {
		StringBuilder query = new StringBuilder("(");
		int size = data.size();

		for (int i = 1; i <= size; i++) {
			if (i != 1) {
				query.append(",");
			}
			if (type.equalsIgnoreCase("numeric")) {
				query.append(data.get(i - 1));
			} else {
				query.append("'" + data.get(i - 1) + "'");
			}
		}
		query.append(")");
		return query.toString();
	}

	private String entityTableNameMapping(String tableColumn) {
		return InventoryOptimizationUtils.columnMap.getOrDefault(tableColumn, null);
	}
}
