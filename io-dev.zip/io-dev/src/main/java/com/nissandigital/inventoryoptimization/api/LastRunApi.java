package com.nissandigital.inventoryoptimization.api;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.PageDTO;
import com.nissandigital.inventoryoptimization.request.LastRunRequest;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Api specification for Last Run Table details
 * 
 * @author Nissan Digital
 *
 */
@RequestMapping(value = "last-run")
public interface LastRunApi {

	@ApiOperation(value = "Returns last run details by page number", nickname = "getAllLastRunDetails", notes = "Returns last run details by page number", response = PageDTO.class, responseContainer = "List", tags = {
			"LastRun" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Detail of last run details by page number", response = PageDTO.class, responseContainer = "List") })
	@PostMapping(produces = { "application/json" })
	ResponseEntity<PageDTO> getLastRunDetails(
			@ApiParam(value = "Get Paginated data", required = true) @Valid @RequestBody LastRunRequest lastRunRequest);

}
