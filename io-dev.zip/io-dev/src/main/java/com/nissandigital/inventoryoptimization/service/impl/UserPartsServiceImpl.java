package com.nissandigital.inventoryoptimization.service.impl;

import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.UserPartsDTO;
import com.nissandigital.inventoryoptimization.entity.UserPartsEntity;
import com.nissandigital.inventoryoptimization.entity.UserPartsIdentity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.repository.UserPartsRepository;
import com.nissandigital.inventoryoptimization.repository.UserRepository;
import com.nissandigital.inventoryoptimization.service.UserPartsService;
import com.nissandigital.inventoryoptimization.service.UserService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserPartsServiceImpl implements UserPartsService {
	@Autowired
	UserPartsRepository userPartsRepository;
	@Autowired
	PartRepository partRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	UserService userService;
	

	@Override
	public void addPartsToPartsController(UserPartsDTO userPartsDTO) {
		List<Integer> partIds = userPartsDTO.getPartIds();
		int userId = userPartsDTO.getUserId();
		validateUser(userId);
		List<UserPartsEntity> userPartsEntityList = convertUserPartsDTOToEntity(userId, partIds);
		userPartsRepository.saveAll(userPartsEntityList);
	}

	private List<UserPartsEntity> convertUserPartsDTOToEntity(int userId, List<Integer> partIds) {
		List<UserPartsEntity> userPartsEntityList = partIds.stream().map(partId -> {
			UserPartsEntity userPartsEntity = new UserPartsEntity();
			UserPartsIdentity userPartsIdentity = new UserPartsIdentity();
			userPartsIdentity.setPartId(partId);
			userPartsIdentity.setUserId(userId);
			userPartsEntity.setUserPartsIdentity(userPartsIdentity);
			userPartsEntity.setCreatedBy(userService.getCurrentUser().getUserId());
			userPartsEntity.setCreatedDt(InventoryOptimizationUtils.getCurrentUTCTimestamp());
			userPartsEntity.setUpdatedBy(userService.getCurrentUser().getUserId());
			userPartsEntity.setUpdatedDt(InventoryOptimizationUtils.getCurrentUTCTimestamp());
			return userPartsEntity;
		}).collect(Collectors.toList());
		return userPartsEntityList;
	}

	void validateUser(long userId) {
		boolean userExists = userRepository.existsById(new Long(userId));
		if (!userExists) {
			String error = String.format("User not found with id %s", userId);
			throw new NoDataFoundException(error);
		}

	}

}
