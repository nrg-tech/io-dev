package com.nissandigital.inventoryoptimization.dto;

/**
 * DTO class containing top part statistics overview
 * 
 * @author Nissan Digital
 *
 */
public class TopPartsStatisticsOverviewDTO {

	private String itemNumber;
	private double currentFloat;
	private double floatSurplus;
	private double recommendedFloat;

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the currentFloat
	 */
	public double getCurrentFloat() {
		return currentFloat;
	}

	/**
	 * @param currentFloat the currentFloat to set
	 */
	public void setCurrentFloat(double currentFloat) {
		this.currentFloat = currentFloat;
	}

	/**
	 * @return the floatSurplus
	 */
	public double getFloatSurplus() {
		return floatSurplus;
	}

	/**
	 * @param floatSurplus the floatSurplus to set
	 */
	public void setFloatSurplus(double floatSurplus) {
		this.floatSurplus = floatSurplus;
	}

	/**
	 * @return the recommendedFloat
	 */
	public double getRecommendedFloat() {
		return recommendedFloat;
	}

	/**
	 * @param recommendedFloat the recommendedFloat to set
	 */
	public void setRecommendedFloat(double recomFloat) {
		this.recommendedFloat = recomFloat;
	}

}
