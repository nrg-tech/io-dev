package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nissandigital.inventoryoptimization.entity.PartEntity;

/**
 * Repository class for performing database operations on Part entity
 * 
 * @author Nissan Digital
 *
 */
public interface PartRepository extends JpaRepository<PartEntity, Long>{
	List<PartEntity> findByPartIdIn(List<Long> partIdList);
	
	@Query(value = "SELECT ipc.partId FROM PartEntity ipc where ipc.plantId = :plantId")
	List<Long> findPartIdByPlantId(long plantId);

	PartEntity findByPartId(long partId);

	List<PartEntity> findByPlantId(long plantId);
	
	@Query(value = "SELECT Count(*)	FROM io_stat_model.io_dwh_dim_parts_master where plant_id=:plantId",nativeQuery = true)
	long findCountByPlantId(long plantId);

}
