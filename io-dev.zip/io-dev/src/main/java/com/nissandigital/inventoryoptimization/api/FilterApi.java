package com.nissandigital.inventoryoptimization.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.FilterDTO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;

@RequestMapping(value = "filters")
public interface FilterApi {
	
	@ApiOperation(value = "Fetch the list of all the filters", nickname = "getFiltersList", notes = "Returns the information of all the filters ", response = FilterDTO.class, tags = {
	"filters" })
	@ApiResponse(code = 200, message = "Information of all the filters", response = FilterDTO.class)
	@GetMapping(value= "/{plantId}",produces = { "application/json" })
ResponseEntity<FilterDTO> getFilters(
		@ApiParam(value = "All filters list", required= true) @PathVariable("plantId") long plantId);

}
