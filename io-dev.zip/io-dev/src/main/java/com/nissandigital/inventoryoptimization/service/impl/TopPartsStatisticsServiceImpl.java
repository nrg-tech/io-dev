package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.DemandVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.SupplyVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.TopPartsStatisticsOverviewDTO;
import com.nissandigital.inventoryoptimization.entity.StatisticalMVTopPartsEntity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.repository.StatisticalMVTopPartsRepository;
import com.nissandigital.inventoryoptimization.service.TopPartsStatisticsService;
import com.nissandigital.inventoryoptimization.service.UserService;

/**
 * Implementation class for top parts statistics service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class TopPartsStatisticsServiceImpl implements TopPartsStatisticsService {

	@Autowired
	UserService userService;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	StatisticalMVTopPartsRepository topPartsRepository;

	@Override
	public List<DemandVariabilityContributionDTO> getDemandVariabilityContribution() {
		long plantId = userService.getCurrentUser().getPlantId();
		List<StatisticalMVTopPartsEntity> statList = topPartsRepository.findAllByPlantId(plantId);
		if (statList.isEmpty()) {
			throw new NoDataFoundException("Top Parts data not found for plant id " + plantId);			
		}
		return statList.stream().map(w -> modelMapper.map(w, DemandVariabilityContributionDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<SupplyVariabilityContributionDTO> getSupplyVariabilityContribution() {
		long plantId = userService.getCurrentUser().getPlantId();
		List<StatisticalMVTopPartsEntity> statList = topPartsRepository.findAllByPlantId(plantId);
		if (statList.isEmpty()) {
			throw new NoDataFoundException("Top Parts data not found for plant id " + plantId);			
		}
		return statList.stream().map(w -> modelMapper.map(w, SupplyVariabilityContributionDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<TopPartsStatisticsOverviewDTO> getTopPartsOverviewDto() {
		long plantId = userService.getCurrentUser().getPlantId();
		List<StatisticalMVTopPartsEntity> statList = topPartsRepository.findAllByPlantId(plantId);
		if (statList.isEmpty()) {
			throw new NoDataFoundException("Top Parts data not found for plant id " + plantId);			
		}
		return statList.stream().map(w -> modelMapper.map(w, TopPartsStatisticsOverviewDTO.class))
				.collect(Collectors.toList());
	}
}
