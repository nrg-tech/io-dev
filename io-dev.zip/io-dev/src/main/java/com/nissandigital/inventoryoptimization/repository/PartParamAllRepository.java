package com.nissandigital.inventoryoptimization.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nissandigital.inventoryoptimization.entity.PartParamAllIdentity;
import com.nissandigital.inventoryoptimization.entity.PartParamAllMappingEntity;

public interface PartParamAllRepository extends JpaRepository<PartParamAllMappingEntity, PartParamAllIdentity>{

}
