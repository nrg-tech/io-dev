package com.nissandigital.inventoryoptimization.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.PartCategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartDetailsDTO;
import com.nissandigital.inventoryoptimization.dto.PartsCategoryMappingDTO;
import com.nissandigital.inventoryoptimization.entity.PartCategoryEntity;
import com.nissandigital.inventoryoptimization.entity.PartCategoryMappingEntity;
import com.nissandigital.inventoryoptimization.entity.PartCategoryMappingIdentity;
import com.nissandigital.inventoryoptimization.entity.PartEntity;
import com.nissandigital.inventoryoptimization.entity.SupplierAddressBookEntity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.repository.PartCategoryRepository;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.repository.PartsCategoryMappingRepository;
import com.nissandigital.inventoryoptimization.repository.SupplierPartsRepository;
import com.nissandigital.inventoryoptimization.repository.SupplierRepository;
import com.nissandigital.inventoryoptimization.repository.UserPartsRepository;
import com.nissandigital.inventoryoptimization.service.PartCategoryService;
import com.nissandigital.inventoryoptimization.service.UserService;

@Service
public class PartCategoryServiceImpl implements PartCategoryService {

	@Autowired
	PartsCategoryMappingRepository partCategoryMappingRepository;

	@Autowired
	PartRepository partRepository;

	@Autowired
	SupplierPartsRepository supplierPartsRepository;

	@Autowired
	UserPartsRepository userPartsRepository;

	@Autowired
	SupplierRepository supplierRepository;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PartCategoryRepository partCategoryRepository;

	@Autowired
	UserService userService;

	@Override
	public void addPartsToPartsCategory(PartsCategoryMappingDTO partsCategoryDTO) {
		List<Long> partIds = partsCategoryDTO.getPartIds();
		Long categoryId = partsCategoryDTO.getCategoryId();
		validateCategory(categoryId);
		List<PartCategoryMappingEntity> partCategoryEntityList = convertPartCategoryMappingDTOToEntity(categoryId,
				partIds);
		partCategoryMappingRepository.saveAll(partCategoryEntityList);

	}

	@Override
	public void addPartsCategory(PartCategoryDTO partCategoryDTO) {
		long categoryId = partCategoryDTO.getCategoryId();
		long plantId = partCategoryDTO.getPlantId();
		if (categoryId == 0) {
			String error = String.format("Part Category id cannot be empty");
			throw new NoDataFoundException(error);
		}
		if (plantId == 0) {
			String error = String.format("Plant Code cannot be empty");
			throw new NoDataFoundException(error);
		}
		PartCategoryEntity partCategoryMasterEntity = convertPartCategoryDTOToEntity(partCategoryDTO);
		partCategoryRepository.save(partCategoryMasterEntity);

	}

	private List<PartCategoryMappingEntity> convertPartCategoryMappingDTOToEntity(Long categoryId, List<Long> partIds) {
		List<PartCategoryMappingEntity> partCategoryEntityList = partIds.stream().map(partId -> {
			PartCategoryMappingEntity partCategoryMappingEntity = new PartCategoryMappingEntity();
			PartCategoryMappingIdentity partCategoryMappingIdentity = new PartCategoryMappingIdentity();
			partCategoryMappingIdentity.setSkPartId(partId);
			partCategoryMappingIdentity.setPartCategoryId(categoryId);
			partCategoryMappingEntity.setPartCategoryMappingIdentity(partCategoryMappingIdentity);
			partCategoryMappingEntity.setCreatedBy(userService.getCurrentUser().getUserId());
			partCategoryMappingEntity.setCreatedDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());
			partCategoryMappingEntity.setUpdatedBy(userService.getCurrentUser().getUserId());
			partCategoryMappingEntity.setUpdatedDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());

			return partCategoryMappingEntity;
		}).collect(Collectors.toList());
		return partCategoryEntityList;
	}

	private PartCategoryEntity convertPartCategoryDTOToEntity(PartCategoryDTO partCategory) {
		PartCategoryEntity partCategoryMasterEntity = modelMapper.map(partCategory, PartCategoryEntity.class);
		partCategoryMasterEntity.setPlantId(partCategory.getPlantId());
		partCategoryMasterEntity.setCreatedBy(userService.getCurrentUser().getUserId());
		partCategoryMasterEntity.setUpdatedBy(userService.getCurrentUser().getUserId());
		partCategoryMasterEntity.setCreatedDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());
		partCategoryMasterEntity.setUpdatedDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());
		return partCategoryMasterEntity;
	}

	void validateCategory(long categoryId) {
		if (categoryId == 0) {
			String error = String.format("Part Category id cannot be empty");
			throw new NoDataFoundException(error);
		}
		boolean partCategoryExists = partCategoryRepository.existsById(categoryId);
		if (!partCategoryExists) {
			String error = String.format("Part Category is not found with id %s", categoryId);
			throw new NoDataFoundException(error);
		}
	}


	@Override
	public List<PartDetailsDTO> findPartsByCategory(long categoryId) {
		List<Long> partIds = partCategoryMappingRepository.findPartsByPartCategoryId(categoryId);
		List<PartEntity> partDetails = partRepository.findByPartIdIn(partIds);
		List<Long> supplierIds = supplierPartsRepository.findSupplierIdsForPartIds(partIds);
		List<SupplierAddressBookEntity> supplierDetails = supplierRepository.findBySkSupplierIdIn(supplierIds);
		List<Long> userIds = userPartsRepository.findPartsControllerInfoByPartIds(partIds);
		List<PartDetailsDTO> categoryDetailsDTOlist = convertEntityToPartDetailsDTO(supplierDetails, userIds,
				partDetails, partIds.size());
		return categoryDetailsDTOlist;
	}

	private List<PartDetailsDTO> convertEntityToPartDetailsDTO(List<SupplierAddressBookEntity> supplierDetails,
			List<Long> userIds, List<PartEntity> partDetails, int listSize) {
		List<PartDetailsDTO> list = new ArrayList<>();
		for (int i = 0; i < listSize; i++) {
			PartDetailsDTO partDetailsDTO = new PartDetailsDTO();
			if (i < partDetails.size()) {
				partDetailsDTO.setPartNumber(partDetails.get(i).getItemNumber());
				partDetailsDTO.setPartDescription(partDetails.get(i).getItemDescription());
				partDetailsDTO.setPartTypeCode(partDetails.get(i).getPartTypeCode());
			}
			if (i < supplierDetails.size()) {
				partDetailsDTO.setSupplierName(supplierDetails.get(i).getSupplierName());
				partDetailsDTO.setLocation(supplierDetails.get(i).getSupplierType());
			}
			if (i < userIds.size()) {
				partDetailsDTO.setPartController(userIds.get(i).toString());
			}
			list.add(partDetailsDTO);
		}

		return list;

	}

	@Override
	public List<PartDetailsDTO> findUnmappedParts() {
		List<Long> partIds = partCategoryRepository.findUnmappedParts();
		List<PartEntity> partDetails = partRepository.findByPartIdIn(partIds);
		List<Long> supplierIds = supplierPartsRepository.findSupplierIdsForPartIds(partIds);
		List<SupplierAddressBookEntity> supplierDetails = supplierRepository.findBySkSupplierIdIn(supplierIds);
		List<Long> userIds = userPartsRepository.findPartsControllerInfoByPartIds(partIds);
		List<PartDetailsDTO> categoryDetailsDTOlist = convertEntityToPartDetailsDTO(supplierDetails, userIds,
				partDetails, partIds.size());
		return categoryDetailsDTOlist;

	}

}
