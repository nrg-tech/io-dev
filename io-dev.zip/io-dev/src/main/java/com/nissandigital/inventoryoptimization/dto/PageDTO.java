package com.nissandigital.inventoryoptimization.dto;

import java.util.List;

public class PageDTO {
	
	private long numberOfFilteredRows;
	private long totalItems;
	private List<LastRunDTO> lastRunDTOs;
	public long getTotalItems() {
		return totalItems;
	}
	public void setTotalItems(long totalItems) {
		this.totalItems = totalItems;
	}
	public List<LastRunDTO> getLastRunDTOs() {
		return lastRunDTOs;
	}
	public void setLastRunDTOs(List<LastRunDTO> lastRunDTOs) {
		this.lastRunDTOs = lastRunDTOs;
	}
	public long getNumberOfFilteredRows() {
		return numberOfFilteredRows;
	}
	public void setNumberOfFilteredRows(long l) {
		this.numberOfFilteredRows = l;
	}
	

}
