package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nissandigital.inventoryoptimization.entity.UniqueColumnViewEntity;
import com.nissandigital.inventoryoptimization.entity.UniqueColumnViewIdentity;

public interface FilterRepository extends CrudRepository<UniqueColumnViewEntity, UniqueColumnViewIdentity> {
	
	public List<UniqueColumnViewEntity> findByPlantCode(String plantCode);
	


}
