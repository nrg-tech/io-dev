package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.UserPartsDTO;

public interface UserPartsService {
	/**
	 * Method to map Parts with parts controller details
	 * 
	 * @param Part
	 * @return
	 */
	void  addPartsToPartsController(UserPartsDTO userparts);
}
