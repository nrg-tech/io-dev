package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.OffsetApi;
import com.nissandigital.inventoryoptimization.dto.OffsetDTO;
import com.nissandigital.inventoryoptimization.request.OffsetRequest;
import com.nissandigital.inventoryoptimization.request.UpdateOffsetAllFilteredPartsRequest;
import com.nissandigital.inventoryoptimization.service.OffsetService;

import io.swagger.annotations.Api;

@RestController
@CrossOrigin
@Api(value = "Offset")
public class OffsetController implements OffsetApi {

	@Autowired
	private OffsetService offsetService;

	@Override
	public ResponseEntity<List<OffsetDTO>> getAllDistinctOffset(long plantId) {
		return new ResponseEntity<List<OffsetDTO>>(offsetService.findAllOffsetsByPlantId(plantId), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<OffsetDTO>> updateSinglePartOffset(List<OffsetRequest> offset) {
		return new ResponseEntity<List<OffsetDTO>>(offsetService.updatePartsOffsets(offset), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Long> updateAllFilteredPartOffset(UpdateOffsetAllFilteredPartsRequest OffsetDTORequest) {
		return new ResponseEntity<Long>(offsetService.updateAllFilteredPartOffsets(OffsetDTORequest), HttpStatus.OK);
	}
}
