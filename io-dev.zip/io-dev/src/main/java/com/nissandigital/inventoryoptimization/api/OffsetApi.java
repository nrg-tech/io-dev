package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nissandigital.inventoryoptimization.dto.OffsetDTO;
import com.nissandigital.inventoryoptimization.request.OffsetRequest;
import com.nissandigital.inventoryoptimization.request.UpdateOffsetAllFilteredPartsRequest;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "offset")
public interface OffsetApi {
	@ApiOperation(value = "Returns distinct offsets without Service Lines", nickname = "getAllDistinctOffset", notes = "Returns all distinct offset", response = OffsetDTO.class, responseContainer = "List", tags = {
			"Offset" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "List of all offset records", response = OffsetDTO.class, responseContainer = "List") })
	@GetMapping(value = "/all", produces = { "application/json" })
	ResponseEntity<List<OffsetDTO>> getAllDistinctOffset(
			@ApiParam(value = "plant ID", required = true) @RequestParam long plantId);

	@ApiOperation(value = "Update Offset", nickname = "updateOffset", notes = "Update  Offset", response = OffsetDTO.class, responseContainer = "List", tags = {
			"Offset" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Update the offsets of all listed records", response = OffsetDTO.class, responseContainer = "List") })
	@PutMapping(value = "/selected-parts", produces = { "application/json" })
	ResponseEntity<List<OffsetDTO>> updateSinglePartOffset(
			@ApiParam(value = "Offset update in inventory", required = true) @RequestBody List<OffsetRequest> individualOffsetDTO);

	@ApiOperation(value = "Update Offset", nickname = "updateOffset", notes = "Update  Offset", response = OffsetDTO.class, responseContainer = "List", tags = {
			"Offset" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Update the offsets of all filtered records", response = Long.class, responseContainer = "List") })
	@PutMapping(value = "/all-filtered-parts", produces = { "application/json" })
	ResponseEntity<Long> updateAllFilteredPartOffset(
			@ApiParam(value = "Offset update in inventory ", required = true) @RequestBody UpdateOffsetAllFilteredPartsRequest OffsetDTORequest);
}
