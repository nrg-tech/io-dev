package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class UserRoleIdentity implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@NotNull
	@Column(name = "PLANT_ID")
	private long plantId;

	@NotNull
	@Column(name = "USER_ROLE_ID")
	private int userRoleId;

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

	@Override
	public String toString() {
		return "UserRoleIdentity [plantId=" + plantId + ", userRoleId=" + userRoleId + "]";
	}

}
