package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.StatisticalMVTopPartsEntity;

/**
 * Repository class for performing database operations on statistical MV top
 * parts entity
 * 
 * @author Nissan Digital
 *
 */
@Repository
public interface StatisticalMVTopPartsRepository extends JpaRepository<StatisticalMVTopPartsEntity, Integer> {

	/**
	 * Fetches statistical analysis details of the top parts using plant ID
	 * 
	 * @Returns a list of statistical analysis of the top parts using plant ID
	 */
	List<StatisticalMVTopPartsEntity> findAllByPlantId(long plantId);

}
