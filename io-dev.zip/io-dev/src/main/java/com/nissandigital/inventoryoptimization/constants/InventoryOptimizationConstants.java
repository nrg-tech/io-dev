package com.nissandigital.inventoryoptimization.constants;

/**
 * Constants related to Inventory Optimization
 * 
 * @author Nissan Digital
 *
 */
public class InventoryOptimizationConstants {

	public static final Integer CUSTOM_IO_ERROR_STATUS = 450;
}
