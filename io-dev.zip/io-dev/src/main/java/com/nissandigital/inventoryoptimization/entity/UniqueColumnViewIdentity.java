package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;


public class UniqueColumnViewIdentity implements Serializable {
	
	private String plantCode;
	private String columnName;
	private String columnValue;

}
