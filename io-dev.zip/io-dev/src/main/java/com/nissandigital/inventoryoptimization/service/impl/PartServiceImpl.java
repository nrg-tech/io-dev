package com.nissandigital.inventoryoptimization.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.PartDTO;
import com.nissandigital.inventoryoptimization.entity.PartEntity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.service.PartService;

/**
 * Default implementation class for part service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class PartServiceImpl implements PartService {

	@Autowired
	PartRepository partRepository;

	@Override
	public PartDTO findPart(long partId) {
		Optional<PartEntity> part = partRepository.findById(partId);
		if (!part.isPresent()) {
			String error = String.format("Part not found with part code: %s", partId);
			throw new NoDataFoundException(error);
		}
		return convertEntityToDTO(part.get());
	}

	@Override
	public List<PartDTO> findAllParts() {
		List<PartEntity> part = new ArrayList<>();
		partRepository.findAll().forEach(part::add);
		return part.stream().map(this::convertEntityToDTO).collect(Collectors.toList());

	}

	@Override
	public long createPart(PartDTO partDTO) {
		PartEntity partEntity = convertDTOToEntity(partDTO);

		validatepartDetails(partEntity);
		return partRepository.save(partEntity).getPartId();
	}

	@Override
	public long updatePart(PartDTO partDTO) {
		Optional<PartEntity> partObj = partRepository.findById(partDTO.getPartId());
		if (!partObj.isPresent()) {
			throw new NoDataFoundException("Part not found with part id:" + partDTO.getPartId());
		}
		PartEntity updatedpart = partObj.get();
		updatedpart.setPartId(partDTO.getPartId());
		updatedpart.setPlantId(partDTO.getPlantId());
		updatedpart.setItemNumber(partDTO.getItemNumber());
		updatedpart.setItemDescription(partDTO.getItemDescription());
		updatedpart.setPartClassCode(partDTO.getPartClassCode());
		updatedpart.setUnitPrice(partDTO.getUnitPrice());
		updatedpart.setOperationalReserveQuantity(partDTO.getOperationalReserveQuantity());
		updatedpart.setMinRanOrderQuantity(partDTO.getMinRanOrderQuantity());
		updatedpart.setSnpQuantity(partDTO.getSnpQuantity());
		updatedpart.setFloatTypeUseCd(partDTO.getFloatTypeUseCd());
		updatedpart.setRecommendedDays(partDTO.getRecommendedDays());
		updatedpart.setRecommendedHours(partDTO.getRecommendedHours());
		updatedpart.setFloatComments(partDTO.getFloatComments());
		updatedpart.setLoadDate(partDTO.getLoadDate());
		validatepartDetails(updatedpart);

		return partRepository.save(updatedpart).getPartId();
	}

	@Override
	public void deletePart(long partId) {
		Optional<PartEntity> partObj = partRepository.findById(partId);
		if (!partObj.isPresent()) {
			throw new NoDataFoundException("Part not found with part code:" + partId);
		}
		PartEntity part = partObj.get();
		partRepository.delete(part);

	}

	private void validatepartDetails(PartEntity partEntity) {
		List<String> validationErrors = new ArrayList<>();
		if (partEntity.getPlantId()==0) {
			validationErrors.add("Missing plant code ");
		}
		if (!validationErrors.isEmpty()) {
			throw new ValidationException(validationErrors.stream().collect(Collectors.joining(",")));
		}
	}

	/**
	 * Converts Part DTO to Entity
	 * 
	 * @param partDTO
	 * @return
	 */

	private PartEntity convertDTOToEntity(PartDTO partDTO) {
		PartEntity partEntity = new PartEntity();
		partEntity.setPartId(partDTO.getPartId());
		partEntity.setPlantId(partDTO.getPlantId());
		partEntity.setItemNumber(partDTO.getItemNumber());
		partEntity.setItemDescription(partDTO.getItemDescription());
		partEntity.setPartClassCode(partDTO.getPartClassCode());
		partEntity.setUnitPrice(partDTO.getUnitPrice());
		partEntity.setOperationalReserveQuantity(partDTO.getOperationalReserveQuantity());
		partEntity.setMinRanOrderQuantity(partDTO.getMinRanOrderQuantity());
		partEntity.setSnpQuantity(partDTO.getSnpQuantity());
		partEntity.setFloatTypeUseCd(partDTO.getFloatTypeUseCd());
		partEntity.setRecommendedDays(partDTO.getRecommendedDays());
		partEntity.setRecommendedHours(partDTO.getRecommendedHours());
		partEntity.setFloatComments(partDTO.getFloatComments());
		partEntity.setLoadDate(partDTO.getLoadDate());
		return partEntity;
	}

	/**
	 * Converts Part entity to DTO
	 * 
	 * @param partInfo
	 * @return
	 */
	private PartDTO convertEntityToDTO(PartEntity partEntity) {

		PartDTO partResponse = new PartDTO();
		partResponse.setPartId(partEntity.getPartId());
		partResponse.setPlantId(partEntity.getPlantId());
		partResponse.setItemNumber(partEntity.getItemNumber());
		partResponse.setItemDescription(partEntity.getItemDescription());
		partResponse.setPartClassCode(partEntity.getPartClassCode());
		partResponse.setUnitPrice(partEntity.getUnitPrice());
		partResponse.setOperationalReserveQuantity(partEntity.getOperationalReserveQuantity());
		partResponse.setMinRanOrderQuantity(partEntity.getMinRanOrderQuantity());
		partResponse.setSnpQuantity(partEntity.getSnpQuantity());
		partResponse.setFloatTypeUseCd(partEntity.getFloatTypeUseCd());
		partResponse.setRecommendedDays(partEntity.getRecommendedDays());
		partResponse.setRecommendedHours(partEntity.getRecommendedHours());
		partResponse.setFloatComments(partEntity.getFloatComments());
		partResponse.setLoadDate(partEntity.getLoadDate());
		return partResponse;
	}

}
