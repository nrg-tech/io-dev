package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.request.LastRunRequest;

public interface LastRunRepositoryCustom {

	List<StatisticalModelOutputViewEntity> findByFilteredParts(String condition, LastRunRequest lastRunRequest);

	long findTotalCountOfFilteredData(String condition);

	String generateQueryCondition(LastRunRequest lastRunRequest);

}
