package com.nissandigital.inventoryoptimization.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.AggregateStatisticsDTO;
import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping("aggregate-statistics")
public interface AggregateStatisticsApi {

	@ApiOperation(value = "Fetch the aggregate statistical data", nickname = "getAggregateStatistics", notes = "Returns the aggregate statistical data", response = AggregateStatisticsDTO.class, tags = "Aggregate statistics")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Aggregate statistical data fetched successfully", response = AggregateStatisticsDTO.class),
			@ApiResponse(code = 404, message = "Details not found for the current user's plant", response = InventoryOptimizationError.class) })
	@GetMapping(produces = { "application/json" })
	ResponseEntity<AggregateStatisticsDTO> getAggregateStatistics();

}
