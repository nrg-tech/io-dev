package com.nissandigital.inventoryoptimization.advice;

import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.nissandigital.inventoryoptimization.constants.InventoryOptimizationErrorMessages;
import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;
import com.nissandigital.inventoryoptimization.exception.InventoryOptimizationException;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

/**
 * Controller Advice for handling the exceptions and converting them to proper error response
 * 
 * @author Nissan Digital
 *
 */
@ControllerAdvice
public class InventoryOptimizationControllerAdvice {

    private static Logger LOGGER = LoggerFactory
            .getLogger(InventoryOptimizationControllerAdvice.class);

    /**
     * Handles NoDataFoundException.
     * 
     * @param NoDataFoundException
     * @return InventoryOptimizationError
     */
    @ExceptionHandler(NoDataFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public InventoryOptimizationError handleNoDataFoundException(NoDataFoundException ex) {
    	LOGGER.error("No data found exception occoured",ex);
        return createResponseErrorMessage(ex.getMessage());
    }
    /**
     * Handles ValidationException.
     * 
     * @param ValidationException
     * @return InventoryOptimizationError
     */
    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ResponseBody
    public InventoryOptimizationError handleValidationException(ValidationException ex) {
    	LOGGER.error("Validation exception occoured",ex);
        return createResponseErrorMessage(ex.getMessage());
    }
    
    
    /**
     * Handles InventoryOptimizationException.
     * 
     * @param InventoryOptimizationException
     * @return InventoryOptimizationError
     */
    @ExceptionHandler(InventoryOptimizationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public InventoryOptimizationError handleException(InventoryOptimizationException ex) {
    	LOGGER.error("InventoryOptimization exception occoured",ex);
        return createResponseErrorMessage(ex.getMessage());
    }
    
    /**
     * Handle any MethodArgumentNotValidException.
     * 
     * @param MethodArgumentNotValidException
     * @return InventoryOptimizationError
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ResponseBody
    public InventoryOptimizationError handleException(MethodArgumentNotValidException ex) {
    	LOGGER.error("Method Argument Not valid exception encoundered",ex);
        return createResponseErrorMessage(ex.getMessage());
    }

    /**
     * Handle any uncaught exception.
     * 
     * @param Exception
     * @return InventoryOptimizationError
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public InventoryOptimizationError handleException(Exception ex) {
    	LOGGER.error("Unexpected exception occoured",ex);
        return createResponseErrorMessage(
                InventoryOptimizationErrorMessages.RESOURCE_OPERATION_FAILED_MESSAGE);
    }

    /**
     * Creates Error Response Object from message
     * 
     * @param message
     * @return
     */
    private InventoryOptimizationError createResponseErrorMessage(String message) {
    	InventoryOptimizationError responseErrorMessage = new InventoryOptimizationError();
        responseErrorMessage.setErrorMessage(message);
        return responseErrorMessage;
    }
}