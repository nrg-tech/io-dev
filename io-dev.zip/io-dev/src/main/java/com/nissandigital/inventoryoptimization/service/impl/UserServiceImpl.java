package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
import com.nissandigital.inventoryoptimization.entity.UserEntity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.exception.ValidationException;
import com.nissandigital.inventoryoptimization.repository.UserRepository;
import com.nissandigital.inventoryoptimization.repository.UserRoleRepository;
import com.nissandigital.inventoryoptimization.service.UserService;

/**
 * Implementation class for user service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRoleRepository userRoleRepository;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetailsDTO getCurrentUser() {
		Optional<UserEntity> user = userRepository.findById(1001l);
		if (!user.isPresent()) {
			throw new NoDataFoundException("Information for current user is not found");			
		}
		return modelMapper.map(user.get(), UserDetailsDTO.class);
	}

	@Override
	public List<UserDetailsDTO> findUserByRole(String role) {
		if (userRoleRepository.findByUserRoleDesc(role).isEmpty()) {
			throw new ValidationException("Invalid user role description : " + role);
		}			
		List<UserEntity> users = userRepository.findByUserRole(role);
		if (users.isEmpty()) {
			throw new NoDataFoundException("No users present with role : " + role);			
		}
		return users.stream().map(w -> modelMapper.map(w, UserDetailsDTO.class)).collect(Collectors.toList());
	}

}
