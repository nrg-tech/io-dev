package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.AggregateStatisticsDTO;

/**
 * Service class to retrieve aggregate statistics and business logic
 * 
 * @author Nissan Digital
 *
 */
public interface AggregateStatisticsService {

	/**
	 * Fetch the aggregate statistical data
	 * 
	 * @Returns the aggregate statistical data
	 */
	AggregateStatisticsDTO getAggregateStatistics();

}
