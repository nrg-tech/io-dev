package com.nissandigital.inventoryoptimization.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * DTO class containing Last Run Table details
 * 
 * @author Nissan Digital
 *
 */
public class LastRunDTO {

	private RecommendedFloatCurrentDTO recommendedFloatCurrent;
	private RecommendedFloatLastRunDTO recommendedFloatLastRun;
	private MinimumFloatCurrentDTO minimumFloatCurrent;
	private MinimumFloatLastRunDTO minimumFloatLastRun;

	private String plantCode;

	private String partNumber;

	private Double serviceLevel;

	private Date modelExecutionDate;

	private String distributionTypeLeadTime;

	private String distributionTypeDemand;

	private Double unitPrice;

	private String supplierType;

	private String supplierCode;

	private String supplierName;

	private String supplierStateCode;

	private Double baselineInventoryQuantity;

	private Double baselineInventoryValue;

	private Integer totalDemandForecast;

	private String totalDemandStatus;

	private Integer averageDailyDemand;

	private Character abcClassConsumptionValue;

	private Character xyzClassCoefficientOfVarianceDemandForecast;

	private String abcXyzClassificationIndicator;

	private Character otherClass;

	private Double minimumRanOrderQuantity;

	private Double snpQuantity;

	private Double operationalReserveQuantity;

	private Double operationalReserveValue;

	private Double purchaseFrequencyRanDays;

	private Double purchaseLeadTime;

	private Double supplyCycleTime;

	private Double covDailyOmDemandCapped;

	private Double covLast12Month;

	private Double coefficientOfVarianceLeadTimeVariability;

	private Double coefficientOfVarianceLeadTimeVariabilityOmCapped;

	private Double purchaseFrequencyVariability;

	private Double purchaseFrequencyVariabilityOm;

	private Double safetyStockQuantityDemandVariability;

	private Double safetyStockValueDemandVariability;

	private Double safetyStockQuantitySupplierVariability;

	private Double safetyStockValueSupplierVariability;

	private Double totalSafetyStockQuantity;

	private Double safetyStockValue;

	private Double directPipelineStockQuantity;

	private Double directPipelineStockValue;

	private Double ilcPipelineStockQuantity;

	private Double ilcPipelineStockValue;

	private Double scrapInventoryQuantity;

	private Double scrapPercentageToAnnualDemand;

	private Double maximumScrapQuantityInstance;

	private Double maximumScrapQuantityInstancePercentage;

	private Double maximumCycleLossQuantityInstance;

	private Double maximumCycleLossQuantityInstancePercentage;

	private Double cycleLossPercentageTotalAnnualDemand;

	private Double floatInventorySavings;

	private Double totalRecommendedFloatQuantity;

	private Double totalRecommendedFloatValue;

	private Double minimumFloatQuantity;

	private Double minimumFloatValue;

	private Double changePerRecommendedFloatValue;

	private Double totalRecommendedReorderQuantity;

	private Double totalRecommendedCycleStockQuantity;

	private Double totalRecommendedCycleStockValue;

	private Double totalRecommendedOnHandStockQuantity;

	private Double totalRecommendedOnHandStockValue;

	private Double activeManagementLever1Days;

	private String partTypeCode;

	private String partsCategoryDescription;

	private String partsController;

	private String analystCode;

	private String dockId;

	private String shipFacility;

	private String orderOptionCode;

	private String crossDockSubsystem;

	private Double reportingPoint;

	private Character floatTypeUseCode;

	private int primaryLccnNumber;

	private Double orderPointQuantity;

	private String supplierCountry;

	private Date lastUsageMonth;

	private String groupCode;

	private Double totalNumberOfInboundLccn;

	private Double pkgDataL;

	private Double pkgDataW;

	private Double pkgDataH;

	private String orderPointCalculationCode;

	private String orderPointFactor1;

	private Integer rackCapacity;

	private String dzLocationType;

	private String pickToBroadcastIndicator;

	private String kitIndicator;

	private String subAssembledIndicator;

	private Double meanAbsoluteDeviation;

	private Double purchaseFrequencyRanDaysMethod2;

	private Double purchaseFrequencyRanDaysMethod3;

	private Double floatVariance;

	private Double usageVariance;

	private Double totalCycleLossQuantity;

	public RecommendedFloatCurrentDTO getRecommendedFloatCurrent() {
		return recommendedFloatCurrent;
	}

	public void setRecommendedFloatCurrent(RecommendedFloatCurrentDTO recommendedFloatCurrent) {
		this.recommendedFloatCurrent = recommendedFloatCurrent;
	}

	public RecommendedFloatLastRunDTO getRecommendedFloatLastRun() {
		return recommendedFloatLastRun;
	}

	public void setRecommendedFloatLastRun(RecommendedFloatLastRunDTO recommendedFloatLastRun) {
		this.recommendedFloatLastRun = recommendedFloatLastRun;
	}

	public MinimumFloatCurrentDTO getMinimumFloatCurrent() {
		return this.minimumFloatCurrent;
	}

	public void setMinimumFloatCurrent(MinimumFloatCurrentDTO minimumFloatCurrent) {
		this.minimumFloatCurrent = minimumFloatCurrent;
	}

	public MinimumFloatLastRunDTO getMinimumFloatLastRun() {
		return minimumFloatLastRun;
	}

	public void setMinimumFloatLastRun(MinimumFloatLastRunDTO minimumFloatLastRun) {
		this.minimumFloatLastRun = minimumFloatLastRun;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public Double getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(Double serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	public String getDistributionTypeLeadTime() {
		return distributionTypeLeadTime;
	}

	public void setDistributionTypeLeadTime(String distributionTypeLeadTime) {
		this.distributionTypeLeadTime = distributionTypeLeadTime;
	}

	public String getDistributionTypeDemand() {
		return distributionTypeDemand;
	}

	public void setDistributionTypeDemand(String distributionTypeDemand) {
		this.distributionTypeDemand = distributionTypeDemand;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierStateCode() {
		return supplierStateCode;
	}

	public void setSupplierStateCode(String supplierStateCode) {
		this.supplierStateCode = supplierStateCode;
	}

	public Double getBaselineInventoryQuantity() {
		return baselineInventoryQuantity;
	}

	public void setBaselineInventoryQuantity(Double baselineInventoryQuantity) {
		this.baselineInventoryQuantity = baselineInventoryQuantity;
	}

	public Double getBaselineInventoryValue() {
		return baselineInventoryValue;
	}

	public void setBaselineInventoryValue(Double baselineInventoryValue) {
		this.baselineInventoryValue = baselineInventoryValue;
	}

	public Integer getTotalDemandForecast() {
		return totalDemandForecast;
	}

	public void setTotalDemandForecast(Integer totalDemandForecast) {
		this.totalDemandForecast = totalDemandForecast;
	}

	public String getTotalDemandStatus() {
		return totalDemandStatus;
	}

	public void setTotalDemandStatus(String totalDemandStatus) {
		this.totalDemandStatus = totalDemandStatus;
	}

	public Integer getAverageDailyDemand() {
		return averageDailyDemand;
	}

	public void setAverageDailyDemand(Integer averageDailyDemand) {
		this.averageDailyDemand = averageDailyDemand;
	}

	public Character getAbcClassConsumptionValue() {
		return abcClassConsumptionValue;
	}

	public void setAbcClassConsumptionValue(Character abcClassConsumptionValue) {
		this.abcClassConsumptionValue = abcClassConsumptionValue;
	}

	public Character getXyzClassCoefficientOfVarianceDemandForecast() {
		return xyzClassCoefficientOfVarianceDemandForecast;
	}

	public void setXyzClassCoefficientOfVarianceDemandForecast(Character xyzClassCoefficientOfVarianceDemandForecast) {
		this.xyzClassCoefficientOfVarianceDemandForecast = xyzClassCoefficientOfVarianceDemandForecast;
	}

	public String getAbcXyzClassificationIndicator() {
		return abcXyzClassificationIndicator;
	}

	public void setAbcXyzClassificationIndicator(String abcXyzClassificationIndicator) {
		this.abcXyzClassificationIndicator = abcXyzClassificationIndicator;
	}

	public Character getOtherClass() {
		return otherClass;
	}

	public void setOtherClass(Character otherClass) {
		this.otherClass = otherClass;
	}

	public Double getMinimumRanOrderQuantity() {
		return minimumRanOrderQuantity;
	}

	public void setMinimumRanOrderQuantity(Double minimumRanOrderQuantity) {
		this.minimumRanOrderQuantity = minimumRanOrderQuantity;
	}

	public Double getSnpQuantity() {
		return snpQuantity;
	}

	public void setSnpQuantity(Double snpQuantity) {
		this.snpQuantity = snpQuantity;
	}

	public Double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	public void setOperationalReserveQuantity(Double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	public Double getOperationalReserveValue() {
		return operationalReserveValue;
	}

	public void setOperationalReserveValue(Double operationalReserveValue) {
		this.operationalReserveValue = operationalReserveValue;
	}

	public Double getPurchaseFrequencyRanDays() {
		return purchaseFrequencyRanDays;
	}

	public void setPurchaseFrequencyRanDays(Double purchaseFrequencyRanDays) {
		this.purchaseFrequencyRanDays = purchaseFrequencyRanDays;
	}

	public Double getPurchaseLeadTime() {
		return purchaseLeadTime;
	}

	public void setPurchaseLeadTime(Double purchaseLeadTime) {
		this.purchaseLeadTime = purchaseLeadTime;
	}

	public Double getSupplyCycleTime() {
		return supplyCycleTime;
	}

	public void setSupplyCycleTime(Double supplyCycleTime) {
		this.supplyCycleTime = supplyCycleTime;
	}

	public Double getCovDailyOmDemandCapped() {
		return covDailyOmDemandCapped;
	}

	public void setCovDailyOmDemandCapped(Double covDailyOmDemandCapped) {
		this.covDailyOmDemandCapped = covDailyOmDemandCapped;
	}

	public Double getCovLast12Month() {
		return covLast12Month;
	}

	public void setCovLast12Month(Double covLast12Month) {
		this.covLast12Month = covLast12Month;
	}

	public Double getCoefficientOfVarianceLeadTimeVariability() {
		return coefficientOfVarianceLeadTimeVariability;
	}

	public void setCoefficientOfVarianceLeadTimeVariability(Double coefficientOfVarianceLeadTimeVariability) {
		this.coefficientOfVarianceLeadTimeVariability = coefficientOfVarianceLeadTimeVariability;
	}

	public Double getCoefficientOfVarianceLeadTimeVariabilityOmCapped() {
		return coefficientOfVarianceLeadTimeVariabilityOmCapped;
	}

	public void setCoefficientOfVarianceLeadTimeVariabilityOmCapped(
			Double coefficientOfVarianceLeadTimeVariabilityOmCapped) {
		this.coefficientOfVarianceLeadTimeVariabilityOmCapped = coefficientOfVarianceLeadTimeVariabilityOmCapped;
	}

	public Double getPurchaseFrequencyVariability() {
		return purchaseFrequencyVariability;
	}

	public void setPurchaseFrequencyVariability(Double purchaseFrequencyVariability) {
		this.purchaseFrequencyVariability = purchaseFrequencyVariability;
	}

	public Double getPurchaseFrequencyVariabilityOm() {
		return purchaseFrequencyVariabilityOm;
	}

	public void setPurchaseFrequencyVariabilityOm(Double purchaseFrequencyVariabilityOm) {
		this.purchaseFrequencyVariabilityOm = purchaseFrequencyVariabilityOm;
	}

	public Double getSafetyStockQuantityDemandVariability() {
		return safetyStockQuantityDemandVariability;
	}

	public void setSafetyStockQuantityDemandVariability(Double safetyStockQuantityDemandVariability) {
		this.safetyStockQuantityDemandVariability = safetyStockQuantityDemandVariability;
	}

	public Double getSafetyStockValueDemandVariability() {
		return safetyStockValueDemandVariability;
	}

	public void setSafetyStockValueDemandVariability(Double safetyStockValueDemandVariability) {
		this.safetyStockValueDemandVariability = safetyStockValueDemandVariability;
	}

	public Double getSafetyStockQuantitySupplierVariability() {
		return safetyStockQuantitySupplierVariability;
	}

	public void setSafetyStockQuantitySupplierVariability(Double safetyStockQuantitySupplierVariability) {
		this.safetyStockQuantitySupplierVariability = safetyStockQuantitySupplierVariability;
	}

	public Double getSafetyStockValueSupplierVariability() {
		return safetyStockValueSupplierVariability;
	}

	public void setSafetyStockValueSupplierVariability(Double safetyStockValueSupplierVariability) {
		this.safetyStockValueSupplierVariability = safetyStockValueSupplierVariability;
	}

	public Double getTotalSafetyStockQuantity() {
		return totalSafetyStockQuantity;
	}

	public void setTotalSafetyStockQuantity(Double totalSafetyStockQuantity) {
		this.totalSafetyStockQuantity = totalSafetyStockQuantity;
	}

	public Double getSafetyStockValue() {
		return safetyStockValue;
	}

	public void setSafetyStockValue(Double safetyStockValue) {
		this.safetyStockValue = safetyStockValue;
	}

	public Double getDirectPipelineStockQuantity() {
		return directPipelineStockQuantity;
	}

	public void setDirectPipelineStockQuantity(Double directPipelineStockQuantity) {
		this.directPipelineStockQuantity = directPipelineStockQuantity;
	}

	public Double getDirectPipelineStockValue() {
		return directPipelineStockValue;
	}

	public void setDirectPipelineStockValue(Double directPipelineStockValue) {
		this.directPipelineStockValue = directPipelineStockValue;
	}

	public Double getIlcPipelineStockQuantity() {
		return ilcPipelineStockQuantity;
	}

	public void setIlcPipelineStockQuantity(Double ilcPipelineStockQuantity) {
		this.ilcPipelineStockQuantity = ilcPipelineStockQuantity;
	}

	public Double getIlcPipelineStockValue() {
		return ilcPipelineStockValue;
	}

	public void setIlcPipelineStockValue(Double ilcPipelineStockValue) {
		this.ilcPipelineStockValue = ilcPipelineStockValue;
	}

	public Double getScrapInventoryQuantity() {
		return scrapInventoryQuantity;
	}

	public void setScrapInventoryQuantity(Double scrapInventoryQuantity) {
		this.scrapInventoryQuantity = scrapInventoryQuantity;
	}

	public Double getScrapPercentageToAnnualDemand() {
		return scrapPercentageToAnnualDemand;
	}

	public void setScrapPercentageToAnnualDemand(Double scrapPercentageToAnnualDemand) {
		this.scrapPercentageToAnnualDemand = scrapPercentageToAnnualDemand;
	}

	public Double getMaximumScrapQuantityInstance() {
		return maximumScrapQuantityInstance;
	}

	public void setMaximumScrapQuantityInstance(Double maximumScrapQuantityInstance) {
		this.maximumScrapQuantityInstance = maximumScrapQuantityInstance;
	}

	public Double getMaximumScrapQuantityInstancePercentage() {
		return maximumScrapQuantityInstancePercentage;
	}

	public void setMaximumScrapQuantityInstancePercentage(Double maximumScrapQuantityInstancePercentage) {
		this.maximumScrapQuantityInstancePercentage = maximumScrapQuantityInstancePercentage;
	}

	public Double getMaximumCycleLossQuantityInstance() {
		return maximumCycleLossQuantityInstance;
	}

	public void setMaximumCycleLossQuantityInstance(Double maximumCycleLossQuantityInstance) {
		this.maximumCycleLossQuantityInstance = maximumCycleLossQuantityInstance;
	}

	public Double getMaximumCycleLossQuantityInstancePercentage() {
		return maximumCycleLossQuantityInstancePercentage;
	}

	public void setMaximumCycleLossQuantityInstancePercentage(Double maximumCycleLossQuantityInstancePercentage) {
		this.maximumCycleLossQuantityInstancePercentage = maximumCycleLossQuantityInstancePercentage;
	}

	public Double getCycleLossPercentageTotalAnnualDemand() {
		return cycleLossPercentageTotalAnnualDemand;
	}

	public void setCycleLossPercentageTotalAnnualDemand(Double cycleLossPercentageTotalAnnualDemand) {
		this.cycleLossPercentageTotalAnnualDemand = cycleLossPercentageTotalAnnualDemand;
	}

	public Double getFloatInventorySavings() {
		return floatInventorySavings;
	}

	public void setFloatInventorySavings(Double floatInventorySavings) {
		this.floatInventorySavings = floatInventorySavings;
	}

	public Double getTotalRecommendedFloatQuantity() {
		return totalRecommendedFloatQuantity;
	}

	public void setTotalRecommendedFloatQuantity(Double totalRecommendedFloatQuantity) {
		this.totalRecommendedFloatQuantity = totalRecommendedFloatQuantity;
	}

	public Double getTotalRecommendedFloatValue() {
		return totalRecommendedFloatValue;
	}

	public void setTotalRecommendedFloatValue(Double totalRecommendedFloatValue) {
		this.totalRecommendedFloatValue = totalRecommendedFloatValue;
	}

	public Double getMinimumFloatQuantity() {
		return minimumFloatQuantity;
	}

	public void setMinimumFloatQuantity(Double minimumFloatQuantity) {
		this.minimumFloatQuantity = minimumFloatQuantity;
	}

	public Double getMinimumFloatValue() {
		return minimumFloatValue;
	}

	public void setMinimumFloatValue(Double minimumFloatValue) {
		this.minimumFloatValue = minimumFloatValue;
	}

	public Double getChangePerRecommendedFloatValue() {
		return changePerRecommendedFloatValue;
	}

	public void setChangePerRecommendedFloatValue(Double changePerRecommendedFloatValue) {
		this.changePerRecommendedFloatValue = changePerRecommendedFloatValue;
	}

	public Double getTotalRecommendedReorderQuantity() {
		return totalRecommendedReorderQuantity;
	}

	public void setTotalRecommendedReorderQuantity(Double totalRecommendedReorderQuantity) {
		this.totalRecommendedReorderQuantity = totalRecommendedReorderQuantity;
	}

	public Double getTotalRecommendedCycleStockQuantity() {
		return totalRecommendedCycleStockQuantity;
	}

	public void setTotalRecommendedCycleStockQuantity(Double totalRecommendedCycleStockQuantity) {
		this.totalRecommendedCycleStockQuantity = totalRecommendedCycleStockQuantity;
	}

	public Double getTotalRecommendedCycleStockValue() {
		return totalRecommendedCycleStockValue;
	}

	public void setTotalRecommendedCycleStockValue(Double totalRecommendedCycleStockValue) {
		this.totalRecommendedCycleStockValue = totalRecommendedCycleStockValue;
	}

	public Double getTotalRecommendedOnHandStockQuantity() {
		return totalRecommendedOnHandStockQuantity;
	}

	public void setTotalRecommendedOnHandStockQuantity(Double totalRecommendedOnHandStockQuantity) {
		this.totalRecommendedOnHandStockQuantity = totalRecommendedOnHandStockQuantity;
	}

	public Double getTotalRecommendedOnHandStockValue() {
		return totalRecommendedOnHandStockValue;
	}

	public void setTotalRecommendedOnHandStockValue(Double totalRecommendedOnHandStockValue) {
		this.totalRecommendedOnHandStockValue = totalRecommendedOnHandStockValue;
	}

	public Double getActiveManagementLever1Days() {
		return activeManagementLever1Days;
	}

	public void setActiveManagementLever1Days(Double activeManagementLever1Days) {
		this.activeManagementLever1Days = activeManagementLever1Days;
	}

	public String getPartTypeCode() {
		return partTypeCode;
	}

	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	public String getPartsCategoryDescription() {
		return partsCategoryDescription;
	}

	public void setPartsCategoryDescription(String partsCategoryDescription) {
		this.partsCategoryDescription = partsCategoryDescription;
	}

	public String getPartsController() {
		return partsController;
	}

	public void setPartsController(String partsController) {
		this.partsController = partsController;
	}

	public String getAnalystCode() {
		return analystCode;
	}

	public void setAnalystCode(String analystCode) {
		this.analystCode = analystCode;
	}

	public String getDockId() {
		return dockId;
	}

	public void setDockId(String dockId) {
		this.dockId = dockId;
	}

	public String getShipFacility() {
		return shipFacility;
	}

	public void setShipFacility(String shipFacility) {
		this.shipFacility = shipFacility;
	}

	public String getOrderOptionCode() {
		return orderOptionCode;
	}

	public void setOrderOptionCode(String orderOptionCode) {
		this.orderOptionCode = orderOptionCode;
	}

	public String getCrossDockSubsystem() {
		return crossDockSubsystem;
	}

	public void setCrossDockSubsystem(String crossDockSubsystem) {
		this.crossDockSubsystem = crossDockSubsystem;
	}

	public Double getReportingPoint() {
		return reportingPoint;
	}

	public void setReportingPoint(Double reportingPoint) {
		this.reportingPoint = reportingPoint;
	}

	public Character getFloatTypeUseCode() {
		return floatTypeUseCode;
	}

	public void setFloatTypeUseCode(Character floatTypeUseCode) {
		this.floatTypeUseCode = floatTypeUseCode;
	}

	public int getPrimaryLccnNumber() {
		return primaryLccnNumber;
	}

	public void setPrimaryLccnNumber(int primaryLccnNumber) {
		this.primaryLccnNumber = primaryLccnNumber;
	}

	public Double getOrderPointQuantity() {
		return orderPointQuantity;
	}

	public void setOrderPointQuantity(Double orderPointQuantity) {
		this.orderPointQuantity = orderPointQuantity;
	}

	public String getSupplierCountry() {
		return supplierCountry;
	}

	public void setSupplierCountry(String supplierCountry) {
		this.supplierCountry = supplierCountry;
	}

	public Date getLastUsageMonth() {
		return lastUsageMonth;
	}

	public void setLastUsageMonth(Date lastUsageMonth) {
		this.lastUsageMonth = lastUsageMonth;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public Double getTotalNumberOfInboundLccn() {
		return totalNumberOfInboundLccn;
	}

	public void setTotalNumberOfInboundLccn(Double totalNumberOfInboundLccn) {
		this.totalNumberOfInboundLccn = totalNumberOfInboundLccn;
	}

	public Double getPkgDataL() {
		return pkgDataL;
	}

	public void setPkgDataL(Double pkgDataL) {
		this.pkgDataL = pkgDataL;
	}

	public Double getPkgDataW() {
		return pkgDataW;
	}

	public void setPkgDataW(Double pkgDataW) {
		this.pkgDataW = pkgDataW;
	}

	public Double getPkgDataH() {
		return pkgDataH;
	}

	public void setPkgDataH(Double pkgDataH) {
		this.pkgDataH = pkgDataH;
	}

	public String getOrderPointCalculationCode() {
		return orderPointCalculationCode;
	}

	public void setOrderPointCalculationCode(String orderPointCalculationCode) {
		this.orderPointCalculationCode = orderPointCalculationCode;
	}

	public String getOrderPointFactor1() {
		return orderPointFactor1;
	}

	public void setOrderPointFactor1(String orderPointFactor1) {
		this.orderPointFactor1 = orderPointFactor1;
	}

	public Integer getRackCapacity() {
		return rackCapacity;
	}

	public void setRackCapacity(Integer rackCapacity) {
		this.rackCapacity = rackCapacity;
	}

	public String getDzLocationType() {
		return dzLocationType;
	}

	public void setDzLocationType(String dzLocationType) {
		this.dzLocationType = dzLocationType;
	}

	public String getPickToBroadcastIndicator() {
		return pickToBroadcastIndicator;
	}

	public void setPickToBroadcastIndicator(String pickToBroadcastIndicator) {
		this.pickToBroadcastIndicator = pickToBroadcastIndicator;
	}

	public String getKitIndicator() {
		return kitIndicator;
	}

	public void setKitIndicator(String kitIndicator) {
		this.kitIndicator = kitIndicator;
	}

	public String getSubAssembledIndicator() {
		return subAssembledIndicator;
	}

	public void setSubAssembledIndicator(String subAssembledIndicator) {
		this.subAssembledIndicator = subAssembledIndicator;
	}

	public Double getMeanAbsoluteDeviation() {
		return meanAbsoluteDeviation;
	}

	public void setMeanAbsoluteDeviation(Double meanAbsoluteDeviation) {
		this.meanAbsoluteDeviation = meanAbsoluteDeviation;
	}

	public Double getPurchaseFrequencyRanDaysMethod2() {
		return purchaseFrequencyRanDaysMethod2;
	}

	public void setPurchaseFrequencyRanDaysMethod2(Double purchaseFrequencyRanDaysMethod2) {
		this.purchaseFrequencyRanDaysMethod2 = purchaseFrequencyRanDaysMethod2;
	}

	public Double getPurchaseFrequencyRanDaysMethod3() {
		return purchaseFrequencyRanDaysMethod3;
	}

	public void setPurchaseFrequencyRanDaysMethod3(Double purchaseFrequencyRanDaysMethod3) {
		this.purchaseFrequencyRanDaysMethod3 = purchaseFrequencyRanDaysMethod3;
	}

	public Double getFloatVariance() {
		return floatVariance;
	}

	public void setFloatVariance(Double floatVariance) {
		this.floatVariance = floatVariance;
	}

	public Double getUsageVariance() {
		return usageVariance;
	}

	public void setUsageVariance(Double usageVariance) {
		this.usageVariance = usageVariance;
	}

	public Double getTotalCycleLossQuantity() {
		return totalCycleLossQuantity;
	}

	public void setTotalCycleLossQuantity(Double totalCycleLossQuantity) {
		this.totalCycleLossQuantity = totalCycleLossQuantity;
	}

	@Override
	public String toString() {
		return "LastRunDTO [recommendedFloatCurrent=" + recommendedFloatCurrent + ", recommendedFloatLastRun="
				+ recommendedFloatLastRun + ", minimumFloatCurrent=" + minimumFloatCurrent + ", minimumFloatLastRun="
				+ minimumFloatLastRun + ", plantCode=" + plantCode + ", partNumber=" + partNumber + ", serviceLevel="
				+ serviceLevel + ", modelExecutionDate=" + modelExecutionDate + ", distributionTypeLeadTime="
				+ distributionTypeLeadTime + ", distributionTypeDemand=" + distributionTypeDemand + ", unitPrice="
				+ unitPrice + ", supplierType=" + supplierType + ", supplierCode=" + supplierCode + ", supplierName="
				+ supplierName + ", supplierStateCode=" + supplierStateCode + ", baselineInventoryQuantity="
				+ baselineInventoryQuantity + ", baselineInventoryValue=" + baselineInventoryValue
				+ ", totalDemandForecast=" + totalDemandForecast + ", totalDemandStatus=" + totalDemandStatus
				+ ", averageDailyDemand=" + averageDailyDemand + ", abcClassConsumptionValue="
				+ abcClassConsumptionValue + ", xyzClassCoefficientOfVarianceDemandForecast="
				+ xyzClassCoefficientOfVarianceDemandForecast + ", abcXyzClassificationIndicator="
				+ abcXyzClassificationIndicator + ", otherClass=" + otherClass + ", minimumRanOrderQuantity="
				+ minimumRanOrderQuantity + ", snpQuantity=" + snpQuantity + ", operationalReserveQuantity="
				+ operationalReserveQuantity + ", operationalReserveValue=" + operationalReserveValue
				+ ", purchaseFrequencyRanDays=" + purchaseFrequencyRanDays + ", purchaseLeadTime=" + purchaseLeadTime
				+ ", supplyCycleTime=" + supplyCycleTime + ", covDailyOmDemandCapped=" + covDailyOmDemandCapped
				+ ", covLast12Month=" + covLast12Month + ", coefficientOfVarianceLeadTimeVariability="
				+ coefficientOfVarianceLeadTimeVariability + ", coefficientOfVarianceLeadTimeVariabilityOmCapped="
				+ coefficientOfVarianceLeadTimeVariabilityOmCapped + ", purchaseFrequencyVariability="
				+ purchaseFrequencyVariability + ", purchaseFrequencyVariabilityOm=" + purchaseFrequencyVariabilityOm
				+ ", safetyStockQuantityDemandVariability=" + safetyStockQuantityDemandVariability
				+ ", safetyStockValueDemandVariability=" + safetyStockValueDemandVariability
				+ ", safetyStockQuantitySupplierVariability=" + safetyStockQuantitySupplierVariability
				+ ", safetyStockValueSupplierVariability=" + safetyStockValueSupplierVariability
				+ ", totalSafetyStockQuantity=" + totalSafetyStockQuantity + ", safetyStockValue=" + safetyStockValue
				+ ", directPipelineStockQuantity=" + directPipelineStockQuantity + ", directPipelineStockValue="
				+ directPipelineStockValue + ", ilcPipelineStockQuantity=" + ilcPipelineStockQuantity
				+ ", ilcPipelineStockValue=" + ilcPipelineStockValue + ", scrapInventoryQuantity="
				+ scrapInventoryQuantity + ", scrapPercentageToAnnualDemand=" + scrapPercentageToAnnualDemand
				+ ", maximumScrapQuantityInstance=" + maximumScrapQuantityInstance
				+ ", maximumScrapQuantityInstancePercentage=" + maximumScrapQuantityInstancePercentage
				+ ", maximumCycleLossQuantityInstance=" + maximumCycleLossQuantityInstance
				+ ", maximumCycleLossQuantityInstancePercentage=" + maximumCycleLossQuantityInstancePercentage
				+ ", cycleLossPercentageTotalAnnualDemand=" + cycleLossPercentageTotalAnnualDemand
				+ ", floatInventorySavings=" + floatInventorySavings + ", totalRecommendedFloatQuantity="
				+ totalRecommendedFloatQuantity + ", totalRecommendedFloatValue=" + totalRecommendedFloatValue
				+ ", minimumFloatQuantity=" + minimumFloatQuantity + ", minimumFloatValue=" + minimumFloatValue
				+ ", changePerRecommendedFloatValue=" + changePerRecommendedFloatValue
				+ ", totalRecommendedReorderQuantity=" + totalRecommendedReorderQuantity
				+ ", totalRecommendedCycleStockQuantity=" + totalRecommendedCycleStockQuantity
				+ ", totalRecommendedCycleStockValue=" + totalRecommendedCycleStockValue
				+ ", totalRecommendedOnHandStockQuantity=" + totalRecommendedOnHandStockQuantity
				+ ", totalRecommendedOnHandStockValue=" + totalRecommendedOnHandStockValue
				+ ", activeManagementLever1Days=" + activeManagementLever1Days + ", partTypeCode=" + partTypeCode
				+ ", partsCategoryDescription=" + partsCategoryDescription + ", partsController=" + partsController
				+ ", analystCode=" + analystCode + ", dockId=" + dockId + ", shipFacility=" + shipFacility
				+ ", orderOptionCode=" + orderOptionCode + ", crossDockSubsystem=" + crossDockSubsystem
				+ ", reportingPoint=" + reportingPoint + ", floatTypeUseCode=" + floatTypeUseCode
				+ ", primaryLccnNumber=" + primaryLccnNumber + ", orderPointQuantity=" + orderPointQuantity
				+ ", supplierCountry=" + supplierCountry + ", lastUsageMonth=" + lastUsageMonth + ", groupCode="
				+ groupCode + ", totalNumberOfInboundLccn=" + totalNumberOfInboundLccn + ", pkgDataL=" + pkgDataL
				+ ", pkgDataW=" + pkgDataW + ", pkgDataH=" + pkgDataH + ", orderPointCalculationCode="
				+ orderPointCalculationCode + ", orderPointFactor1=" + orderPointFactor1 + ", rackCapacity="
				+ rackCapacity + ", dzLocationType=" + dzLocationType + ", pickToBroadcastIndicator="
				+ pickToBroadcastIndicator + ", kitIndicator=" + kitIndicator + ", subAssembledIndicator="
				+ subAssembledIndicator + ", meanAbsoluteDeviation=" + meanAbsoluteDeviation
				+ ", purchaseFrequencyRanDaysMethod2=" + purchaseFrequencyRanDaysMethod2
				+ ", purchaseFrequencyRanDaysMethod3=" + purchaseFrequencyRanDaysMethod3 + ", floatVariance="
				+ floatVariance + ", usageVariance=" + usageVariance + ", totalCycleLossQuantity="
				+ totalCycleLossQuantity + "]";
	}

	
}