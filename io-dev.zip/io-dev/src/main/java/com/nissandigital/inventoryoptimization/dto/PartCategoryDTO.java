package com.nissandigital.inventoryoptimization.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO class for adding a new Category
 * 
 * @author Nissan Digital
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartCategoryDTO {

	private long categoryId;
	private long plantId;
	private String partCategoryDescription;
	
	
	public long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}
	public long getPlantId() {
		return plantId;
	}
	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}
	public String getPartCategoryDescription() {
		return partCategoryDescription;
	}
	public void setPartCategoryDescription(String partCategoryDescription) {
		this.partCategoryDescription = partCategoryDescription;
	}
	
	public PartCategoryDTO() {
		super();
	}
	public PartCategoryDTO(long categoryId, long plantId, String partCategoryDesc) {
		super();
		this.categoryId = categoryId;
		this.plantId = plantId;
		this.partCategoryDescription = partCategoryDesc;
	}
	@Override
	public String toString() {
		return "PartCategoryDTO [categoryId=" + categoryId + ", plantId=" + plantId + ", partCategoryDescription="
				+ partCategoryDescription + "]";
	}

	

}
