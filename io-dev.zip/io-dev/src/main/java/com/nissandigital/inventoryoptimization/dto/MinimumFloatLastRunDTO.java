package com.nissandigital.inventoryoptimization.dto;

public class MinimumFloatLastRunDTO {
	
	private Double minimumFloatLastRunDays;
	private Double minimumFloatLastRunHours;
	public Double getMinimumFloatLastRunDays() {
		return minimumFloatLastRunDays;
	}
	public void setMinimumFloatLastRunDays(Double minimumFloatLastRunDays) {
		this.minimumFloatLastRunDays = minimumFloatLastRunDays;
	}
	public Double getMinimumFloatLastRunHours() {
		return minimumFloatLastRunHours;
	}
	public void setMinimumFloatLastRunHours(Double minimumFloatLastRunHours) {
		this.minimumFloatLastRunHours = minimumFloatLastRunHours;
	}



}
