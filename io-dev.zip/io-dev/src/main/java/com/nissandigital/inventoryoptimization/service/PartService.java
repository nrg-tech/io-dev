package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.PartDTO;

/**
 * Service class to handle Part Information and business logics
 * 
 * @author Nissan Digital
 *
 */
public interface PartService {

    /**
     * Fetch the Part details for a particular Part id
     * 
     * @param PartId
     * @return
     */
    PartDTO findPart(long PartId);

	/**
	 * Fetch the list of all available Parts
	 * 
	 * @return List of all Parts
	 */
	List<PartDTO> findAllParts();
	
	
	/**
	 * Method to create a new Part
	 * 
	 * @param employee
	 * @return
	 */
	long createPart(PartDTO Part);
	
	/**
	 * Method to update Part details
	 * 
	 * @param Part
	 * @return
	 */
	long updatePart(PartDTO Part);
	
	/**
	 * Method to delete Part 
	 * 
	 * @param Part
	 * @return
	 */
	void deletePart(long Part);
}
