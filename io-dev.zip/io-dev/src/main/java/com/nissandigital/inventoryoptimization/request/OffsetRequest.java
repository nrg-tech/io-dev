package com.nissandigital.inventoryoptimization.request;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"partId","plantId","userId","offset"})
public class OffsetRequest {

    private long partId;
    private long offsetId;
    private double offsetValue;
    private LocalDate startDate;
    private LocalDate endDate;

    public OffsetRequest() {
    }

    public OffsetRequest(long partId, long plantId, long userId, long offset) {
        this.partId = partId;
        this.offsetId = offset;
    }
    
    

    public double getOffsetValue() {
		return offsetValue;
	}

	public void setOffsetValue(double offsetValue) {
		this.offsetValue = offsetValue;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

    public long getPartId() {
        return partId;
    }
    
    public void setPartId(long partId) {
        this.partId = partId;
    }

    public long getOffsetId() {
        return offsetId;
    }

    public void setOffsetId(long offset) {
        this.offsetId = offset;
    }
}
