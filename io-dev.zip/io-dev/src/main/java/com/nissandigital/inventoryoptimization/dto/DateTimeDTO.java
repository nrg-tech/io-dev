package com.nissandigital.inventoryoptimization.dto;

import java.util.Date;

/**
 * DTO class containing Date Time details
 * 
 * @author Nissan Digital
 *
 */
public class DateTimeDTO {
	private Date date;
	private String timeZone;

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

}
