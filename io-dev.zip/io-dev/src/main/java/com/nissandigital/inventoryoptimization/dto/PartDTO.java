package com.nissandigital.inventoryoptimization.dto;



import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO class containing part details 
 * 
 * @author Nissan Digital
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartDTO {

	private long partId;
	private long plantId;
	private String itemNumber;
	private String itemDescription;
	private char partClassCode;
	private double unitPrice;
	private double operationalReserveQuantity;
	private double minRanOrderQuantity;
	private double snpQuantity;
	private char floatTypeUseCd;
	private double recommendedDays;
	private double recommendedHours;
	private String floatComments;
	private Date loadDate;
	public long getPartId() {
		return partId;
	}
	public void setPartId(long partId) {
		this.partId = partId;
	}
	
	public long getPlantId() {
		return plantId;
	}
	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}
	public void setPartId(Long partId) {
		this.partId = partId;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public char getPartClassCode() {
		return partClassCode;
	}
	public void setPartClassCode(char partClassCode) {
		this.partClassCode = partClassCode;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double d) {
		this.unitPrice = d;
	}
	public double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}
	public void setOperationalReserveQuantity(double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}
	public double getMinRanOrderQuantity() {
		return minRanOrderQuantity;
	}
	public void setMinRanOrderQuantity(double minRanOrderQuantity) {
		this.minRanOrderQuantity = minRanOrderQuantity;
	}
	public double getSnpQuantity() {
		return snpQuantity;
	}
	public void setSnpQuantity(double snpQuantity) {
		this.snpQuantity = snpQuantity;
	}
	public char getFloatTypeUseCd() {
		return floatTypeUseCd;
	}
	public void setFloatTypeUseCd(char floatTypeUseCd) {
		this.floatTypeUseCd = floatTypeUseCd;
	}
	public double getRecommendedDays() {
		return recommendedDays;
	}
	public void setRecommendedDays(double recommendedDays) {
		this.recommendedDays = recommendedDays;
	}
	public double getRecommendedHours() {
		return recommendedHours;
	}
	public void setRecommendedHours(double recommendedHours) {
		this.recommendedHours = recommendedHours;
	}
	public String getFloatComments() {
		return floatComments;
	}
	public void setFloatComments(String floatComments) {
		this.floatComments = floatComments;
	}
	public Date getLoadDate() {
		return loadDate;
	}
	public void setLoadDate(Date string) {
		this.loadDate = string;
	}
	@Override
	public String toString() {
		return "Part [partId=" + partId + ", plantId=" + plantId + ", itemNumber=" + itemNumber
				+ ", itemDescription=" + itemDescription + ", partClassCode=" + partClassCode + ", unitPrice="
				+ unitPrice + ", operationalReserveQuantity=" + operationalReserveQuantity + ", minRanOrderQuantity="
				+ minRanOrderQuantity + ", snpQuantity=" + snpQuantity + ", floatTypeUseCd=" + floatTypeUseCd
				+ ", recommendedDays=" + recommendedDays + ", recommendedHours=" + recommendedHours + ", floatComments="
				+ floatComments + ", loadDate=" + loadDate + "]";
	}


}
