package com.nissandigital.inventoryoptimization.repository;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.request.FilterRequest;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;

@Component
public interface ScheduledRunCustomRepository {

	ScheduleRunDTO findByFilteredParts(ScheduleRunRequest request);
	
	Long findTotalCountOfFilteredData(String condition);

	List<Long> findPartIdWithFilters(Map<String, FilterRequest> filters, long plantId);
}
