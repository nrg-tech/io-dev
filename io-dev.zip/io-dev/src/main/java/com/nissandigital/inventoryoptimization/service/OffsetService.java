package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.OffsetDTO;
import com.nissandigital.inventoryoptimization.request.OffsetRequest;
import com.nissandigital.inventoryoptimization.request.UpdateOffsetAllFilteredPartsRequest;

public interface OffsetService {
	List<OffsetDTO> findAllOffsetsByPlantId(long plantId);

	List<OffsetDTO> updatePartsOffsets(List<OffsetRequest> offsets);
	
	long updateAllFilteredPartOffsets(UpdateOffsetAllFilteredPartsRequest updateRequest);

}
