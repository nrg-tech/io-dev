package com.nissandigital.inventoryoptimization.dto;

import java.util.List;
import java.util.Map;

/**
 * DTO class containing filter details
 * 
 * @author Nissan Digital
 *
 */
public class FilterDTO {



	private Map<String, List<FilterValueDTO>> filter;

	public Map<String, List<FilterValueDTO>> getFilter() {
		return filter;
	}

	public void setFilter(Map<String, List<FilterValueDTO>> filter) {
		this.filter = filter;
	}

	@Override
	public String toString() {
		return "FilterDTO [filter=" + filter + "]";
	}

}