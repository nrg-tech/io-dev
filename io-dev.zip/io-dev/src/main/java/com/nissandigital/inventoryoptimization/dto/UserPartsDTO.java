package com.nissandigital.inventoryoptimization.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO class containing user parts details
 * 
 * @author Nissan Digital
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserPartsDTO {

	private Integer userId;
	private List<Integer> partIds;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public List<Integer> getPartIds() {
		return partIds;
	}

	public void setPartIds(List<Integer> partIds) {
		this.partIds = partIds;
	}

	@Override
	public String toString() {
		return "UserPartsDTO [userId=" + userId + ", partIds=" + partIds + "]";
	}

}
