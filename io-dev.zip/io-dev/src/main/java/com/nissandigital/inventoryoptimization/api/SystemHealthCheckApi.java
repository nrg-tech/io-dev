package com.nissandigital.inventoryoptimization.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "system-health")
public interface SystemHealthCheckApi {

	@ApiOperation(value = "Return the current health of the aws",nickname = "AWSHealthCheck",tags = "test")
	@ApiResponses(value = {
			@ApiResponse(code = 200,message = "aws environment is healthy and running fine")
	})
	@GetMapping(value = "/aws-health")
	ResponseEntity<String> awsHealthCheck();
	
	@ApiOperation(value = "Return the current health of the application",nickname = "checkSystemHealthStatus",tags = "test")
	@ApiResponses(value = {
			@ApiResponse(code = 200,message = "System is healthy and running fine")
	})
	@GetMapping(value = "/health")
	ResponseEntity<String> checkSystemHealthStatus();
}
