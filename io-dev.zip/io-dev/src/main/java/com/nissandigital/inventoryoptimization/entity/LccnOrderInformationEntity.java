package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "io_dwh_dim_lccn_ordr_info", schema = "io_stat_model")
public class LccnOrderInformationEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sk_lccn_ordr_info_id")
	private Long skLccnOrderInformationId;

	@Temporal(TemporalType.DATE)
	@Column(name = "eff_dt")
	private Date effectiveDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "expr_dt")
	private Date expirationDate;

	@Column(name = "lccn_num")
	private Integer lccnNumber;

	@Column(name = "lccn_ver_num")
	private Integer lccnVersionNumber;

	@Column(name = "load_dt")
	private Timestamp loadDate;

	@Column(name = "ordr_pnt_calc_cd")
	private String orderPointCalculationCode;

	@Column(name = "ordr_pnt_fctr_1_rt")
	private Double orderPointFactor1;

	@Column(name = "ordr_typ_cd")
	private String orderTypeCode;

	@Column(name = "part_cls_cd")
	private String partClassCode;

	@Column(name = "plant_id")
	private long plantId;

	@Column(name = "sk_part_id")
	private Long skPartId;

	@Column(name = "xdck_subsys_id")
	private String xdckSubsystemId;

	public Long getSkLccnOrderInformationId() {
		return skLccnOrderInformationId;
	}

	public void setSkLccnOrderInformationId(Long skLccnOrderInformationId) {
		this.skLccnOrderInformationId = skLccnOrderInformationId;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Integer getLccnNumber() {
		return lccnNumber;
	}

	public void setLccnNumber(Integer lccnNumber) {
		this.lccnNumber = lccnNumber;
	}

	public Integer getLccnVersionNumber() {
		return lccnVersionNumber;
	}

	public void setLccnVersionNumber(Integer lccnVersionNumber) {
		this.lccnVersionNumber = lccnVersionNumber;
	}

	public Timestamp getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Timestamp loadDate) {
		this.loadDate = loadDate;
	}

	public String getOrderPointCalculationCode() {
		return orderPointCalculationCode;
	}

	public void setOrderPointCalculationCode(String orderPointCalculationCode) {
		this.orderPointCalculationCode = orderPointCalculationCode;
	}

	public Double getOrderPointFactor1() {
		return orderPointFactor1;
	}

	public void setOrderPointFactor1(Double orderPointFactor1) {
		this.orderPointFactor1 = orderPointFactor1;
	}

	public String getOrderTypeCode() {
		return orderTypeCode;
	}

	public void setOrderTypeCode(String orderTypeCode) {
		this.orderTypeCode = orderTypeCode;
	}

	public String getPartClassCode() {
		return partClassCode;
	}

	public void setPartClassCode(String partClassCode) {
		this.partClassCode = partClassCode;
	}

	public Long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public long getSkPartId() {
		return skPartId;
	}

	public void setSkPartId(Long skPartId) {
		this.skPartId = skPartId;
	}

	public String getXdckSubsystemId() {
		return xdckSubsystemId;
	}

	public void setXdckSubsystemId(String xdckSubsystemId) {
		this.xdckSubsystemId = xdckSubsystemId;
	}

	@Override
	public String toString() {
		return "LccnOrderInformationEntity [skLccnOrderInformationId=" + skLccnOrderInformationId + ", effectiveDate="
				+ effectiveDate + ", expirationDate=" + expirationDate + ", lccnNumber=" + lccnNumber
				+ ", lccnVersionNumber=" + lccnVersionNumber + ", loadDate=" + loadDate + ", orderPointCalculationCode="
				+ orderPointCalculationCode + ", orderPointFactor1=" + orderPointFactor1 + ", orderTypeCode="
				+ orderTypeCode + ", partClassCode=" + partClassCode + ", plantId=" + plantId + ", skPartId=" + skPartId
				+ ", xdckSubsystemId=" + xdckSubsystemId + "]";
	}

}
