package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.FilterDTO;

public interface FilterService {
	
	public FilterDTO getAllFilters(long plantId);

}
