package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.DemandVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.SupplyVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.TopPartsStatisticsOverviewDTO;

/**
 * Service class to retrieve top parts statistics and implementing business
 * logic
 * 
 * @author Nissan Digital
 *
 */
public interface TopPartsStatisticsService {

	/**
	 * Fetches information for demand variability contribution
	 * 
	 * @Returns the demand variability contribution
	 */
	List<DemandVariabilityContributionDTO> getDemandVariabilityContribution();

	/**
	 * Fetches information for supply variability contribution
	 * 
	 * @Returns return the supply variability contribution
	 */
	List<SupplyVariabilityContributionDTO> getSupplyVariabilityContribution();

	/**
	 * Fetches top parts overview information
	 * 
	 * @Returns the top parts overview information
	 */
	List<TopPartsStatisticsOverviewDTO> getTopPartsOverviewDto();
}
