package com.nissandigital.inventoryoptimization.service.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.OffsetDTO;
import com.nissandigital.inventoryoptimization.entity.PartParamCurrMappingEntity;
import com.nissandigital.inventoryoptimization.entity.PartParamEntity;
import com.nissandigital.inventoryoptimization.entity.PartParamIdentity;
import com.nissandigital.inventoryoptimization.repository.PartParamAllRepository;
import com.nissandigital.inventoryoptimization.repository.PartParamCurrRepository;
import com.nissandigital.inventoryoptimization.repository.PartParamRepository;
import com.nissandigital.inventoryoptimization.request.OffsetRequest;
import com.nissandigital.inventoryoptimization.request.UpdateOffsetAllFilteredPartsRequest;
import com.nissandigital.inventoryoptimization.service.OffsetService;
import com.nissandigital.inventoryoptimization.service.UserService;

@Service
public class OffsetServiceImpl implements OffsetService {
	
	@Autowired
	PartParamRepository partParamRepository;
	
	@Autowired
	UserService userService;

	@Autowired
	PartParamCurrRepository partParamCurrRepository;
	
	@Autowired
	PartParamAllRepository partParamAllRepository;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	ScheduleRunServiceImpl scheduledRunServiceImpl;

	@Override
	public List<OffsetDTO> findAllOffsetsByPlantId(long plantId) {
		List<PartParamEntity> paramEntities = partParamRepository.findAllByPlantId(plantId);
		return  paramEntities.stream().filter(w->w.getPartParamType().equalsIgnoreCase("offsets")).map(w-> modelMapper.map(w,OffsetDTO.class)).collect(Collectors.toList());
	}

	@Override
	public List<OffsetDTO> updatePartsOffsets(List<OffsetRequest> offsetDTOs) {
		List<PartParamCurrMappingEntity> insertedPartParamCurrList = partParamCurrRepository.saveAll(convertIntoEntityList(offsetDTOs));
		return insertedPartParamCurrList.stream().map(w -> modelMapper.map(w, OffsetDTO.class)).
                collect(Collectors.toList());
	}

	@Override
	public long updateAllFilteredPartOffsets(UpdateOffsetAllFilteredPartsRequest updateRequest) {
		List<Long> partId = scheduledRunServiceImpl.findPartIdWithFilter(updateRequest.getFilters(),updateRequest.getPlantId());
		List<OffsetRequest> offsetDTOs = new ArrayList<OffsetRequest>();
		partId.stream().forEach((partToUpdate)->{
			updateRequest.getOffsets().forEach((offset)->{
				offset.setPartId(partToUpdate);
			});
			offsetDTOs.addAll(updateRequest.getOffsets());
		});
		updatePartsOffsets(offsetDTOs);
		return 0;
	}
	
	private List<PartParamCurrMappingEntity> convertIntoEntityList(List<OffsetRequest> offsets) {
		return offsets.stream().map(w->expandRangeToEffectiveDate(w)).flatMap(Collection::stream).collect(Collectors.toList());
	}
	
	private List<PartParamCurrMappingEntity> expandRangeToEffectiveDate(OffsetRequest w){
		List<PartParamCurrMappingEntity> partParamList = new ArrayList<PartParamCurrMappingEntity>();
		Timestamp ts = new Timestamp((new Date()).getTime());		
		LocalDate start = w.getStartDate();
		LocalDate end = w.getEndDate().plusDays(1);
		for (LocalDate date = start; date.isBefore(end); date = date.plusDays(1)) {;		
		PartParamIdentity partParamIdentity = new PartParamIdentity(w.getOffsetId(), w.getPartId(), date);
		Optional<PartParamCurrMappingEntity> optionalPartParam = partParamCurrRepository.findById(partParamIdentity);
		PartParamCurrMappingEntity partParam = optionalPartParam.isPresent()?optionalPartParam.get():new PartParamCurrMappingEntity();
		if(partParam.getCreatedBy()==null) {
			partParam.setCreatedBy(userService.getCurrentUser().getUserId());
			partParam.setCreatedDt(ts);
		}
		partParam.setUpdatedBy(userService.getCurrentUser().getUserId());
		partParam.setPartParamIdentity(partParamIdentity);
		partParam.setPartParamVal(w.getOffsetValue());
		partParam.setUpdatedDt(ts);
		partParamList.add(partParam);
		}
		return partParamList;
	}
}
