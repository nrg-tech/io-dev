package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;
import com.nissandigital.inventoryoptimization.dto.RoleDTO;
import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping("/users")
public interface UserApi {

	@ApiOperation(value = "Fetch the information of current user", nickname = "getCurrentUser", notes = "Returns the information of the current user", response = UserDetailsDTO.class, tags = {
			"user" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User information successfully fetched for current user", response = UserDetailsDTO.class),
			@ApiResponse(code = 404, message = "Current user information not found", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/current-user", produces = { "application/json" })
	ResponseEntity<UserDetailsDTO> getCurrentUser();
	

	@ApiOperation(value = "Find name by user role", nickname = "getNameRole", notes = "Returns name based on role", response = UserDetailsDTO.class, tags = {
			"Role" })
			@ApiResponse(code = 200, message = "User information fetched with the given role", response = UserDetailsDTO.class)
	@GetMapping(value = "/role", produces = { "application/json" })
	ResponseEntity<List<UserDetailsDTO>> getUsersByRole(@RequestParam String role);
}
