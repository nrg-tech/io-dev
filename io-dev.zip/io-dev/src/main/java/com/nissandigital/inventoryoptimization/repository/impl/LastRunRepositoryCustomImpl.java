package com.nissandigital.inventoryoptimization.repository.impl;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;

import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.enums.FilterTypeEnum;
import com.nissandigital.inventoryoptimization.exception.ValidationException;
import com.nissandigital.inventoryoptimization.repository.LastRunRepositoryCustom;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.request.FilterRequest;
import com.nissandigital.inventoryoptimization.request.LastRunRequest;

public class LastRunRepositoryCustomImpl implements LastRunRepositoryCustom {

	@Autowired
	private PlantRepository plantRepository;

	@PersistenceContext
	EntityManager entityManager;
	String customQuery;

	@Override
	public List<StatisticalModelOutputViewEntity> findByFilteredParts(String queryString,
			LastRunRequest lastRunRequest) {

		String condition = queryString + " OFFSET " + (lastRunRequest.getPageNumber() * lastRunRequest.getPageSize())
				+ " LIMIT " + lastRunRequest.getPageSize();
		String customQuery = "SELECT * FROM io_stat_model.io_mv_sm_op_curr " + condition;
		Query query = entityManager.createNativeQuery(customQuery, StatisticalModelOutputViewEntity.class);
		return query.getResultList();
	}

	@Override
	public long findTotalCountOfFilteredData(String condition) {

		String customQuery = "SELECT * FROM io_stat_model.io_mv_sm_op_curr " + condition;
		Query query = entityManager.createNativeQuery(customQuery, StatisticalModelOutputViewEntity.class);
		return (query.getResultList().size());

	}

	@Override
	public String generateQueryCondition(LastRunRequest lastRunRequest) {
		String plantCode = plantRepository.findByPlantId(lastRunRequest.getPlantId()).get(0).getPlantCode();
		StringBuilder query = new StringBuilder(" where plant_cd= '" + plantCode + "'");
		Map<String, FilterRequest> filters = lastRunRequest.getFilterRequest();
		if (filters != null) {
			String s = filters.entrySet().stream().map(w -> generateQuery(w)).collect(Collectors.joining());
			query.append(s);
		}
		return query.toString();
	}

	public StringBuilder generateQuery(Entry<String, FilterRequest> filters) {
		StringBuilder query = new StringBuilder();

		if (filters.getValue().getType() == FilterTypeEnum.LIST) {
			query.append(" AND " + entityTableNameMapping(filters.getKey()) + " IN "
					+ convertList(filters.getValue().getValues(), filters.getValue().getValuesType()));
		} else if (filters.getValue().getType() == FilterTypeEnum.RANGE) {
			query.append(" AND " + entityTableNameMapping(filters.getKey()) + " BETWEEN " + filters.getValue().getMin()
					+ " AND " + filters.getValue().getMax());
		} else {
			throw new ValidationException("Incorrect type information");
		}
		return query;

	}

	public String convertList(List<?> data, String type) {
		StringBuilder query = new StringBuilder("(");
		int size = data.size();

		for (int i = 1; i <= size; i++) {
			if (i != 1) {
				query.append(",");
			}
			if (type.equalsIgnoreCase("numeric")) {
				query.append(data.get(i - 1));
			} else {
				query.append("'" + data.get(i - 1) + "'");
			}
		}
		query.append(")");
		return query.toString();
	}

	private String entityTableNameMapping(String tableColumn) {
		return InventoryOptimizationUtils.columnMap.getOrDefault(tableColumn, null);
	}

}
