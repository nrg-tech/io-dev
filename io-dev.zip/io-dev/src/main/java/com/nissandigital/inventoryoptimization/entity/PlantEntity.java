package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistence class for the io_plant_master database table.
 * 
 * @author Nissan Digital
 * 
 */
@Entity
@Table(name = "io_plant_master", schema = "io_stat_model")
@NamedQuery(name = "PlantEntity.findAll", query = "SELECT i FROM PlantEntity i")
public class PlantEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "plant_id")
	private long plantId;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Timestamp createdDate;

	@Column(name = "curr_code")
	private String currentCode;

	@Column(name = "time_zone")
	private String timeZone;

	@Column(name = "plant_cd")
	private String plantCode;

	@Column(name = "plant_name")
	private String plantName;

	@Column(name = "upd_by")
	private String uploadedBy;

	@Column(name = "upd_dt")
	private Timestamp uploadDate;
    
	@OneToMany(mappedBy = "plantEntity", cascade = CascadeType.ALL)
    private List<PartCategoryEntity> partCategory;
	
	
	
	public List<PartCategoryEntity> getPartCategory() {
		return partCategory;
	}

	public void setPartCategory(List<PartCategoryEntity> partCategory) {
		this.partCategory = partCategory;
	}

	public PlantEntity() {
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the plantId
	 */
	public long getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDt) {
		this.createdDate = createdDt;
	}

	/**
	 * @return the currentCode
	 */
	public String getCurrentCode() {
		return currentCode;
	}

	/**
	 * @param currentCode the currentCode to set
	 */
	public void setCurrentCode(String currCode) {
		this.currentCode = currCode;
	}

	/**
	 * @return the plantCode
	 */
	public String getPlantCode() {
		return plantCode;
	}

	/**
	 * @param plantCode the plantCode to set
	 */
	public void setPlantCode(String plantCd) {
		this.plantCode = plantCd;
	}

	/**
	 * @return the plantName
	 */
	public String getPlantName() {
		return plantName;
	}

	/**
	 * @param plantName the plantName to set
	 */
	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return uploadedBy;
	}

	/**
	 * @param uploadedBy the uploadedBy to set
	 */
	public void setUploadedBy(String updBy) {
		this.uploadedBy = updBy;
	}

	/**
	 * @return the uploadDate
	 */
	public Timestamp getUploadDate() {
		return uploadDate;
	}

	/**
	 * @param uploadDate the uploadDate to set
	 */
	public void setUploadDate(Timestamp updDt) {
		this.uploadDate = updDt;
	}

}