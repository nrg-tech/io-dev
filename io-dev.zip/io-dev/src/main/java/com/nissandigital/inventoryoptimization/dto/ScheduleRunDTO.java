package com.nissandigital.inventoryoptimization.dto;

import java.util.List;

public class ScheduleRunDTO {
	private long totalRows;
	private long totalFilteredRows;
	private List<PartResponseDTO> parts;
	/**
	 * @return the totalRows
	 */
	public long getTotalRows() {
		return totalRows;
	}
	/**
	 * @param totalRows the totalRows to set
	 */
	public void setTotalRows(long totalRows) {
		this.totalRows = totalRows;
	}
	/**
	 * @return the totalFilteredRows
	 */
	public long getTotalFilteredRows() {
		return totalFilteredRows;
	}
	/**
	 * @param totalFilteredRows the totalFilteredRows to set
	 */
	public void setTotalFilteredRows(long totalFilteredRows) {
		this.totalFilteredRows = totalFilteredRows;
	}
	/**
	 * @return the parts
	 */
	public List<PartResponseDTO> getParts() {
		return parts;
	}
	/**
	 * @param parts the parts to set
	 */
	public void setParts(List<PartResponseDTO> parts) {
		this.parts = parts;
	}
	
}
