package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "io_dwh_dim_lccn_info", schema = "io_stat_model")
public class LccnInformationEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sk_lccn_info_id")
	private Long skLccnInformationId;

	@Temporal(TemporalType.DATE)
	@Column(name = "eff_dt")
	private Date effectiveDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "expr_dt")
	private Date expirationDate;

	@Column(name = "lccn_num")
	private Integer lccnNumber;

	@Column(name = "lccn_typ_cd")
	private String lccnTypeCode;

	@Column(name = "lccn_ver_num")
	private Integer lccnVersionNumber;

	@Column(name = "lctn_cn")
	private Integer location;

	@Column(name = "lctn_tx")
	private String locationType;

	@Column(name = "load_dt")
	private Timestamp loadDate;

	@Column(name = "part_cls_cd")
	private String partClassCode;

	@Column(name = "plant_id")
	private long plantId;

	@Column(name = "rack_cpcty_qt")
	private Integer rackCapacityQuantity;

	@Column(name = "sk_part_id")
	private Long skPartId;

	public Long getSkLccnInformationId() {
		return skLccnInformationId;
	}

	public void setSkLccnInformationId(Long skLccnInformationId) {
		this.skLccnInformationId = skLccnInformationId;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Integer getLccnNumber() {
		return lccnNumber;
	}

	public void setLccnNumber(Integer lccnNumber) {
		this.lccnNumber = lccnNumber;
	}

	public String getLccnTypeCode() {
		return lccnTypeCode;
	}

	public void setLccnTypeCode(String lccnTypeCode) {
		this.lccnTypeCode = lccnTypeCode;
	}

	public Integer getLccnVersionNumber() {
		return lccnVersionNumber;
	}

	public void setLccnVersionNumber(Integer lccnVersionNumber) {
		this.lccnVersionNumber = lccnVersionNumber;
	}

	public Integer getLocation() {
		return location;
	}

	public void setLocation(Integer location) {
		this.location = location;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public Timestamp getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Timestamp loadDate) {
		this.loadDate = loadDate;
	}

	public String getPartClassCode() {
		return partClassCode;
	}

	public void setPartClassCode(String partClassCode) {
		this.partClassCode = partClassCode;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public Integer getRackCapacityQuantity() {
		return rackCapacityQuantity;
	}

	public void setRackCapacityQuantity(Integer rackCapacityQuantity) {
		this.rackCapacityQuantity = rackCapacityQuantity;
	}

	public Long getSkPartId() {
		return skPartId;
	}

	public void setSkPartId(Long skPartId) {
		this.skPartId = skPartId;
	}

	@Override
	public String toString() {
		return "LccnInformationEntity [skLccnInformationId=" + skLccnInformationId + ", effectiveDate=" + effectiveDate
				+ ", expirationDate=" + expirationDate + ", lccnNumber=" + lccnNumber + ", lccnTypeCode=" + lccnTypeCode
				+ ", lccnVersionNumber=" + lccnVersionNumber + ", location=" + location + ", locationType="
				+ locationType + ", loadDate=" + loadDate + ", partClassCode=" + partClassCode + ", plantId=" + plantId
				+ ", rackCapacityQuantity=" + rackCapacityQuantity + ", skPartId=" + skPartId + "]";
	}

}
