package com.nissandigital.inventoryoptimization.dto;

public class MinimumFloatCurrentDTO {
	
	private Double minimumFloatCurrentDays;
	private Double minimumFloatCurrentHours;
	public Double getMinimumFloatCurrentDays() {
		return minimumFloatCurrentDays;
	}
	public void setMinimumFloatCurrentDays(Double minimumFloatCurrentDays) {
		this.minimumFloatCurrentDays = minimumFloatCurrentDays;
	}
	public Double getMinimumFloatCurrentHours() {
		return minimumFloatCurrentHours;
	}
	public void setMinimumFloatCurrentHours(Double minimumFloatCurrentHours) {
		this.minimumFloatCurrentHours = minimumFloatCurrentHours;
	}


	
	

}
