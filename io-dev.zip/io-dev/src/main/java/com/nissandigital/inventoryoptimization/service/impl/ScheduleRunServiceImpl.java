package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.repository.LastRunRepository;
import com.nissandigital.inventoryoptimization.repository.PartParamCurrRepository;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.repository.ScheduledRunCustomRepository;
import com.nissandigital.inventoryoptimization.request.FilterRequest;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;
import com.nissandigital.inventoryoptimization.service.ScheduleRunService;

@Service
public class ScheduleRunServiceImpl implements ScheduleRunService {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PartParamCurrRepository partParamCurrRepository;

	@Autowired
	LastRunRepository lastRunRepository;

	@Autowired
	PartRepository partRepository;

	@Autowired
	PlantRepository plantRepository;
	
	@Autowired
	ScheduledRunCustomRepository scheduledRunCustomRepository;

	public List<Long> findPartIdWithFilter(Map<String, FilterRequest> filters, long plantId)
	{
		return scheduledRunCustomRepository.findPartIdWithFilters(filters,plantId);
	}
	
	@Override
	public ScheduleRunDTO findAllScheduleRun(ScheduleRunRequest request) {
		ScheduleRunDTO response = scheduledRunCustomRepository.findByFilteredParts(request);
		response.setTotalRows(lastRunRepository.countByPlantCode(plantRepository.findById(request.getPlantId()).get().getPlantCode()));
		return response;
	}
}
