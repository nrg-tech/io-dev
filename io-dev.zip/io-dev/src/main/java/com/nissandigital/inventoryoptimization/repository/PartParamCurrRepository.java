package com.nissandigital.inventoryoptimization.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.PartEntity;
import com.nissandigital.inventoryoptimization.entity.PartParamCurrMappingEntity;
import com.nissandigital.inventoryoptimization.entity.PartParamIdentity;

@Repository
public interface PartParamCurrRepository extends JpaRepository<PartParamCurrMappingEntity, PartParamIdentity>{

	List<PartParamCurrMappingEntity> findByPartParamIdentityEffectDtAndPartParamEntityPlantIdAndDimPartsMasterPartIdIn(LocalDate effectDt,long plantId,List<Long> dimPartsMaster);
	List<PartParamCurrMappingEntity> findByPartParamIdentityEffectDtAndPartParamEntityPlantId(LocalDate effectDt,long plantId);
	List<PartParamCurrMappingEntity> findByDimPartsMasterIn(List<PartEntity> part);
//	List<String> findAllPartParamDescByPartParamIdentityEffectDtAndPartParamEntityPlantId(LocalDate effectDt,long plantId);

}
