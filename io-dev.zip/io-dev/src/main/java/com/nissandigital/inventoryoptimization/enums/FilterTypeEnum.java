package com.nissandigital.inventoryoptimization.enums;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum FilterTypeEnum {
	
	LIST("list"),RANGE("range");
	
	private String value;

	private FilterTypeEnum(String value) {
		this.value = value;
	}

	@JsonCreator
	public static FilterTypeEnum fromValue(String value) {
		for (FilterTypeEnum type : values()) {
			if (type.value.equalsIgnoreCase(value)) {
				return type;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + value + ", Allowed values are " + Arrays.toString(values()));
	}
	
	@JsonValue
	public String toJson() {
		return name().toLowerCase();
	}

}