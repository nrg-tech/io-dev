package com.nissandigital.inventoryoptimization.api;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.dto.UserPartsDTO;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "user-parts")
public interface UserPartsApi {

	
	@ApiOperation(value = "Mapping the  parts with specific parts controller", nickname = "UserParts", notes = "", tags={"UserParts"})
    @ApiResponses(value = { 
    	@ApiResponse(code = 200, message = "Parts are successfully mapped with user", response = Status.class),
        @ApiResponse(code = 404, message = "User Id not found",response = NoDataFoundException.class)})
    @PostMapping( value ="/parts-controller-mapping",
        produces = { "application/json" }, 
        consumes = { "application/json" })
    ResponseEntity<Status> addPartsToPartsController(@ApiParam(value = "Parts that needs to be mapped with Parts Controller in inventory optimization" ,required=true )  @Valid @RequestBody UserPartsDTO userPartsDTO);
    
	
}
