package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.PlantEntity;

/**
 * Repository class for performing database operations on plant master entity
 * 
 * @author Nissan Digital
 *
 */
@Repository
public interface PlantRepository extends CrudRepository<PlantEntity, Long> {

	/**
	 * Fetches the plant information for the given plant ID
	 * 
	 * @Returns the plant information for the given plant ID
	 */
	List<PlantEntity> findByPlantId(long plantId);
	
	PlantEntity findPlantCodeByPlantId(long plantId);
}
