package com.nissandigital.inventoryoptimization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.ScheduleRunApi;
import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;
import com.nissandigital.inventoryoptimization.service.ScheduleRunService;

import io.swagger.annotations.Api;

@RestController
@CrossOrigin
@Api(tags = "ScheduleRun")
public class ScheduleRunController implements ScheduleRunApi {

	@Autowired
	private ScheduleRunService scheduleRunService;

	@Override
	public ResponseEntity<ScheduleRunDTO> getAllScheduleRunView(ScheduleRunRequest request) {

		return new ResponseEntity<ScheduleRunDTO>(scheduleRunService.findAllScheduleRun(request),
				HttpStatus.OK);
	}

}
