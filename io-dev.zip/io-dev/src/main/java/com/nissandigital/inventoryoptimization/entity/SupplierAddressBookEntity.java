package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

/**
 * The persistent class for the io_dwh_dim_suplr_addr_bk database table.
 * 
 */
@Entity
@Table(name = "io_dwh_dim_suplr_addr_bk", schema = "io_stat_model")
public class SupplierAddressBookEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sk_suplr_id")
	private long skSupplierId;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "load_dt")
	private Timestamp loadDate;

	@Column(name = "state_code")
	private String stateCode;

	@Column(name = "suplr_addr_code")
	private String supplierAddressCode;

	@Column(name = "suplr_code")
	private String supplierCode;

	@Column(name = "suplr_status_code")
	private String supplierStatusCode;

	@Column(name = "suplr_type")
	private String supplierType;

	@Column(name = "zip_code")
	private String zipCode;

	@Column(name = "suplr_name")
	private String supplierName;

	@Column(name = "addr")
	private String address;

	@Column(name = "city")
	private String city;

	public long getSkSupplierId() {
		return skSupplierId;
	}

	public void setSkSupplierId(long skSupplierId) {
		this.skSupplierId = skSupplierId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Timestamp getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Timestamp loadDate) {
		this.loadDate = loadDate;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getSupplierAddressCode() {
		return supplierAddressCode;
	}

	public void setSupplierAddressCode(String supplierAddressCode) {
		this.supplierAddressCode = supplierAddressCode;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierStatusCode() {
		return supplierStatusCode;
	}

	public void setSupplierStatusCode(String supplierStatusCode) {
		this.supplierStatusCode = supplierStatusCode;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "SupplierAddressBookEntity [skSupplierId=" + skSupplierId + ", countryCode=" + countryCode
				+ ", loadDate=" + loadDate + ", stateCode=" + stateCode + ", supplierAddressCode=" + supplierAddressCode
				+ ", supplierCode=" + supplierCode + ", supplierStatusCode=" + supplierStatusCode + ", supplierType="
				+ supplierType + ", zipCode=" + zipCode + ", supplierName=" + supplierName + ", address=" + address
				+ ", city=" + city + "]";
	}

}
