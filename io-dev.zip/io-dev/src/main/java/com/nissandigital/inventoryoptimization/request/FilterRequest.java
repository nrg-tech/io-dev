package com.nissandigital.inventoryoptimization.request;

import java.util.List;

import com.nissandigital.inventoryoptimization.enums.FilterTypeEnum;

public class FilterRequest {

	private FilterTypeEnum type;
	private double min;
	private double max;
	private String valuesType;
	private List<?> values;

	/**
	 * @return the valuesType
	 */
	public String getValuesType() {
		return valuesType;
	}

	/**
	 * @param valuesType the valuesType to set
	 */
	public void setValuesType(String valuesType) {
		this.valuesType = valuesType;
	}

	/**
	 * @param type the type to set
	 */

	public FilterTypeEnum getType() {
		return type;
	}

	public void setType(FilterTypeEnum type) {
		this.type = type;
	}

	/**
	 * @return the min
	 */
	public double getMin() {
		return min;
	}

	/**
	 * @param min the min to set
	 */
	public void setMin(double min) {
		this.min = min;
	}

	/**
	 * @return the max
	 */
	public double getMax() {
		return max;
	}

	/**
	 * @param max the max to set
	 */
	public void setMax(double max) {
		this.max = max;
	}

	/**
	 * @return the values
	 */
	public List<?> getValues() {
		return values;
	}

	/**
	 * @param values the values to set
	 */
	public void setValues(List<?> values) {
		this.values = values;
	}

}
