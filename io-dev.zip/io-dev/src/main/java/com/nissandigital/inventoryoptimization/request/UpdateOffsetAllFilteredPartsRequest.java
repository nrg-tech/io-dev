package com.nissandigital.inventoryoptimization.request;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateOffsetAllFilteredPartsRequest {

	private long plantId;
	private List<OffsetRequest> offsets;
	private Map<String, FilterRequest> filters;

	/**
	 * @return the plantId
	 */
	public long getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	/**
	 * @return the offsets
	 */
	public List<OffsetRequest> getOffsets() {
		return offsets;
	}

	/**
	 * @param offsets the offsets to set
	 */
	public void setOffsets(List<OffsetRequest> offsets) {
		this.offsets = offsets;
	}

	/**
	 * @return the filters
	 */
	public Map<String, FilterRequest> getFilters() {
		return filters;
	}

	/**
	 * @param filters the filters to set
	 */
	public void setFilters(Map<String, FilterRequest> filters) {
		this.filters = filters;
	}

}