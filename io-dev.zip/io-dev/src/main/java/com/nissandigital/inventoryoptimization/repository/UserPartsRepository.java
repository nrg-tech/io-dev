package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.nissandigital.inventoryoptimization.entity.UserPartsEntity;
import com.nissandigital.inventoryoptimization.entity.UserPartsIdentity;

public interface UserPartsRepository extends JpaRepository<UserPartsEntity, UserPartsIdentity> {
	@Query(value = "select iup.userPartsIdentity.userId from UserPartsEntity iup where iup.userPartsIdentity.partId in :partIdList")
	List<Long> findPartsControllerInfoByPartIds(List<Long> partIdList);
 
}
