package com.nissandigital.inventoryoptimization.controller;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.nissandigital.inventoryoptimization.api.SystemHealthCheckApi;
import com.nissandigital.inventoryoptimization.utils.aws.AwsSecretManager;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "test")
public class SystemHealthCheckController implements SystemHealthCheckApi{

	@Override
	public ResponseEntity<String> awsHealthCheck() {
		AwsSecretManager awsSecretManager = new AwsSecretManager();
		try {
			awsSecretManager.initialize();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String value = awsSecretManager.getSecretValue("username") + " " + awsSecretManager.getSecretValue("password");
		return new ResponseEntity<String>("Running - values = " + value ,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> checkSystemHealthStatus() {
		// TODO Auto-generated method stub
		return new ResponseEntity<String>("I'm running", HttpStatus.OK);
	}

}
