package com.nissandigital.inventoryoptimization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.FilterApi;
import com.nissandigital.inventoryoptimization.dto.FilterDTO;
import com.nissandigital.inventoryoptimization.service.FilterService;

import io.swagger.annotations.Api;

@RestController
@Api( value = "filters")
public class FilterController implements FilterApi{
	
	@Autowired
	private FilterService filterService;

	@Override
	public ResponseEntity<FilterDTO> getFilters(long plantId) {
		FilterDTO filterDTO = filterService.getAllFilters(plantId);
		return new ResponseEntity<>(filterDTO, HttpStatus.OK);
	}

}
