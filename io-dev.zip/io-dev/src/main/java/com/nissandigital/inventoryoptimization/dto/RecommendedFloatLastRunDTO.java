package com.nissandigital.inventoryoptimization.dto;

public class RecommendedFloatLastRunDTO {
	
	private Double recommendedFloatDaysLastRun;
	private Double recommendedFloatHoursLastRun;
	public Double getRecommendedFloatDaysLastRun() {
		return recommendedFloatDaysLastRun;
	}
	public void setRecommendedFloatDaysLastRun(Double recommendedFloatDaysLastRun) {
		this.recommendedFloatDaysLastRun = recommendedFloatDaysLastRun;
	}
	public Double getRecommendedFloatHoursLastRun() {
		return recommendedFloatHoursLastRun;
	}
	public void setRecommendedFloatHoursLastRun(Double recommendedFloatHoursLastRun) {
		this.recommendedFloatHoursLastRun = recommendedFloatHoursLastRun;
	}


	
	
	 

}
