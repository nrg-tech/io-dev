package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class PartParamIdentity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1840743103935772096L;
	@NotNull
	@Column(name = "part_param_id")
	private Long partParamId;
	@NotNull
	@Column(name = "sk_part_id")
	private Long skPartId;

	@Column(name = "effect_dt")
	private LocalDate effectDt;

	public PartParamIdentity() {
	}

	public PartParamIdentity(@NotNull Long partParamId, @NotNull Long skPartId,LocalDate effectDate) {
		this.partParamId = partParamId;
		this.skPartId = skPartId;
		this.effectDt = effectDate;
	}

	public Long getPartParamId() {
		return partParamId;
	}

	public void setPartParamId(Long partParamId) {
		this.partParamId = partParamId;
	}

	public Long getSkPartId() {
		return skPartId;
	}

	public void setSkPartId(Long skPartId) {
		this.skPartId = skPartId;
	}

	public LocalDate getEffectDate() {
		return effectDt;
	}

	public void setEffectDate(LocalDate effectDate) {
		this.effectDt = effectDate;
	}

}
