package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.LastRunDTO;
import com.nissandigital.inventoryoptimization.dto.PageDTO;
import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.repository.LastRunRepository;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.request.LastRunRequest;
import com.nissandigital.inventoryoptimization.service.LastRunService;

/**
 * @author Nissan Digital
 * 
 *         Implementation class for Last Run Details service
 *
 */
@Service
public class LastRunServiceImpl implements LastRunService {

	@Autowired
	LastRunRepository lastRunRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PlantRepository plantRepository;

	@Override
	public PageDTO getPaginatedData(LastRunRequest lastRunRequest) {
		PageDTO response = new PageDTO();
		String plantCode = plantRepository.findByPlantId(lastRunRequest.getPlantId()).get(0).getPlantCode();
		String query = lastRunRepository.generateQueryCondition(lastRunRequest);

		List<StatisticalModelOutputViewEntity> parts = lastRunRepository.findByFilteredParts(query, lastRunRequest);
		response.setTotalItems(lastRunRepository.countByPlantCode(plantCode));
		List<LastRunDTO> lastRunDTOs = parts.stream().map(w -> modelMapper.map(w, LastRunDTO.class))
				.collect(Collectors.toList());
		response.setNumberOfFilteredRows(lastRunRepository.findTotalCountOfFilteredData(query));

		response.setLastRunDTOs(lastRunDTOs);

		return response;
	}
}
