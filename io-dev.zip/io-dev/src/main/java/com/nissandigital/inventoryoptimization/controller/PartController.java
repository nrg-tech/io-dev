package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.PartApi;
import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.PartDTO;
import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.service.PartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

/**
* Controller which handles the parts details
* 
* @author Nissan Digital
*
*/
@RestController
@Api(tags = "Part")
public class PartController implements PartApi{

    private static Logger LOGGER = LoggerFactory
            .getLogger(PartController.class);

    @Autowired
    PartService partService;
    
    @Override
	public ResponseEntity<PartDTO> getPartById(@ApiParam(value = "Find the part details based on the part id",required=true) @PathVariable("partId") int partId) {
    	PartDTO partDTO  = partService.findPart(partId);
    	String message = String.format("Fetched the details for the part with code : %s",partId);
    	LOGGER.debug(message);
        return new ResponseEntity<>(partDTO,HttpStatus.OK);
    }
    
    
    @Override
   	public ResponseEntity<List<PartDTO>> getAllParts() {
       	List<PartDTO> partList = partService.findAllParts();
       	LOGGER.debug("Successfully fetched all parts");
        return new ResponseEntity<>(partList,HttpStatus.OK);
   	}
    
    
  
    @Override
	public ResponseEntity<Status> addPart(@ApiParam(value = "Part details that needs to be added to inventory optimization" ,required=true )  @Valid @RequestBody PartDTO part) {
    	long partId = partService.createPart(part);
    	String message = String.format("Created part with partId: %s", partId);
    	LOGGER.debug(message);
        return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message),HttpStatus.CREATED);
    }
    

    @Override
	public ResponseEntity<Status> updatePart(@ApiParam(value = "Part details that needs to be updated in idms" ,required=true )  @Valid @RequestBody PartDTO part) {
    	long partId = partService.updatePart(part);
    	String message = String.format("Updated Part with Partcode : %s",partId);
    	LOGGER.debug(message);
        return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message),HttpStatus.OK);
    }
  
    
    @Override
	public ResponseEntity<Status> deletePart(@ApiParam(value = "Part code of part to be delete",required=true) @PathVariable("partId") int partId) {
    	partService.deletePart(partId);
    	String message = String.format("Deleted part with partcode: %s",partId);
    	LOGGER.debug(message);
        return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message),HttpStatus.OK);
    }   

}
