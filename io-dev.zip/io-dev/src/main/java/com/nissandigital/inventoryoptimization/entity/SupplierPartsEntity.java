package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "IO_PART_SUPPLIER",schema="io_stat_model")
public class SupplierPartsEntity implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SupplierPartsIdentity supplierPartsIdentity;
	
	@Column(name = "CREATED_BY")
	private long createdBy;
	
	@Column(name = "CREATED_DT")
    @Temporal(TemporalType.TIMESTAMP)
	private Date createdDt;
	
	@Column(name = "UPDATED_BY")
	private long updatedBy;
	
	@Column(name = "UPDATED_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDt;

	public SupplierPartsIdentity getSupplierPartsIdentity() {
		return supplierPartsIdentity;
	}

	public void setSupplierPartsIdentity(SupplierPartsIdentity supplierPartsIdentity) {
		this.supplierPartsIdentity = supplierPartsIdentity;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
