package com.nissandigital.inventoryoptimization.request;

import java.util.List;
import java.util.Map;

public class LastRunRequest {

	long plantId;
	int pageNumber;
	int pageSize;
	Map<String, FilterRequest> filterRequest;

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public Map<String, FilterRequest> getFilterRequest() {
		return filterRequest;
	}

	public void setFilterRequest(Map<String, FilterRequest> filterRequest) {
		this.filterRequest = filterRequest;
	}

}
