package com.nissandigital.inventoryoptimization.repository;

import org.springframework.data.repository.CrudRepository;

import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewIdentity;

/**
 * Repository class for performing database operations on Statistical Model View
 * Entity
 * 
 * @author Nissan Digital
 *
 */
public interface LastRunRepository extends
		CrudRepository<StatisticalModelOutputViewEntity, StatisticalModelOutputViewIdentity>, LastRunRepositoryCustom {

	long countByPlantCode(String plantCode);

	
	StatisticalModelOutputViewEntity findByPlantCodeAndPartNumber(String plantCode,String partNumber);
}
