
package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.RoleDTO;
import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;

/**
 * Service class to handle user Information and business logic
 * 
 * @author Nissan Digital
 *
 */
public interface UserService {
	
	/**
     * Fetch the information of current user
     * 
     * @Returns the information of the current user
     */
	UserDetailsDTO getCurrentUser();
	
	public List<UserDetailsDTO> findUserByRole(String role);
	
}
