package com.nissandigital.inventoryoptimization.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.ScheduleRunDTO;
import com.nissandigital.inventoryoptimization.request.ScheduleRunRequest;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "schedule-run")
public interface ScheduleRunApi {

    @ApiOperation(value = "Returns all schedule run records for each part", nickname = "getAllScheduleRunView", notes = "Returns all schedule run records for each part", response = ScheduleRunDTO.class, responseContainer = "List", tags = {
            "ScheduleRun"})
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "List of all schedule run records for each part", response = ScheduleRunDTO.class, responseContainer = "List")})
    @PostMapping(value = "/", produces = {"application/json"})
    ResponseEntity<ScheduleRunDTO> getAllScheduleRunView(
            @RequestBody(required = true)ScheduleRunRequest request);

}