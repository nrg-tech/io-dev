package com.nissandigital.inventoryoptimization.dto;

/**
 * Standard error message class for exceptions thrown by API calls.
 * 
 */
public class InventoryOptimizationError {

    private String errorMessage;

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}