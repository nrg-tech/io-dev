
package com.nissandigital.inventoryoptimization.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OffsetDTO {

	@JsonProperty("offsetId")
	private long partParamId;
	
	@JsonProperty("offsetDescription")
	private String partParamDesc;

	/**
	 * @return the partParamId
	 */
	public long getPartParamId() {
		return partParamId;
	}

	/**
	 * @param partParamId the partParamId to set
	 */
	public void setPartParamId(long partParamId) {
		this.partParamId = partParamId;
	}

	/**
	 * @return the partParamDesc
	 */
	public String getPartParamDesc() {
		return partParamDesc;
	}

	/**
	 * @param partParamDesc the partParamDesc to set
	 */
	public void setPartParamDesc(String partParamDesc) {
		this.partParamDesc = partParamDesc;
	}
	
	
}