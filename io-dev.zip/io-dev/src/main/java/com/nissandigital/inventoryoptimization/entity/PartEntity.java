package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the part database table.
 * 
 */
@Entity
@Table(name = "IO_DWH_DIM_PARTS_MASTER", schema = "io_stat_model")
public class PartEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SK_PART_ID")
	private long partId;

	@Column(name = "PLANT_ID")
	private long plantId;

	@Column(name = "ITEM_NUM")
	private String itemNumber;

	@Column(name = "ITEM_DESC")
	private String itemDescription;

	@Column(name = "ITEM_TYPE")
	private String itemType;

	@Column(name = "PART_CLS_CD")
	private char partClassCode;

	@Column(name = "UNIT_PRICE")
	private double unitPrice;

	@Column(name = "OPRTNL_RSRV_QTY")
	private double operationalReserveQuantity;

	@Column(name = "MIN_RAN_ORDR_QTY")
	private double minRanOrderQuantity;

	@Column(name = "SNP_QTY")
	private double snpQuantity;

	@Column(name = "FLOAT_TYPE_USE_CD")
	private char floatTypeUseCd;

	@Column(name = "FLOAT_RECOM_DAYS")
	private double recommendedDays;

	@Column(name = "FLOAT_RECOM_HRS")
	private double recommendedHours;

	@Column(name = "FLOAT_COMMENTS")
	private String floatComments;

	@Column(name = "LOAD_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date loadDate;

	@Column(name = "analyst_cde")
	private String analystCde;

	@Column(name = "grp_cde")
	private String groupCde;

	@Column(name = "lccn_dck_id")
	private String lccnDockId;

	@Column(name = "lccn_typ_cd")
	private String lccnTypeCode;

	@Temporal(TemporalType.DATE)
	@Column(name = "lst_req_dt")
	private Date lstRequestDate;

	@Column(name = "max_ran_ordr_qty")
	private Double maxRandomOrderQuantity;

	@Column(name = "min_lvl_days")
	private Double minLvlDays;

	@Column(name = "min_lvl_hrs")
	private Double minLvlHrs;

	@Column(name = "oprtnl_rsrv_val")
	private Double oprtnlRsrvVal;

	@Column(name = "order_point_qty")
	private Double orderPointQty;

	@Column(name = "part_rpt_pt")
	private Double partRptPt;

	@Column(name = "parts_usg_ind")
	private String partsUsgInd;

	@Column(name = "primary_lccn_num")
	private Integer primaryLccnNum;

	@Column(name = "ship_facl_id")
	private String shipFaclId;

	@Column(name = "ship_facl_type_cd")
	private String shipFaclTypeCd;

	@Column(name = "suplr_code")
	private String suplrCode;

	@Column(name = "suplr_type")
	private String suplrType;

	@Column(name = "transit_time_days")
	private Double transitTimeDays;

	@Column(name = "transit_time_hrs")
	private Double transitTimeHrs;

	@Column(name = "unit_load_qty")
	private Double unitLoadQty;

	@Column(name = "xdck_ord_opt_cde")
	private String xdckOrdOptCde;

	@Column(name = "xdck_subsys_id")
	private String xdckSubsysId;

	@Column(name = "PART_TYPE_CD")
	private String partTypeCode;

	@OneToMany(mappedBy = "partEntity", cascade = CascadeType.ALL)
	private List<PartCategoryMappingEntity> partCategoryMappingEntities;

	public List<PartCategoryMappingEntity> getPartCategoryMappingEntities() {
		return partCategoryMappingEntities;
	}

	public void setPartCategoryMappingEntities(List<PartCategoryMappingEntity> partCategoryMappingEntities) {
		this.partCategoryMappingEntities = partCategoryMappingEntities;
	}

	public String getAnalystCde() {
		return analystCde;
	}

	public void setAnalystCde(String analystCde) {
		this.analystCde = analystCde;
	}

	public String getGroupCde() {
		return groupCde;
	}

	public void setGroupCde(String groupCde) {
		this.groupCde = groupCde;
	}

	public String getLccnDockId() {
		return lccnDockId;
	}

	public void setLccnDockId(String lccnDockId) {
		this.lccnDockId = lccnDockId;
	}

	public String getLccnTypeCode() {
		return lccnTypeCode;
	}

	public void setLccnTypeCode(String lccnTypeCode) {
		this.lccnTypeCode = lccnTypeCode;
	}

	public Date getLstRequestDate() {
		return lstRequestDate;
	}

	public void setLstRequestDate(Date lstRequestDate) {
		this.lstRequestDate = lstRequestDate;
	}

	public Double getMaxRandomOrderQuantity() {
		return maxRandomOrderQuantity;
	}

	public void setMaxRandomOrderQuantity(Double maxRandomOrderQuantity) {
		this.maxRandomOrderQuantity = maxRandomOrderQuantity;
	}

	public Double getMinLvlDays() {
		return minLvlDays;
	}

	public void setMinLvlDays(Double minLvlDays) {
		this.minLvlDays = minLvlDays;
	}

	public Double getMinLvlHrs() {
		return minLvlHrs;
	}

	public void setMinLvlHrs(Double minLvlHrs) {
		this.minLvlHrs = minLvlHrs;
	}

	public Double getOprtnlRsrvVal() {
		return oprtnlRsrvVal;
	}

	public void setOprtnlRsrvVal(Double oprtnlRsrvVal) {
		this.oprtnlRsrvVal = oprtnlRsrvVal;
	}

	public Double getOrderPointQty() {
		return orderPointQty;
	}

	public void setOrderPointQty(Double orderPointQty) {
		this.orderPointQty = orderPointQty;
	}

	public Double getPartRptPt() {
		return partRptPt;
	}

	public void setPartRptPt(Double partRptPt) {
		this.partRptPt = partRptPt;
	}

	public String getPartsUsgInd() {
		return partsUsgInd;
	}

	public void setPartsUsgInd(String partsUsgInd) {
		this.partsUsgInd = partsUsgInd;
	}

	public Integer getPrimaryLccnNum() {
		return primaryLccnNum;
	}

	public void setPrimaryLccnNum(Integer primaryLccnNum) {
		this.primaryLccnNum = primaryLccnNum;
	}

	public String getShipFaclId() {
		return shipFaclId;
	}

	public void setShipFaclId(String shipFaclId) {
		this.shipFaclId = shipFaclId;
	}

	public String getShipFaclTypeCd() {
		return shipFaclTypeCd;
	}

	public void setShipFaclTypeCd(String shipFaclTypeCd) {
		this.shipFaclTypeCd = shipFaclTypeCd;
	}

	public String getSuplrCode() {
		return suplrCode;
	}

	public void setSuplrCode(String suplrCode) {
		this.suplrCode = suplrCode;
	}

	public String getSuplrType() {
		return suplrType;
	}

	public void setSuplrType(String suplrType) {
		this.suplrType = suplrType;
	}

	public Double getTransitTimeDays() {
		return transitTimeDays;
	}

	public void setTransitTimeDays(Double transitTimeDays) {
		this.transitTimeDays = transitTimeDays;
	}

	public Double getTransitTimeHrs() {
		return transitTimeHrs;
	}

	public void setTransitTimeHrs(Double transitTimeHrs) {
		this.transitTimeHrs = transitTimeHrs;
	}

	public Double getUnitLoadQty() {
		return unitLoadQty;
	}

	public void setUnitLoadQty(Double unitLoadQty) {
		this.unitLoadQty = unitLoadQty;
	}

	public String getXdckOrdOptCde() {
		return xdckOrdOptCde;
	}

	public void setXdckOrdOptCde(String xdckOrdOptCde) {
		this.xdckOrdOptCde = xdckOrdOptCde;
	}

	public String getXdckSubsysId() {
		return xdckSubsysId;
	}

	public void setXdckSubsysId(String xdckSubsysId) {
		this.xdckSubsysId = xdckSubsysId;
	}

	public long getPartId() {
		return partId;
	}

	public void setPartId(long partId) {
		this.partId = partId;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public char getPartClassCode() {
		return partClassCode;
	}

	public void setPartClassCode(char partClassCode) {
		this.partClassCode = partClassCode;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	public void setOperationalReserveQuantity(double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	public double getMinRanOrderQuantity() {
		return minRanOrderQuantity;
	}

	public void setMinRanOrderQuantity(double minRanOrderQuantity) {
		this.minRanOrderQuantity = minRanOrderQuantity;
	}

	public double getSnpQuantity() {
		return snpQuantity;
	}

	public void setSnpQuantity(double snpQuantity) {
		this.snpQuantity = snpQuantity;
	}

	public char getFloatTypeUseCd() {
		return floatTypeUseCd;
	}

	public void setFloatTypeUseCd(char floatTypeUseCd) {
		this.floatTypeUseCd = floatTypeUseCd;
	}

	public double getRecommendedDays() {
		return recommendedDays;
	}

	public void setRecommendedDays(double recommendedDays) {
		this.recommendedDays = recommendedDays;
	}

	public double getRecommendedHours() {
		return recommendedHours;
	}

	public void setRecommendedHours(double recommendedHours) {
		this.recommendedHours = recommendedHours;
	}

	public String getFloatComments() {
		return floatComments;
	}

	public void setFloatComments(String floatComments) {
		this.floatComments = floatComments;
	}

	public Date getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPartTypeCode() {
		return partTypeCode;
	}

	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	@Override
	public String toString() {
		return "PartEntity [partId=" + partId + ", plantId=" + plantId + ", itemNumber=" + itemNumber
				+ ", itemDescription=" + itemDescription + ", itemType=" + itemType + ", partClassCode=" + partClassCode
				+ ", unitPrice=" + unitPrice + ", operationalReserveQuantity=" + operationalReserveQuantity
				+ ", minRanOrderQuantity=" + minRanOrderQuantity + ", snpQuantity=" + snpQuantity + ", floatTypeUseCd="
				+ floatTypeUseCd + ", recommendedDays=" + recommendedDays + ", recommendedHours=" + recommendedHours
				+ ", floatComments=" + floatComments + ", loadDate=" + loadDate + ", analystCde=" + analystCde
				+ ", groupCde=" + groupCde + ", lccnDockId=" + lccnDockId + ", lccnTypeCode=" + lccnTypeCode
				+ ", lstRequestDate=" + lstRequestDate + ", maxRandomOrderQuantity=" + maxRandomOrderQuantity
				+ ", minLvlDays=" + minLvlDays + ", minLvlHrs=" + minLvlHrs + ", oprtnlRsrvVal=" + oprtnlRsrvVal
				+ ", orderPointQty=" + orderPointQty + ", partRptPt=" + partRptPt + ", partsUsgInd=" + partsUsgInd
				+ ", primaryLccnNum=" + primaryLccnNum + ", shipFaclId=" + shipFaclId + ", shipFaclTypeCd="
				+ shipFaclTypeCd + ", suplrCode=" + suplrCode + ", suplrType=" + suplrType + ", transitTimeDays="
				+ transitTimeDays + ", transitTimeHrs=" + transitTimeHrs + ", unitLoadQty=" + unitLoadQty
				+ ", xdckOrdOptCde=" + xdckOrdOptCde + ", xdckSubsysId=" + xdckSubsysId + ", partTypeCode="
				+ partTypeCode + ", partCategoryMappingEntities=" + partCategoryMappingEntities + "]";
	}

}