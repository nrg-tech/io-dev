package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.PartCategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartDetailsDTO;
import com.nissandigital.inventoryoptimization.dto.PartsCategoryMappingDTO;

public interface PartCategoryService {

	/**
	 * Method to map Parts with parts category details
	 * 
	 * @param Parts
	 * @return
	 */
	void  addPartsToPartsCategory(PartsCategoryMappingDTO partsCategoryMappingDTO);
	
	/**
	 * Method to add new Part Category
	 * 
	 * @param Part Category
	 * @return
	 */
	void  addPartsCategory(PartCategoryDTO partCategoryDTO);
	
	/**
	 * Method to find Parts Mapped to Specific Category
	 * 
	 * @param Part Category Id
	 * @return List of Part Details for Category
	 */
	public List<PartDetailsDTO> findPartsByCategory(long categoryId);
	/**
	 * Method to find Unmapped Parts
	 * 
	 * @param
	 * @return List of Part Details
	 */
	public List<PartDetailsDTO> findUnmappedParts();


}
