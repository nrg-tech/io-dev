package com.nissandigital.inventoryoptimization.dto;

/**
 * DTO class containing Supply variability contribution
 * 
 * @author Nissan Digital
 *
 */
public class SupplyVariabilityContributionDTO {

	private String itemNumber;
	private double averageSupplyCycleTime;
	private double coefVariableSupplyCycleTime;

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the averageSupplyCycleTime
	 */
	public double getAverageSupplyCycleTime() {
		return averageSupplyCycleTime;
	}

	/**
	 * @param averageSupplyCycleTime the averageSupplyCycleTime to set
	 */
	public void setAverageSupplyCycleTime(double avgSupCycleTime) {
		this.averageSupplyCycleTime = avgSupCycleTime;
	}

	/**
	 * @return the coefVariableSupplyCycleTime
	 */
	public double getCoefVariableSupplyCycleTime() {
		return coefVariableSupplyCycleTime;
	}

	/**
	 * @param coefVariableSupplyCycleTime the coefVariableSupplyCycleTime to set
	 */
	public void setCoefVariableSupplyCycleTime(double covVarSupCycleTime) {
		this.coefVariableSupplyCycleTime = covVarSupCycleTime;
	}

}
