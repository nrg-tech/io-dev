package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.PlantDetailsDTO;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.service.PlantService;
import com.nissandigital.inventoryoptimization.service.UserService;

/**
 * Implementation class for plant service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class PlantServiceImpl implements PlantService {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PlantRepository plantRepository;

	@Autowired
	UserService userService;

	@Override
	public List<PlantDetailsDTO> getPlantInformation() {
		return plantRepository.findByPlantId(userService.getCurrentUser().getPlantId()).stream()
				.map(w -> modelMapper.map(w, PlantDetailsDTO.class)).collect(Collectors.toList());
	}

}
