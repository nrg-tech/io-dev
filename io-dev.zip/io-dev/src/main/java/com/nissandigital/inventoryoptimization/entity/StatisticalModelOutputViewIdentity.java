package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

public class StatisticalModelOutputViewIdentity implements Serializable {
	private String plantCode;
	private String partNumber;
	private Double serviceLevel;
}
