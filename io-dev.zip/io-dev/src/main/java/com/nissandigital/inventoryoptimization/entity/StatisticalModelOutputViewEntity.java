package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * Class for Statistical Model View Entity
 * 
 * @author Nissan Digital
 *
 */
@Entity
@Table(name = "io_mv_sm_op_curr", schema = "io_stat_model")
@IdClass(StatisticalModelOutputViewIdentity.class)
public class StatisticalModelOutputViewEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "plant_cd", length = 2)
	private String plantCode;

	@Id
	@Column(name = "item_num", length = 30)
	private String partNumber;

	@Id
	@Column(name = "service_level", precision = 15)
	private Double serviceLevel;

	@Column(name = "model_exec_dt", length = 29)
	private Date modelExecutionDate;

	@Column(name = "distrib_type_lt", length = 30)
	private String distributionTypeLeadTime;

	@Column(name = "distrib_type_dem", length = 30)
	private String distributionTypeDemand;

	@Column(name = "unit_price", precision = 15)
	private Double unitPrice;

	@Column(name = "suplr_type", length = 15)
	private String supplierType;

	@Column(name = "suplr_code", length = 15)
	private String supplierCode;

	@Column(name = "suplr_name")
	private String supplierName;

	@Column(name = "state_code")
	private String supplierStateCode;

	@Column(name = "bsl_inv_qty", precision = 15)
	private Double baselineInventoryQuantity;

	@Column(name = "bsl_inv_val", precision = 15)
	private Double baselineInventoryValue;

	@Column(name = "tot_dem_frcst")
	private Integer totalDemandForecast;

	@Column(name = "tot_dem_status", length = 15)
	private String totalDemandStatus;

	@Column(name = "avg_dly_dem")
	private Integer averageDailyDemand;

	@Column(name = "abc_class_consump_val", length = 1)
	private Character abcClassConsumptionValue;

	@Column(name = "xyz_class_cov_dem_frcst", length = 1)
	private Character xyzClassCoefficientOfVarianceDemandForecast;

	@Column(name = "abc_xyz_class_ind")
	private String abcXyzClassificationIndicator;

	@Column(name = "other_class", length = 1)
	private Character otherClass;

	@Column(name = "min_ran_ordr_qty", precision = 15)
	private Double minimumRanOrderQuantity;

	@Column(name = "snp_qty")
	private Double snpQuantity;

	@Column(name = "float_recom_days", precision = 15)
	private Double floatRecommendedDaysCurrent;

	@Column(name = "float_recom_hrs")
	private Double floatRecommendedHoursCurrent;

	@Column(name = "oprtnl_rsrv_qty", precision = 15)
	private Double operationalReserveQuantity;

	@Column(name = "oprtnl_rsrv_val", precision = 15)
	private Double operationalReserveValue;

	@Column(name = "purch_freq_ran_days", precision = 15)
	private Double purchaseFrequencyRanDays;

	@Column(name = "purch_lt_days", precision = 15)
	private Double purchaseLeadTime;

	@Column(name = "supply_cycle_time")
	private Double supplyCycleTime;

	@Column(name = "cov_dly_om_dem_cpd")
	private Double covDailyOmDemandCapped;

	@Column(name = "cov_lst_12_mon")
	private Double covLast12Month;

	@Column(name = "cov_lt_var", precision = 15)
	private Double coefficientOfVarianceLeadTimeVariability;

	@Column(name = "cov_lt_var_om_cpd", precision = 15)
	private Double coefficientOfVarianceLeadTimeVariabilityOmCapped;

	@Column(name = "pur_freq_var", precision = 15)
	private Double purchaseFrequencyVariability;

	@Column(name = "pur_freq_var_om", precision = 15)
	private Double purchaseFrequencyVariabilityOm;

	@Column(name = "safety_stock_qty_dem_var", precision = 15)
	private Double safetyStockQuantityDemandVariability;

	@Column(name = "safety_stock_val_dem_var", precision = 15)
	private Double safetyStockValueDemandVariability;

	@Column(name = "safety_stock_qty_supl_var", precision = 15)
	private Double safetyStockQuantitySupplierVariability;

	@Column(name = "safety_stock_val_supl_var", precision = 15)
	private Double safetyStockValueSupplierVariability;

	@Column(name = "tot_safety_stock_qty", precision = 15)
	private Double totalSafetyStockQuantity;

	@Column(name = "safety_stock_val", precision = 15)
	private Double safetyStockValue;

	@Column(name = "pipeline_stock_qty", precision = 15)
	private Double directPipelineStockQuantity;

	@Column(name = "pipeline_stock_val", precision = 15)
	private Double directPipelineStockValue;

	@Column(name = "scrap_inv_qty", precision = 15)
	private Double scrapInventoryQuantity;

	@Column(name = "scrap_per_tot_ann_dem", precision = 15)
	private Double scrapPercentageToAnnualDemand;

	@Column(name = "max_scrap_qty_inst", precision = 15)
	private Double maximumScrapQuantityInstance;

	@Column(name = "max_scrap_qty_inst_per", precision = 15)
	private Double maximumScrapQuantityInstancePercentage;

	@Column(name = "max_cycle_loss_qty_inst", precision = 15)
	private Double maximumCycleLossQuantityInstance;

	@Column(name = "max_cycle_loss_qty_inst_per", precision = 15)
	private Double maximumCycleLossQuantityInstancePercentage;

	@Column(name = "cycle_loss_per_tot_ann_dem", precision = 15)
	private Double cycleLossPercentageTotalAnnualDemand;

	@Column(name = "float_inv_savings", precision = 15)
	private Double floatInventorySavings;

	@Column(name = "tot_recom_float_qty", precision = 15)
	private Double totalRecommendedFloatQuantity;

	@Column(name = "tot_recom_float_val", precision = 15)
	private Double totalRecommendedFloatValue;

	@Column(name = "min_float_qty", precision = 15)
	private Double minimumFloatQuantity;

	@Column(name = "min_float_val", precision = 15)
	private Double minimumFloatValue;

	@Column(name = "chg_per_recom_float_val", precision = 15)
	private Double changePerRecommendedFloatValue;

	@Column(name = "tot_recom_reord_qty", precision = 15)
	private Double totalRecommendedReorderQuantity;

	@Column(name = "tot_recom_cycle_stock_qty", precision = 15)
	private Double totalRecommendedCycleStockQuantity;

	@Column(name = "tot_recom_cycle_stock_val", precision = 15)
	private Double totalRecommendedCycleStockValue;

	@Column(name = "tot_recom_on_hand_stock_qty", precision = 15)
	private Double totalRecommendedOnHandStockQuantity;

	@Column(name = "tot_recom_on_hand_stock_val", precision = 15)
	private Double totalRecommendedOnHandStockValue;

	@Column(name = "act_mgmt_lever_1_days", precision = 15)
	private Double activeManagementLever1Days;

	@Column(name = "part_type_cd", length = 10)
	private String partTypeCode;

	@Column(name = "part_category_desc")
	private String partsCategoryDescription;

	@Column(name = "parts_controller", length = 50)
	private String partsController;

	@Column(name = "analyst_cde")
	private String analystCode;

	@Column(name = "lccn_dck_id")
	private String dockId;

	@Column(name = "ship_facl_type_cd")
	private String shipFacility;

	@Column(name = "xdck_ord_opt_cde")
	private String orderOptionCode;

	@Column(name = " xdck_subsys_id")
	private String crossDockSubsystem;

	@Column(name = "part_rpt_pt")
	private Double reportingPoint;

	@Column(name = "float_type_use_cd")
	private Character floatTypeUseCode;

	@Column(name = "primary_lccn_num")
	private int primaryLccnNumber;

	@Column(name = "order_point_qty")
	private Double orderPointQuantity;

	@Column(name = "country_code")
	private String supplierCountry;

	@Column(name = "lst_req_dt")
	private Date lastUsageMonth;

	@Column(name = "grp_cde")
	private String groupCode;

	@Column(name = "tot_num_ib_lccns")
	private Double totalNumberOfInboundLccn;

	@Column(name = "pkg_qty_lt")
	private Double pkgDataL;

	@Column(name = "pkg_qty_wt")
	private Double pkgDataW;

	@Column(name = "pkg_qty_ht")
	private Double pkgDataH;

	@Column(name = "ordr_pnt_calc_cd")
	private String orderPointCalculationCode;

	@Column(name = "ordr_pnt_fctr_1_rt")
	private String orderPointFactor1;

	@Column(name = "rack_cpcty_qt")
	private Integer rackCapacity;

	@Column(name = "dz_loc_typ_cde")
	private String dzLocationType;

	@Column(name = "pick_brod_ind")
	private String pickToBroadcastIndicator;

	@Column(name = "kit_ind")
	private String kitIndicator;

	@Column(name = "sub_asmbld_ind")
	private String subAssembledIndicator;

	@Column(name = "mean_abs_dev_frcst_err")
	private Double meanAbsoluteDeviation;

	@Column(name = "purch_freq_ran_days_method2", precision = 15)
	private Double purchaseFrequencyRanDaysMethod2;

	@Column(name = "purch_freq_ran_days_method3", precision = 15)
	private Double purchaseFrequencyRanDaysMethod3;

	@Column(name = "float_var")
	private Double floatVariance;

	@Column(name = "usage_var")
	private Double usageVariance;

	@Column(name = "tot_recom_float_hrs", precision = 15)
	private Double recommendedFloatHoursLastRun;

	@Column(name = "tot_recom_float_days", precision = 15)
	private Double recommendedFloatDaysLastRun;

	@Column(name = "min_lvl_days")
	private Double minimumFloatCurrentDays;

	@Column(name = "min_lvl_hrs")
	private Double minimumFloatCurrentHours;

	@Column(name = "min_recom_float_days", precision = 15)
	private Double minimumFloatLastRunDays;

	@Column(name = "min_recom_float_hrs", precision = 15)
	private Double minimumFloatLastRunHours;

	@Column(name = "tot_cycle_loss_qty", precision = 15)
	private Double totalCycleLossQuantity;
	

	public Double getRecommendedFloatHoursLastRun() {
		return recommendedFloatHoursLastRun;
	}

	public void setRecommendedFloatHoursLastRun(Double recommendedFloatHoursLastRun) {
		this.recommendedFloatHoursLastRun = recommendedFloatHoursLastRun;
	}

	public Double getRecommendedFloatDaysLastRun() {
		return recommendedFloatDaysLastRun;
	}

	public void setRecommendedFloatDaysLastRun(Double recommendedFloatDaysLastRun) {
		this.recommendedFloatDaysLastRun = recommendedFloatDaysLastRun;
	}

	public Double getFloatRecommendedDaysCurrent() {
		return floatRecommendedDaysCurrent;
	}

	public void setFloatRecommendedDaysCurrent(Double floatRecommendedDaysCurrent) {
		this.floatRecommendedDaysCurrent = floatRecommendedDaysCurrent;
	}

	public Double getFloatRecommendedHoursCurrent() {
		return floatRecommendedHoursCurrent;
	}

	public void setFloatRecommendedHoursCurrent(Double floatRecommendedHoursCurrent) {
		this.floatRecommendedHoursCurrent = floatRecommendedHoursCurrent;
	}

	public Double getMinimumFloatCurrentDays() {
		return minimumFloatCurrentDays;
	}

	public void setMinimumFloatCurrentDays(Double minimumFloatCurrentDays) {
		this.minimumFloatCurrentDays = minimumFloatCurrentDays;
	}

	public Double getMinimumFloatCurrentHours() {
		return minimumFloatCurrentHours;
	}

	public void setMinimumFloatCurrentHours(Double minimumFloatCurrentHours) {
		this.minimumFloatCurrentHours = minimumFloatCurrentHours;
	}

	public Double getMinimumFloatLastRunDays() {
		return minimumFloatLastRunDays;
	}

	public void setMinimumFloatLastRunDays(Double minimumFloatLastRunDays) {
		this.minimumFloatLastRunDays = minimumFloatLastRunDays;
	}

	public Double getMinimumFloatLastRunHours() {
		return minimumFloatLastRunHours;
	}

	public void setMinimumFloatLastRunHours(Double minimumFloatLastRunHours) {
		this.minimumFloatLastRunHours = minimumFloatLastRunHours;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public Double getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(Double serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public int getPrimaryLccnNumber() {
		return primaryLccnNumber;
	}

	public void setPrimaryLccnNumber(int primaryLccnNumber) {
		this.primaryLccnNumber = primaryLccnNumber;
	}

	public Double getPurchaseFrequencyVariability() {
		return purchaseFrequencyVariability;
	}

	public void setPurchaseFrequencyVariability(Double purchaseFrequencyVariability) {
		this.purchaseFrequencyVariability = purchaseFrequencyVariability;
	}

	public Double getPurchaseFrequencyVariabilityOm() {
		return purchaseFrequencyVariabilityOm;
	}

	public void setPurchaseFrequencyVariabilityOm(Double purchaseFrequencyVariabilityOm) {
		this.purchaseFrequencyVariabilityOm = purchaseFrequencyVariabilityOm;
	}

	public Double getPurchaseFrequencyRanDays() {
		return purchaseFrequencyRanDays;
	}

	public void setPurchaseFrequencyRanDays(Double purchaseFrequencyRanDays) {
		this.purchaseFrequencyRanDays = purchaseFrequencyRanDays;
	}

	public Double getPurchaseFrequencyRanDaysMethod2() {
		return purchaseFrequencyRanDaysMethod2;
	}

	public void setPurchaseFrequencyRanDaysMethod2(Double purchaseFrequencyRanDaysMethod2) {
		this.purchaseFrequencyRanDaysMethod2 = purchaseFrequencyRanDaysMethod2;
	}

	public Double getPurchaseFrequencyRanDaysMethod3() {
		return purchaseFrequencyRanDaysMethod3;
	}

	public void setPurchaseFrequencyRanDaysMethod3(Double purchaseFrequencyRanDaysMethod3) {
		this.purchaseFrequencyRanDaysMethod3 = purchaseFrequencyRanDaysMethod3;
	}

	public Double getPurchaseLeadTime() {
		return purchaseLeadTime;
	}

	public void setPurchaseLeadTime(Double purchaseLeadTime) {
		this.purchaseLeadTime = purchaseLeadTime;
	}

	public Integer getRackCapacity() {
		return rackCapacity;
	}

	public void setRackCapacity(Integer rackCapacity) {
		this.rackCapacity = rackCapacity;
	}

	public Double getSafetyStockQuantityDemandVariability() {
		return safetyStockQuantityDemandVariability;
	}

	public void setSafetyStockQuantityDemandVariability(Double safetyStockQuantityDemandVariability) {
		this.safetyStockQuantityDemandVariability = safetyStockQuantityDemandVariability;
	}

	public Double getSafetyStockValueDemandVariability() {
		return safetyStockValueDemandVariability;
	}

	public void setSafetyStockValueDemandVariability(Double safetyStockValueDemandVariability) {
		this.safetyStockValueDemandVariability = safetyStockValueDemandVariability;
	}

	public Double getSafetyStockQuantitySupplierVariability() {
		return safetyStockQuantitySupplierVariability;
	}

	public void setSafetyStockQuantitySupplierVariability(Double safetyStockQuantitySupplierVariability) {
		this.safetyStockQuantitySupplierVariability = safetyStockQuantitySupplierVariability;
	}

	public Double getSafetyStockValueSupplierVariability() {
		return safetyStockValueSupplierVariability;
	}

	public void setSafetyStockValueSupplierVariability(Double safetyStockValueSupplierVariability) {
		this.safetyStockValueSupplierVariability = safetyStockValueSupplierVariability;
	}

	public Double getSafetyStockValue() {
		return safetyStockValue;
	}

	public void setSafetyStockValue(Double safetyStockValue) {
		this.safetyStockValue = safetyStockValue;
	}

	public Double getScrapInventoryQuantity() {
		return scrapInventoryQuantity;
	}

	public void setScrapInventoryQuantity(Double scrapInventoryQuantity) {
		this.scrapInventoryQuantity = scrapInventoryQuantity;
	}

	public Double getScrapPercentageToAnnualDemand() {
		return scrapPercentageToAnnualDemand;
	}

	public void setScrapPercentageToAnnualDemand(Double scrapPercentageToAnnualDemand) {
		this.scrapPercentageToAnnualDemand = scrapPercentageToAnnualDemand;
	}

	public String getShipFacility() {
		return shipFacility;
	}

	public void setShipFacility(String shipFacility) {
		this.shipFacility = shipFacility;
	}

	public Double getSnpQuantity() {
		return snpQuantity;
	}

	public void setSnpQuantity(Double snpQuantity) {
		this.snpQuantity = snpQuantity;
	}

	public String getSupplierStateCode() {
		return supplierStateCode;
	}

	public void setSupplierStateCode(String supplierStateCode) {
		this.supplierStateCode = supplierStateCode;
	}

	public String getSubAssembledIndicator() {
		return subAssembledIndicator;
	}

	public void setSubAssembledIndicator(String subAssembledIndicator) {
		this.subAssembledIndicator = subAssembledIndicator;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Double getSupplyCycleTime() {
		return supplyCycleTime;
	}

	public void setSupplyCycleTime(Double supplyCycleTime) {
		this.supplyCycleTime = supplyCycleTime;
	}

	public Double getTotalCycleLossQuantity() {
		return totalCycleLossQuantity;
	}

	public void setTotalCycleLossQuantity(Double totalCycleLossQuantity) {
		this.totalCycleLossQuantity = totalCycleLossQuantity;
	}

	public Integer getTotalDemandForecast() {
		return totalDemandForecast;
	}

	public void setTotalDemandForecast(Integer totalDemandForecast) {
		this.totalDemandForecast = totalDemandForecast;
	}

	public String getTotalDemandStatus() {
		return totalDemandStatus;
	}

	public void setTotalDemandStatus(String totalDemandStatus) {
		this.totalDemandStatus = totalDemandStatus;
	}

	public Double getTotalNumberOfInboundLccn() {
		return totalNumberOfInboundLccn;
	}

	public void setTotalNumberOfInboundLccn(Double totalNumberOfInboundLccn) {
		this.totalNumberOfInboundLccn = totalNumberOfInboundLccn;
	}

	public Double getTotalRecommendedCycleStockQuantity() {
		return totalRecommendedCycleStockQuantity;
	}

	public void setTotalRecommendedCycleStockQuantity(Double totalRecommendedCycleStockQuantity) {
		this.totalRecommendedCycleStockQuantity = totalRecommendedCycleStockQuantity;
	}

	public Double getTotalRecommendedCycleStockValue() {
		return totalRecommendedCycleStockValue;
	}

	public void setTotalRecommendedCycleStockValue(Double totalRecommendedCycleStockValue) {
		this.totalRecommendedCycleStockValue = totalRecommendedCycleStockValue;
	}

	public Double getTotalRecommendedFloatQuantity() {
		return totalRecommendedFloatQuantity;
	}

	public void setTotalRecommendedFloatQuantity(Double totalRecommendedFloatQuantity) {
		this.totalRecommendedFloatQuantity = totalRecommendedFloatQuantity;
	}

	public Double getTotalRecommendedFloatValue() {
		return totalRecommendedFloatValue;
	}

	public void setTotalRecommendedFloatValue(Double totalRecommendedFloatValue) {
		this.totalRecommendedFloatValue = totalRecommendedFloatValue;
	}

	public Double getTotalRecommendedReorderQuantity() {
		return totalRecommendedReorderQuantity;
	}

	public void setTotalRecommendedReorderQuantity(Double totalRecommendedReorderQuantity) {
		this.totalRecommendedReorderQuantity = totalRecommendedReorderQuantity;
	}

	public Double getTotalRecommendedOnHandStockQuantity() {
		return totalRecommendedOnHandStockQuantity;
	}

	public void setTotalRecommendedOnHandStockQuantity(Double totalRecommendedOnHandStockQuantity) {
		this.totalRecommendedOnHandStockQuantity = totalRecommendedOnHandStockQuantity;
	}

	public Double getTotalRecommendedOnHandStockValue() {
		return totalRecommendedOnHandStockValue;
	}

	public void setTotalRecommendedOnHandStockValue(Double totalRecommendedOnHandStockValue) {
		this.totalRecommendedOnHandStockValue = totalRecommendedOnHandStockValue;
	}

	public Double getTotalSafetyStockQuantity() {
		return totalSafetyStockQuantity;
	}

	public void setTotalSafetyStockQuantity(Double totalSafetyStockQuantity) {
		this.totalSafetyStockQuantity = totalSafetyStockQuantity;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Double getUsageVariance() {
		return usageVariance;
	}

	public void setUsageVariance(Double usageVariance) {
		this.usageVariance = usageVariance;
	}

	public String getOrderOptionCode() {
		return orderOptionCode;
	}

	public void setOrderOptionCode(String orderOptionCode) {
		this.orderOptionCode = orderOptionCode;
	}

	public String getCrossDockSubsystem() {
		return crossDockSubsystem;
	}

	public void setCrossDockSubsystem(String crossDockSubsystem) {
		this.crossDockSubsystem = crossDockSubsystem;
	}

	public Character getAbcClassConsumptionValue() {
		return abcClassConsumptionValue;
	}

	public void setAbcClassConsumptionValue(Character abcClassConsumptionValue) {
		this.abcClassConsumptionValue = abcClassConsumptionValue;
	}

	public Character getXyzClassCoefficientOfVarianceDemandForecast() {
		return xyzClassCoefficientOfVarianceDemandForecast;
	}

	public void setXyzClassCoefficientOfVarianceDemandForecast(Character xyzClassCoefficientOfVarianceDemandForecast) {
		this.xyzClassCoefficientOfVarianceDemandForecast = xyzClassCoefficientOfVarianceDemandForecast;
	}

	public String getAbcXyzClassificationIndicator() {
		return abcXyzClassificationIndicator;
	}

	public void setAbcXyzClassificationIndicator(String abcXyzClassificationIndicator) {
		this.abcXyzClassificationIndicator = abcXyzClassificationIndicator;
	}

	public Double getActiveManagementLever1Days() {
		return activeManagementLever1Days;
	}

	public void setActiveManagementLever1Days(Double activeManagementLever1Days) {
		this.activeManagementLever1Days = activeManagementLever1Days;
	}

	public String getAnalystCode() {
		return analystCode;
	}

	public void setAnalystCode(String analystCode) {
		this.analystCode = analystCode;
	}

	public Double getBaselineInventoryQuantity() {
		return baselineInventoryQuantity;
	}

	public void setBaselineInventoryQuantity(Double baselineInventoryQuantity) {
		this.baselineInventoryQuantity = baselineInventoryQuantity;
	}

	public Double getBaselineInventoryValue() {
		return baselineInventoryValue;
	}

	public void setBaselineInventoryValue(Double baselineInventoryValue) {
		this.baselineInventoryValue = baselineInventoryValue;
	}

	public Integer getAverageDailyDemand() {
		return averageDailyDemand;
	}

	public void setAverageDailyDemand(Integer averageDailyDemand) {
		this.averageDailyDemand = averageDailyDemand;
	}

	public Double getChangePerRecommendedFloatValue() {
		return changePerRecommendedFloatValue;
	}

	public void setChangePerRecommendedFloatValue(Double changePerRecommendedFloatValue) {
		this.changePerRecommendedFloatValue = changePerRecommendedFloatValue;
	}

	public String getSupplierCountry() {
		return supplierCountry;
	}

	public void setSupplierCountry(String supplierCountry) {
		this.supplierCountry = supplierCountry;
	}

	public Double getCovDailyOmDemandCapped() {
		return covDailyOmDemandCapped;
	}

	public void setCovDailyOmDemandCapped(Double covDailyOmDemandCapped) {
		this.covDailyOmDemandCapped = covDailyOmDemandCapped;
	}

	public Double getCovLast12Month() {
		return covLast12Month;
	}

	public void setCovLast12Month(Double covLast12Month) {
		this.covLast12Month = covLast12Month;
	}

	public Double getCoefficientOfVarianceLeadTimeVariability() {
		return coefficientOfVarianceLeadTimeVariability;
	}

	public void setCoefficientOfVarianceLeadTimeVariability(Double coefficientOfVarianceLeadTimeVariability) {
		this.coefficientOfVarianceLeadTimeVariability = coefficientOfVarianceLeadTimeVariability;
	}

	public Double getCoefficientOfVarianceLeadTimeVariabilityOmCapped() {
		return coefficientOfVarianceLeadTimeVariabilityOmCapped;
	}

	public void setCoefficientOfVarianceLeadTimeVariabilityOmCapped(
			Double coefficientOfVarianceLeadTimeVariabilityOmCapped) {
		this.coefficientOfVarianceLeadTimeVariabilityOmCapped = coefficientOfVarianceLeadTimeVariabilityOmCapped;
	}

	public Double getCycleLossPercentageTotalAnnualDemand() {
		return cycleLossPercentageTotalAnnualDemand;
	}

	public void setCycleLossPercentageTotalAnnualDemand(Double cycleLossPercentageTotalAnnualDemand) {
		this.cycleLossPercentageTotalAnnualDemand = cycleLossPercentageTotalAnnualDemand;
	}

	public Double getDirectPipelineStockQuantity() {
		return directPipelineStockQuantity;
	}

	public void setDirectPipelineStockQuantity(Double directPipelineStockQuantity) {
		this.directPipelineStockQuantity = directPipelineStockQuantity;
	}

	public Double getDirectPipelineStockValue() {
		return directPipelineStockValue;
	}

	public void setDirectPipelineStockValue(Double directPipelineStockValue) {
		this.directPipelineStockValue = directPipelineStockValue;
	}

	public String getDistributionTypeLeadTime() {
		return distributionTypeLeadTime;
	}

	public void setDistributionTypeLeadTime(String distributionTypeLeadTime) {
		this.distributionTypeLeadTime = distributionTypeLeadTime;
	}

	public String getDistributionTypeDemand() {
		return distributionTypeDemand;
	}

	public void setDistributionTypeDemand(String distributionTypeDemand) {
		this.distributionTypeDemand = distributionTypeDemand;
	}

	public String getDzLocationType() {
		return dzLocationType;
	}

	public void setDzLocationType(String dzLocationType) {
		this.dzLocationType = dzLocationType;
	}

	public Double getFloatInventorySavings() {
		return floatInventorySavings;
	}

	public void setFloatInventorySavings(Double floatInventorySavings) {
		this.floatInventorySavings = floatInventorySavings;
	}

	public Character getFloatTypeUseCode() {
		return floatTypeUseCode;
	}

	public void setFloatTypeUseCode(Character floatTypeUseCode) {
		this.floatTypeUseCode = floatTypeUseCode;
	}

	public Double getFloatVariance() {
		return floatVariance;
	}

	public void setFloatVariance(Double floatVariance) {
		this.floatVariance = floatVariance;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getKitIndicator() {
		return kitIndicator;
	}

	public void setKitIndicator(String kitIndicator) {
		this.kitIndicator = kitIndicator;
	}

	public String getDockId() {
		return dockId;
	}

	public void setDockId(String dockId) {
		this.dockId = dockId;
	}

	public Date getLastUsageMonth() {
		return lastUsageMonth;
	}

	public void setLastUsageMonth(Date lastUsageMonth) {
		this.lastUsageMonth = lastUsageMonth;
	}

	public Double getMaximumScrapQuantityInstance() {
		return maximumScrapQuantityInstance;
	}

	public void setMaximumScrapQuantityInstance(Double maximumScrapQuantityInstance) {
		this.maximumScrapQuantityInstance = maximumScrapQuantityInstance;
	}

	public Double getMaximumScrapQuantityInstancePercentage() {
		return maximumScrapQuantityInstancePercentage;
	}

	public void setMaximumScrapQuantityInstancePercentage(Double maximumScrapQuantityInstancePercentage) {
		this.maximumScrapQuantityInstancePercentage = maximumScrapQuantityInstancePercentage;
	}

	public Double getMaximumCycleLossQuantityInstance() {
		return maximumCycleLossQuantityInstance;
	}

	public void setMaximumCycleLossQuantityInstance(Double maximumCycleLossQuantityInstance) {
		this.maximumCycleLossQuantityInstance = maximumCycleLossQuantityInstance;
	}

	public Double getMaximumCycleLossQuantityInstancePercentage() {
		return maximumCycleLossQuantityInstancePercentage;
	}

	public void setMaximumCycleLossQuantityInstancePercentage(Double maximumCycleLossQuantityInstancePercentage) {
		this.maximumCycleLossQuantityInstancePercentage = maximumCycleLossQuantityInstancePercentage;
	}

	public Double getMeanAbsoluteDeviation() {
		return meanAbsoluteDeviation;
	}

	public void setMeanAbsoluteDeviation(Double meanAbsoluteDeviation) {
		this.meanAbsoluteDeviation = meanAbsoluteDeviation;
	}

	public Double getMinimumFloatQuantity() {
		return minimumFloatQuantity;
	}

	public void setMinimumFloatQuantity(Double minimumFloatQuantity) {
		this.minimumFloatQuantity = minimumFloatQuantity;
	}

	public Double getMinimumFloatValue() {
		return minimumFloatValue;
	}

	public void setMinimumFloatValue(Double minimumFloatValue) {
		this.minimumFloatValue = minimumFloatValue;
	}

	public Double getMinimumRanOrderQuantity() {
		return minimumRanOrderQuantity;
	}

	public void setMinimumRanOrderQuantity(Double minimumRanOrderQuantity) {
		this.minimumRanOrderQuantity = minimumRanOrderQuantity;
	}

	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	public Double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	public void setOperationalReserveQuantity(Double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	public Double getOperationalReserveValue() {
		return operationalReserveValue;
	}

	public void setOperationalReserveValue(Double operationalReserveValue) {
		this.operationalReserveValue = operationalReserveValue;
	}

	public Double getOrderPointQuantity() {
		return orderPointQuantity;
	}

	public void setOrderPointQuantity(Double orderPointQuantity) {
		this.orderPointQuantity = orderPointQuantity;
	}

	public String getOrderPointCalculationCode() {
		return orderPointCalculationCode;
	}

	public void setOrderPointCalculationCode(String orderPointCalculationCode) {
		this.orderPointCalculationCode = orderPointCalculationCode;
	}

	public String getOrderPointFactor1() {
		return orderPointFactor1;
	}

	public void setOrderPointFactor1(String orderPointFactor1) {
		this.orderPointFactor1 = orderPointFactor1;
	}

	public Character getOtherClass() {
		return otherClass;
	}

	public void setOtherClass(Character otherClass) {
		this.otherClass = otherClass;
	}

	public String getPartsCategoryDescription() {
		return partsCategoryDescription;
	}

	public void setPartsCategoryDescription(String partsCategoryDescription) {
		this.partsCategoryDescription = partsCategoryDescription;
	}

	public Double getReportingPoint() {
		return reportingPoint;
	}

	public void setReportingPoint(Double reportingPoint) {
		this.reportingPoint = reportingPoint;
	}

	public String getPartTypeCode() {
		return partTypeCode;
	}

	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	public String getPartsController() {
		return partsController;
	}

	public void setPartsController(String partsController) {
		this.partsController = partsController;
	}

	public String getPickToBroadcastIndicator() {
		return pickToBroadcastIndicator;
	}

	public void setPickToBroadcastIndicator(String pickToBroadcastIndicator) {
		this.pickToBroadcastIndicator = pickToBroadcastIndicator;
	}

	public Double getPkgDataL() {
		return pkgDataL;
	}

	public void setPkgDataL(Double pkgDataL) {
		this.pkgDataL = pkgDataL;
	}

	public Double getPkgDataW() {
		return pkgDataW;
	}

	public void setPkgDataW(Double pkgDataW) {
		this.pkgDataW = pkgDataW;
	}

	public Double getPkgDataH() {
		return pkgDataH;
	}

	public void setPkgDataH(Double pkgDataH) {
		this.pkgDataH = pkgDataH;
	}

	@Override
	public String toString() {
		return "StatisticalModelOutputViewEntity [plantCode=" + plantCode + ", partNumber=" + partNumber
				+ ", serviceLevel=" + serviceLevel + ", modelExecutionDate=" + modelExecutionDate
				+ ", distributionTypeLeadTime=" + distributionTypeLeadTime + ", distributionTypeDemand="
				+ distributionTypeDemand + ", unitPrice=" + unitPrice + ", supplierType=" + supplierType
				+ ", supplierCode=" + supplierCode + ", supplierName=" + supplierName + ", supplierStateCode="
				+ supplierStateCode + ", baselineInventoryQuantity=" + baselineInventoryQuantity
				+ ", baselineInventoryValue=" + baselineInventoryValue + ", totalDemandForecast=" + totalDemandForecast
				+ ", totalDemandStatus=" + totalDemandStatus + ", averageDailyDemand=" + averageDailyDemand
				+ ", abcClassConsumptionValue=" + abcClassConsumptionValue
				+ ", xyzClassCoefficientOfVarianceDemandForecast=" + xyzClassCoefficientOfVarianceDemandForecast
				+ ", abcXyzClassificationIndicator=" + abcXyzClassificationIndicator + ", otherClass=" + otherClass
				+ ", minimumRanOrderQuantity=" + minimumRanOrderQuantity + ", snpQuantity=" + snpQuantity
				+ ", floatRecommendedDaysCurrent=" + floatRecommendedDaysCurrent + ", floatRecommendedHoursCurrent="
				+ floatRecommendedHoursCurrent + ", operationalReserveQuantity=" + operationalReserveQuantity
				+ ", operationalReserveValue=" + operationalReserveValue + ", purchaseFrequencyRanDays="
				+ purchaseFrequencyRanDays + ", purchaseLeadTime=" + purchaseLeadTime + ", supplyCycleTime="
				+ supplyCycleTime + ", covDailyOmDemandCapped=" + covDailyOmDemandCapped + ", covLast12Month="
				+ covLast12Month + ", coefficientOfVarianceLeadTimeVariability="
				+ coefficientOfVarianceLeadTimeVariability + ", coefficientOfVarianceLeadTimeVariabilityOmCapped="
				+ coefficientOfVarianceLeadTimeVariabilityOmCapped + ", purchaseFrequencyVariability="
				+ purchaseFrequencyVariability + ", purchaseFrequencyVariabilityOm=" + purchaseFrequencyVariabilityOm
				+ ", safetyStockQuantityDemandVariability=" + safetyStockQuantityDemandVariability
				+ ", safetyStockValueDemandVariability=" + safetyStockValueDemandVariability
				+ ", safetyStockQuantitySupplierVariability=" + safetyStockQuantitySupplierVariability
				+ ", safetyStockValueSupplierVariability=" + safetyStockValueSupplierVariability
				+ ", totalSafetyStockQuantity=" + totalSafetyStockQuantity + ", safetyStockValue=" + safetyStockValue
				+ ", directPipelineStockQuantity=" + directPipelineStockQuantity + ", directPipelineStockValue="
				+ directPipelineStockValue + ", scrapInventoryQuantity=" + scrapInventoryQuantity
				+ ", scrapPercentageToAnnualDemand=" + scrapPercentageToAnnualDemand + ", maximumScrapQuantityInstance="
				+ maximumScrapQuantityInstance + ", maximumScrapQuantityInstancePercentage="
				+ maximumScrapQuantityInstancePercentage + ", maximumCycleLossQuantityInstance="
				+ maximumCycleLossQuantityInstance + ", maximumCycleLossQuantityInstancePercentage="
				+ maximumCycleLossQuantityInstancePercentage + ", cycleLossPercentageTotalAnnualDemand="
				+ cycleLossPercentageTotalAnnualDemand + ", floatInventorySavings=" + floatInventorySavings
				+ ", totalRecommendedFloatQuantity=" + totalRecommendedFloatQuantity + ", totalRecommendedFloatValue="
				+ totalRecommendedFloatValue + ", minimumFloatQuantity=" + minimumFloatQuantity + ", minimumFloatValue="
				+ minimumFloatValue + ", changePerRecommendedFloatValue=" + changePerRecommendedFloatValue
				+ ", totalRecommendedReorderQuantity=" + totalRecommendedReorderQuantity
				+ ", totalRecommendedCycleStockQuantity=" + totalRecommendedCycleStockQuantity
				+ ", totalRecommendedCycleStockValue=" + totalRecommendedCycleStockValue
				+ ", totalRecommendedOnHandStockQuantity=" + totalRecommendedOnHandStockQuantity
				+ ", totalRecommendedOnHandStockValue=" + totalRecommendedOnHandStockValue
				+ ", activeManagementLever1Days=" + activeManagementLever1Days + ", partTypeCode=" + partTypeCode
				+ ", partsCategoryDescription=" + partsCategoryDescription + ", partsController=" + partsController
				+ ", analystCode=" + analystCode + ", dockId=" + dockId + ", shipFacility=" + shipFacility
				+ ", orderOptionCode=" + orderOptionCode + ", crossDockSubsystem=" + crossDockSubsystem
				+ ", reportingPoint=" + reportingPoint + ", floatTypeUseCode=" + floatTypeUseCode
				+ ", primaryLccnNumber=" + primaryLccnNumber + ", orderPointQuantity=" + orderPointQuantity
				+ ", supplierCountry=" + supplierCountry + ", lastUsageMonth=" + lastUsageMonth + ", groupCode="
				+ groupCode + ", totalNumberOfInboundLccn=" + totalNumberOfInboundLccn + ", pkgDataL=" + pkgDataL
				+ ", pkgDataW=" + pkgDataW + ", pkgDataH=" + pkgDataH + ", orderPointCalculationCode="
				+ orderPointCalculationCode + ", orderPointFactor1=" + orderPointFactor1 + ", rackCapacity="
				+ rackCapacity + ", dzLocationType=" + dzLocationType + ", pickToBroadcastIndicator="
				+ pickToBroadcastIndicator + ", kitIndicator=" + kitIndicator + ", subAssembledIndicator="
				+ subAssembledIndicator + ", meanAbsoluteDeviation=" + meanAbsoluteDeviation
				+ ", purchaseFrequencyRanDaysMethod2=" + purchaseFrequencyRanDaysMethod2
				+ ", purchaseFrequencyRanDaysMethod3=" + purchaseFrequencyRanDaysMethod3 + ", floatVariance="
				+ floatVariance + ", usageVariance=" + usageVariance + ", recommendedFloatHoursLastRun="
				+ recommendedFloatHoursLastRun + ", recommendedFloatDaysLastRun=" + recommendedFloatDaysLastRun
				+ ", minimumFloatCurrentDays=" + minimumFloatCurrentDays + ", minimumFloatCurrentHours="
				+ minimumFloatCurrentHours + ", minimumFloatLastRunDays=" + minimumFloatLastRunDays
				+ ", minimumFloatLastRunHours=" + minimumFloatLastRunHours + ", totalCycleLossQuantity="
				+ totalCycleLossQuantity + "]";
	}

	

}
