package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the io_part_param_curr database table.
 * 
 */
@Entity
@Table(name = "io_part_param_curr",schema = "io_stat_model")
public class PartParamCurrMappingEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PartParamIdentity partParamIdentity;

	@Column(name = "created_by")
	private Long createdBy;

	@Column(name = "created_dt")
	private Timestamp createdDt;

	@Column(name = "part_param_val")
	private double partParamVal;

	@Column(name = "upd_by")
	private Long updBy;

	@Column(name = "upd_dt")
	private Timestamp updDt;

	// bi-directional many-to-one association to IoDimPartsMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sk_part_id", insertable = false, updatable = false)
	private PartEntity dimPartsMaster;


	public PartParamCurrMappingEntity() {
	}

	public PartParamCurrMappingEntity(PartParamIdentity partParamIdentity, Long createdBy, Timestamp
			createdDt, Date effectDt, double partParamVal, Long updatedBy, Timestamp updatedDt) {
		this.partParamIdentity = partParamIdentity;
		this.createdBy = createdBy;
		this.createdDt = createdDt;
		this.partParamVal = partParamVal;
		this.updBy = updatedBy;
		this.updDt = updatedDt;
	}

	public PartParamIdentity getPartParamIdentity() {
		return partParamIdentity;
	}

	public void setPartParamIdentity(PartParamIdentity partParamIdentity) {
		this.partParamIdentity = partParamIdentity;
	}

	// bi-directional many-to-one association to PartParamEntity
	@ManyToOne
	@JoinColumn(name = "part_param_id", insertable = false, updatable = false)
	private PartParamEntity partParamEntity;
	
	public long getPartParamId() {
		return partParamIdentity.getPartParamId();
	}

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public double getPartParamVal() {
		return this.partParamVal;
	}

	public void setPartParamVal(double partParamVal) {
		this.partParamVal = partParamVal;
	}

	public Long getUpdatedBy() {
		return this.updBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updBy = updatedBy;
	}

	public Timestamp getUpdatedDt() {
		return this.updDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updDt = updatedDt;
	}

	public PartEntity getDimPartsMaster() {
		return this.dimPartsMaster;
	}

	public void setDimPartsMaster(PartEntity dimPartsMaster) {
		this.dimPartsMaster = dimPartsMaster;
	}

	public PartParamEntity getPartParamEntity() {
		return this.partParamEntity;
	}

	public void setPartParamEntity(PartParamEntity partParamEntity) {
		this.partParamEntity = partParamEntity;
	}

}