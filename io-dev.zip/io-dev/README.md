INVENTORY OPTIMISATION BACKEND REPO:

This codebase deals with user-interface requests such as changing the part level values. 
After getting the request, the backend provides the useful information which is displayed in the form of 
graphs and charts.
